R3D AC1D V3.4B1 - BO2 private/offline multiplayer menu

_clientids.gsc is the complete merged plain-text source.
The source/ directory contains editing sections extracted from that same file, and readable/ contains identical text copies. These sections are not standalone scripts; concatenate main.gsc, functions.gsc, maps.gsc, notify.gsc in that order to reproduce the merged file exactly.

Latest change: Add 1min, Remove 1min, Superjump, Gravity and Super Walk appear in Game Settings only (not the parent Game Menu).

Teleport Plus renamed to Teleport Menu; its VIP entry and all five option labels are green (^2). Internal menu references were updated consistently. In-game testing has not been performed.


Game Menu+ removed; Floating Bodies, Remove kill barrier, Vsat 24/7, Sky color and No Fall Damage moved directly into Game Menu with original Host-only access retained. Static source checks passed; no PS4 runtime test performed.
