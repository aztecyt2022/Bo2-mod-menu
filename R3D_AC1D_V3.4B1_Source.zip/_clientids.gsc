// ============================================================================
// R3D AC1D V3.4B1
// Copyright (c) 2026 AZYT - Released under the MIT License (see LICENSE).
// Menu base by TORQ.
// Intended for private/offline use. Provided "as is", without warranty.
// ============================================================================

// R3D AC1D V3.4B1 - BO2 Multiplayer DeadOps PS4/PS5 port
// Install as: /data/DeadOps/t6_mp/_clientids.gsc
// Converted from main.gsc + Functions(1).gsc + Maps.gsc + Notify.gsc
// The DeadOps.sprx loader compiles this plain GSC when a match is started.
// Multiplayer only. Not compatible with t6_zm without a separate rewrite.

#include maps\mp\gametypes\_hud;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\_utility;
#include common_scripts\utility;
#include maps\mp\teams\_teams;
#include maps\mp\killstreaks\_ai_tank;
#include maps\mp\killstreaks\_remotemissile;
#include maps\mp\killstreaks\_killstreaks;
#include maps\mp\gametypes\_weapons;
#include maps\mp\_development_dvars;
#include maps\mp\gametypes\_hud_message;
#include maps\mp\gametypes\_globallogic;
#include maps\mp\gametypes\_rank;
#include maps\mp\killstreaks\_turret_killstreak;
#include maps\mp\killstreaks\_supplydrop;
#include maps\mp\gametypes\_spectating;

init()
{   
    precacheModel("t6_wpn_supply_drop_ally");
    PrecacheShader("compass_emp");
    PrecacheShader("menu_camo_carbon_pattern"); 
    PrecacheShader("gradient_fadein");  
   	precacheShader("headicon_dead");
    PrecacheShader("gradient");
    PrecacheShader("black");             
    level thread onPlayerConnect();
    level.clientid = 0;
    level.currentTimescale = 0;
    level.result = 0;
	level.deads = "headicon_dead";
	level.esps = "hud_remote_missile_target";
}

onPlayerConnect()
{
    for(;;)
    {
        level waittill("connected", player);
        player.MenuInit = false;
        
        if(player isHost())
             player.status = "Host";
        else
             player.status = "Unverified";
             
        if(player isVerified())
             player giveMenu();
             
        player thread onPlayerSpawned();
        player.clientid = level.clientid;
        level.clientid++;
    }
}

onPlayerSpawned()
{
     self endon("disconnect");
     level endon("game_ended");
     isFirstSpawn = true;
     self freezecontrols(false);
     for(;;)
     {
          self waittill("spawned_player");
          // Reset explosive bullets after each respawn (worker ends on death).
          self notify("StopExplosiveBullets");
          self.explosiveBulletsEnabled = false;
          if(isFirstSpawn)
          {
               if (self isHost()) // The if (self isHost()) line is a self host checker, so any code that is in this function it only shows for the host!
               {
                    self iprintln("ADS + Melee ^6To Open"); // this shows a text on the left side 
                    self iprintln("^4Black ^6OPS II: ^1R3D ^3AC1D ^FV3.4B1 ^2Now ^1Running!"); // this shows a text on the left side 
                              wait 0.05;
                    self iprintln("^6Menu Built by: AZYT");
                              wait 0.35;
                    self iprintln("^2Menu Base By: TORQ");
                              
                    thread overflowfix();
                    self thread welcomeMessage();
               }
               isFirstSpawn = false;
          }
         
     }
}
welcomeMessage()
{
    self endon("disconnect");
    level endon("game_ended");

    // Wait out the pre-match intro so the game's own splash doesn't cover it.
    while(isDefined(level.inPrematchPeriod) && level.inPrematchPeriod)
        wait 0.05;
    wait 1.5;

    // Own popup instead of the stock notify: the stock one is locked to
    // screen center (overlaps the menu) and left the third line stuck on screen.
    // Move it with popX / popY (negative x = further left).
    popX = -170;
    popY = 30;

    title = self createFontString("objective", 2.0);
    title setPoint("CENTER", "TOP", popX, popY);
    title setText("^1R3D ^7AC1D ^1V3.4B1");
    title.glowColor = (0.85, 0.05, 0.10);
    title.glowAlpha = 1;
    title.alpha = 0;
    title.foreground = true;
    title.archived = false;
    title.hideWhenInMenu = false;

    sub1 = self createFontString("objective", 1.4);
    sub1 setPoint("CENTER", "TOP", popX, popY + 22);
    sub1 setText("^7BO2 GSC MOD MENU");
    sub1.alpha = 0;
    sub1.foreground = true;
    sub1.archived = false;
    sub1.hideWhenInMenu = false;

    sub2 = self createFontString("objective", 1.2);
    sub2 setPoint("CENTER", "TOP", popX, popY + 38);
    sub2 setText("^7ADS + Melee to open");
    sub2.alpha = 0;
    sub2.foreground = true;
    sub2.archived = false;
    sub2.hideWhenInMenu = false;

    title FadeOverTime(0.5);  title.alpha = 1;
    sub1  FadeOverTime(0.5);  sub1.alpha = 1;
    sub2  FadeOverTime(0.5);  sub2.alpha = 1;
    wait 6;
    title FadeOverTime(0.5);  title.alpha = 0;
    sub1  FadeOverTime(0.5);  sub1.alpha = 0;
    sub2  FadeOverTime(0.5);  sub2.alpha = 0;
    wait 0.6;
    title destroy();
    sub1 destroy();
    sub2 destroy();
}

overflowfix()
{
     level endon("game_ended");
     level.test = createServerFontString("default",1.5);
     level.test setText("xTUL");
     level.test.alpha = 0;
     for(;;)
     {
          level waittill("textset");
          if(level.result >= 50)
          {
               level.test ClearAllTextAfterHudElem();
               level.result = 0;
               foreach(player in level.players)
               {
                    if(isDefined(player.menu) && isDefined(player.menu.open) && player.menu.open)
                    {
                         player recreateText();
                    }
               }
          }
          wait 0.01;
     }
}

recreateText()
{
     self endon("disconnect");
     self endon("death");
     
     if(!isDefined(self.CurMenu) || !isDefined(self.CurTitle))
         return;
     input = self.CurMenu;
     title = self.CurTitle;
     
     self thread submenu(input, title);
}

giveMenu()
{
     if (self isVerified())
     {
          if (!self.MenuInit)
          {
               self.MenuInit = 1;
               self thread MenuInit();
          }
     }
}

isVerified()
{
     if (self.status == "Host" || self.status == "Verified" || self.status == "VIP" || self.status == "Admin" || self.status == "Co-Host")
     {
          return true;
     }
     else
     {
          return false;
     }
}

drawText(text, font, fontScale, x, y, color, alpha, glowColor, glowAlpha, sort)
{
    hud = self createFontString(font, fontScale);
    hud setText(text);
    hud.x = x;
    hud.y = y;
    hud.color = color;
    hud.alpha = alpha;
    hud.glowColor = glowColor;
    hud.glowAlpha = glowAlpha;
    hud.sort = sort;
    hud.alpha = alpha;
    
    level.result += 1;
    hud setText(text);
    level notify("textset");
    
    return hud;
}

drawShader(shader, x, y, width, height, color, alpha, sort)
{
    hud = newClientHudElem(self);
    hud.elemtype = "icon";
    hud.color = color;
    hud.alpha = alpha;
    hud.sort = sort;
    hud.children = [];
    if(isDefined(level.uiParent))
        hud setParent(level.uiParent);
    hud setShader(shader, width, height);
    hud.x = x;
    hud.y = y;
    return hud;
}

changeVerificationMenu(player, verlevel)
{
     if (player.status != verlevel && !player isHost())
     {
          player notify("statusChanged");
          player.status = verlevel;
          wait 0.05;
          player giveMenu();
          
          if(player.status == "Unverified")
          {
               player thread destroyMenu(player);
          }
          if(player isVerified())
          {
               self iprintln("^7 " + getPlayerName(player) + " Is Now " + verificationToColor(verlevel));
               player iPrintln("^2You Are Now" + verificationToColor(verlevel));
               player iprintln("^3Press ADS + Melee ^2To Open The Menu");
          }
     }
     else
     {
          if (player isHost())
              self iPrintln("You Cannot Change The Access Level of The " + verificationToColor(player.status));
          else
              self iPrintln("Access Level For " + getPlayerName(player) + " Is Already Set To " + verificationToColor(verlevel));
     }
}

changeVerification(player, verlevel)
{
     player notify("statusChanged");
     player.status = verlevel;
     wait 0.05;
     player giveMenu();
     
     if(player.status == "Unverified")
     {
          player thread destroyMenu(player);
          player iPrintln("^6Sorry You don't have access!");
     }
     if(player isVerified())
     {
          player iPrintln("^1You Are Now" + verificationToColor(verlevel));
          player iprintln("^1Press^2 ADS + Melee ^2To Open The Menu");
     }
}

getPlayerName(player)
{
    playerName = getSubStr(player.name, 0, player.name.size);
    for(i=0; i < playerName.size; i++)
    {
        if(playerName[i] == "]")
            break;
    }
    if(playerName.size != i)
        playerName = getSubStr(playerName, i + 1, playerName.size);
    return playerName;
}

verificationToNum(status)
{
    if (status == "Host") //HOST
        return 5;
    if (status == "Co-Host") // Co-Host
        return 4;
    if (status == "Admin") // Admin
        return 3;
    if (status == "VIP") // VIP
        return 2;
    if (status == "Verified") // Verified
        return 1;
    else
        return 0;
}

verificationToColor(status)
{
    if (status == "Host")
        return "^2Host";
    if (status == "Co-Host")
        return "^2Co-Host";
    if (status == "Admin")
        return "^2Admin";
    if (status == "VIP")
        return "^2VIP";
    if (status == "Verified")
        return "^2Verified";
    else
        return "^2Unverified";
}

Iif(bool, rTrue, rFalse)
{
    if(bool)
        return rTrue;
    else
        return rFalse;
}

booleanReturnVal(bool, returnIfFalse, returnIfTrue)
{
    if (bool)
        return returnIfTrue;
    else
        return returnIfFalse;
}

booleanOpposite(bool)
{
    if(!isDefined(bool))
        return true;
    if (bool)
        return false;
    else
        return true;
}

CreateMenu()
{
     self add_menu("Main Menu", Undefined, "Verified");
     self add_option("Main Menu", "^1User Menu", ::submenu, "Sub Option 1", "Sub Option 1");
     self add_option("Main Menu", "^1Weapon Menu", ::submenu, "Sub Option 9", "Sub Option 9");  
     self add_option("Main Menu", "^1Vision Menu", ::submenu, "Sub Option 7", "Sub Option 7");
     self add_option("Main Menu", "^1Streaks Menu", ::submenu, "Sub Option 8", "Sub Option 8");
     self add_option("Main Menu", "^1Notify Menu", ::submenu, "Sub Option 3", "Sub Option 3");
     self add_option("Main Menu", "^1Game Menu", ::submenu, "Sub Option 4", "Sub Option 4");
     self add_option("Main Menu", "^1Vip Menu", ::submenu, "Sub Option 10", "Sub Option 10");
     self add_option("Main Menu", "^1Host Menu", ::submenu, "Sub Option 11", "Sub Option 11");       
     self add_option("Main Menu", "^1Verify Menu", ::submenu, "PlayersMenu", "Players Menu");
     self add_option("Main Menu", "^1Forge Menu", ::submenu, "Forge Menu", "Forge Menu");

     self add_menu("Teleport Menu", "Sub Option 10", "VIP");
     self add_option("Teleport Menu", "^2Save location A", ::v36SaveA);
     self add_option("Teleport Menu", "^2Return to A", ::v36LoadA);
     self add_option("Teleport Menu", "^2Save location B", ::v36SaveB);
     self add_option("Teleport Menu", "^2Return to B", ::v36LoadB);
     self add_option("Teleport Menu", "^2Map teleport", ::doTeleport);

     self add_menu("Forge Menu", "Main Menu", "Host");
     self add_option("Forge Menu", "^1Forge Pickup", ::forge);
     self add_option("Forge Menu", "^1Spawn crate", ::forgeBuild, 1);
     self add_option("Forge Menu", "^1Build platform 2x2", ::forgeBuild, 2);
     self add_option("Forge Menu", "^1Build platform 3x3", ::forgeBuild, 3);
     self add_option("Forge Menu", "^1Undo last build", ::forgeUndo);
     self add_option("Forge Menu", "Forge help", ::v36ForgeHelp);






     
     
     self add_menu("Sub Option 1", "Main Menu", "Verified"); 
     self add_option("Sub Option 1", "^1GodMode", ::God_Toggle);  
     self add_option("Sub Option 1", "^1Auto TBag", ::tbag); 
     self add_option("Sub Option 1", "^1Noclip", ::NoclipMode);
     self add_option("Sub Option 1", "^1Invisibility", ::invis);     
     self add_option("Sub Option 1", "^1healthbar", ::healthbar); 
     self add_option("Sub Option 1", "^1End it All", ::commitsuicide);
     self add_option("Sub Option 1", "^1Hide Gun", ::nogun); 
     self add_option("Sub Option 1", "^1Change Fov", ::togglefov);
     self add_option("Sub Option 1", "^1Draw Fps", ::ShowFPS);
     self add_option("Sub Option 1", "^2User Menu+", ::submenu, "Sub Option 1.1", "Sub Option 1");



     self add_menu("Sub Option 1.1", "Sub Option 1", "Verified");
     self add_option("Sub Option 1.1", "^1Third Person", ::toggleThirdPerson);
     self add_option("Sub Option 1.1", "^1Multi Jump", ::toggleMultiJump);
     self add_option("Sub Option 1.1", "^1Floaters", ::toggleFloaters);
     self add_option("Sub Option 1.1", "^1Dead clone", ::clonedead);
     self add_option("Sub Option 1.1", "^1Alive clone", ::cloneAlive);
       
       

     self add_menu("Sub Option 2", "Sub Option 11", "Co-Host"); 
     self add_option("Sub Option 2", "^1-^4-^2-^4-^1Map Selection^1-^2-^2-^4-", ::Ceers);
     self add_option("Sub Option 2", "^2Popular ^1Maps", ::submenu, "Sub Option 2.2", "Sub Option 2");     
     self add_option("Sub Option 2", "^2Normal ^1Maps", ::submenu, "Sub Option 2.3", "Sub Option 2");   
     self add_option("Sub Option 2", "^2DLC ^1Maps", ::submenu, "Sub Option 2.4", "Sub Option 2");  
     self add_option("Sub Option 2", "^1-^4-^2-^4-^1Map Selection^1-^2-^2-^4-", ::Ceers);

     
     
     self add_menu("Sub Option 2.2", "Sub Option 2", "Co-Host");
     self add_option("Sub Option 2.2", "^1Nuketown", ::Nuketown);
     self add_option("Sub Option 2.2", "^1Express", ::Express);
     self add_option("Sub Option 2.2", "^1Standoff", ::Standoff);  
     self add_option("Sub Option 2.2", "^1Cargo", ::Cargo); 
     self add_option("Sub Option 2.2", "^1Carrier", ::Carrier);
     self add_option("Sub Option 2.2", "^1Hijacked", ::Hijacked);            
     
     
     
     self add_menu("Sub Option 2.3", "Sub Option 2", "Co-Host");
     self add_option("Sub Option 2.3", "^1Meltdown", ::Meltdown);
     self add_option("Sub Option 2.3", "^1Drone", ::Drone);
     self add_option("Sub Option 2.3", "^1Overflow", ::Overflow);
     self add_option("Sub Option 2.3", "^1Slums", ::Slums);
     self add_option("Sub Option 2.3", "^1Turbine", ::Turbine);
     self add_option("Sub Option 2.3", "^1Raid", ::Raid);
     self add_option("Sub Option 2.3", "^1Aftermath", ::Aftermath);
     self add_option("Sub Option 2.3", "^1Plaza", ::Plaza);
     self add_option("Sub Option 2.3", "^1Yemen", ::Yemen);



     self add_menu("Sub Option 2.4", "Sub Option 2", "Co-Host");   							
     self add_option("Sub Option 2.4", "^1Skate", ::skate);     
     self add_option("Sub Option 2.4", "^1studio", ::studio);       
     self add_option("Sub Option 2.4", "^1paintball", ::paintball);       
     self add_option("Sub Option 2.4", "^1hydro", ::hydro);       
     self add_option("Sub Option 2.4", "^1mirage", ::mirage);       
     self add_option("Sub Option 2.4", "^1uplink", ::uplink);      
     self add_option("Sub Option 2.4", "^1detour", ::detour);       
     self add_option("Sub Option 2.4", "^1cove", ::cove);       
     self add_option("Sub Option 2.4", "^1magma", ::magma);
     self add_option("Sub Option 2.4", "^2DLC+", ::submenu, "Sub Option 2.44", "Sub Option 2"); 
     
     
     
     self add_menu("Sub Option 2.44", "Sub Option 2.4", "Co-Host"); 
     self add_option("Sub Option 2.44", "^1vertigo", ::vertigo);       
     self add_option("Sub Option 2.44", "^1concert", ::concert);       
     self add_option("Sub Option 2.44", "^1downhill", ::downhill);      
     self add_option("Sub Option 2.44", "^1frostbite", ::frostbite);       
     self add_option("Sub Option 2.44", "^1takeoff", ::takeoff);       
     self add_option("Sub Option 2.44", "^1pod", ::pod);       
     self add_option("Sub Option 2.44", "^1dig", ::dig); 
     
     


     

     self add_menu("Sub Option 3", "Main Menu", "Host"); 
     self add_option("Sub Option 3", "^1-^4-^2-^4-^1Menu messages^1-^2-^2-^4-", ::Ceers);
     self add_option("Sub Option 3", "^1Messages 1", ::submenu, "Sub Option 3.2", "Sub Option 3");     
     self add_option("Sub Option 3", "^1Messages 2", ::submenu, "Sub Option 3.3", "Sub Option 3");   
     self add_option("Sub Option 3", "^1Messages 3", ::submenu, "Sub Option 3.4", "Sub Option 3");
     self add_option("Sub Option 3", "^1-^4-^2-^4-^1Menu messages^1-^2-^2-^4-", ::Ceers);

     
     
     
     
     self add_menu("Sub Option 3.2", "Sub Option 3", "Host"); 
     self add_option("Sub Option 3.2", "^1Menu Version", ::msg);
     self add_option("Sub Option 3.2", "^1Creator", ::msg2);
     self add_option("Sub Option 3.2", "^1Build for", ::msgg); 
     self add_option("Sub Option 3.2", "^1Source Menu", ::msgb); 
     self add_option("Sub Option 3.2", "^1Free Hosting", ::msga);     
     self add_option("Sub Option 3.2", "^1Offline Menu", ::msg9);
     
     
     self add_menu("Sub Option 3.3", "Sub Option 3", "Host");
     self add_option("Sub Option 3.3", "^1YES", ::msgyes);
     self add_option("Sub Option 3.3", "^1NO", ::msgno);
     self add_option("Sub Option 3.3", "^1STFU", ::msgga1);    
     self add_option("Sub Option 3.3", "^1MORON", ::msgga2);    
     self add_option("Sub Option 3.3", "^1WHY", ::msgwhy);
     self add_option("Sub Option 3.3", "^1Get Out", ::msggbb);  
     
     
     
     self add_menu("Sub Option 3.4", "Sub Option 3", "Host");
     self add_option("Sub Option 3.4", "^1Crack Addict", ::msgc);
     self add_option("Sub Option 3.4", "^1FKUOH", ::msgd);
     self add_option("Sub Option 3.4", "^1Menu promo", ::msge);
     self add_option("Sub Option 3.4", "^1Green Grass", ::msgf); 
     self add_option("Sub Option 3.4", "^1BO2OT", ::msg0);  
     
     

     
     self add_menu("Sub Option 4", "Main Menu", "Co-Host");
     self add_option("Sub Option 4", "^2Bot Menu", ::submenu, "Sub Option 6", "Sub Option 4");
     self add_option("Sub Option 4", "^2XP Menu", ::submenu, "Sub Option 5", "Sub Option 4");
     self add_option("Sub Option 4", "^1Flashing Killfeed", ::flashfeed2);
     self add_option("Sub Option 4", "^1KnockBack", ::knock);  
     self add_option("Sub Option 4", "^2Game Settings", ::submenu, "Game Settings", "Game Settings");
     // Retain the former Game Menu+ host-only access.
     if(verificationToNum(self.status) >= verificationToNum("Host"))
     {
          self add_option("Sub Option 4", "^1Floating Bodies", ::floater);
          self add_option("Sub Option 4", "^1Remove kill barrier", ::removedbarrier);
          self add_option("Sub Option 4", "^1Vsat 24/7", ::alwaysVSAT);
          self add_option("Sub Option 4", "^1Sky color", ::dosky);
          self add_option("Sub Option 4", "^1No Fall Damage", ::dofalldamage);
     }





     self add_menu("Sub Option 5", "Sub Option 4", "Host");
     self add_option("Sub Option 5", "^1Max Xp", ::X9XP);
     self add_option("Sub Option 5", "^1+420XP", ::WDXP);     
     self add_option("Sub Option 5", "^1Normal XP", ::BO2N); 
     self add_option("Sub Option 5", "^1Cod 4 XP", ::CODXP); 
     self add_option("Sub Option 5", "^1+1 XP", ::A1XP);
     self add_option("Sub Option 5", "^1Death XP", ::DMXP);
     self add_option("Sub Option 5", "^1Double XP", ::X2BO2);
     self add_option("Sub Option 5", "^1Triple XP", ::X3BO2);
     self add_option("Sub Option 5", "^1Boosted XP", ::Boosted);          
     

     
     self add_menu("Sub Option 6", "Sub Option 4", "Host"); 
     self add_option("Sub Option 6", "^1-^4-^2-^4-^1Bot Options^1-^2-^2-^4-", ::Ceers);
     self add_option("Sub Option 6", "^3Spawning ^2info", ::BOT2INFO);
     self add_option("Sub Option 6", "^1Bot Options", ::submenu, "Sub Option 6.2", "Sub Option 6");  
     self add_option("Sub Option 6", "^1Bot Spawning", ::submenu, "Sub Option 6.3", "Sub Option 6");   
     self add_option("Sub Option 6", "^1-^4-^2-^4-^1Bot Options^1-^2-^2-^4-", ::Ceers);

     
     
     self add_menu("Sub Option 6.2", "Sub Option 6", "Host");
     self add_option("Sub Option 6.2", "^1Freeze Bots", ::FreezeBots);
     self add_option("Sub Option 6.2", "^1Tele Bots", ::TeleBots);
     self add_option("Sub Option 6.2", "^1Kick Bots", ::kAB); 
     
     
     
     self add_menu("Sub Option 6.3", "Sub Option 6", "Host");
     self add_option("Sub Option 6.3", "^1Spawn 1", ::SpawnBot1);
     self add_option("Sub Option 6.3", "^2Spawn 2", ::SpawnBot2);
     self add_option("Sub Option 6.3", "^3Spawn 3", ::SpawnBot3);     
     self add_option("Sub Option 6.3", "^4Spawn 4", ::SpawnBot4); 
     self add_option("Sub Option 6.3", "^5Spawn 5", ::SpawnBot5);     
     self add_option("Sub Option 6.3", "^2Spawn 6", ::SpawnBot6);
     self add_option("Sub Option 6.3", "^7Spawn 7", ::SpawnBot7);     
     self add_option("Sub Option 6.3", "^8Spawn 8", ::SpawnBot8);
     self add_option("Sub Option 6.3", "^9Spawn 9", ::SpawnBot9);     
     self add_option("Sub Option 6.3", "^1Spawn 10", ::SpawnBot10);  
     
     

     
     self add_menu("Sub Option 7", "Main Menu", "Verified");
     self add_option("Sub Option 7", "^1Black and White", ::BWV);
     self add_option("Sub Option 7", "^1Light Vision", ::LVis);
     self add_option("Sub Option 7", "^1Enhanced Vision", ::EV);
     self add_option("Sub Option 7", "^1Infrared Vision", ::infrarV); 
     self add_option("Sub Option 7", "^1Water Vision", ::WVis);
     self add_option("Sub Option 7", "^1Poison Vision", ::PVis);
     self add_option("Sub Option 7", "^1Flare", ::setVision, "flare", "Flare");
     self add_option("Sub Option 7", "^1Mortar Infrared", ::setVision, "remote_mortar_infrared", "Mortar Infrared");
     self add_option("Sub Option 7", "^2Reset Vision", ::resetVision);


     
     

     self add_menu("Sub Option 8", "Main Menu", "VIP");
     self add_option("Sub Option 8", "^1Max Streak Score", ::doKillstreaks);
     self add_option("Sub Option 8", "^1Give Equipped", ::GiveEquipped);
     self add_option("Sub Option 8", "^1Give UAV", ::GiveUAV);
     self add_option("Sub Option 8", "^1Give RC-XD", ::GiveRC);
     self add_option("Sub Option 8", "^1Give guardian", ::GiveGuard);
     self add_option("Sub Option 8", "^1Give HellStorm", ::GiveHell);
     self add_option("Sub Option 8", "^1Give S.Chopper ", ::GiveSC); 
     self add_option("Sub Option 8", "^1Give VSAT", ::GiveVSAT);
     self add_option("Sub Option 8", "^1Give Escort.D", ::GiveED); 
     self add_option("Sub Option 8", "^2Streak Menu+", ::submenu, "Sub Option 8.1", "Sub Option 8");  
     



     self add_menu("Sub Option 8.1", "Sub Option 8", "VIP"); 
     self add_option("Sub Option 8.1", "^1Give Warthog", ::GiveWH);
     self add_option("Sub Option 8.1", "^1Give Lodestar", ::GiveLST);
     self add_option("Sub Option 8.1", "^1Give VTOL.W", ::GiveVW);
     self add_option("Sub Option 8.1", "^1Give Dogs", ::GiveDogs);  
     self add_option("Sub Option 8.1", "^1Give Swarm", ::GiveSwarm);  
     self add_option("Sub Option 8.1", "^1Give A.G.R", ::GiveAG); 
     self add_option("Sub Option 8.1", "^1Give EMP ", ::GiveEMP);



    
     self add_menu("Sub Option 9", "Main Menu", "Verified"); 
     self add_option("Sub Option 9", "^2Weapon Selection #1", ::submenu, "Sub Option 9.1", "Sub Option 9");     
     self add_option("Sub Option 9", "^2Weapon Selection #2", ::submenu, "Sub Option 9.2", "Sub Option 9"); 
     self add_option("Sub Option 9", "^1-^4-^2-^4-^1Weapon Mods^1-^2-^2-^4-", ::Ceers);   
     self add_option("Sub Option 9", "^1ChangeClass", ::ChangeClass);
     self add_option("Sub Option 9", "^1Random Camo", ::randomcamo);  
     self add_option("Sub Option 9", "^1Low ammo flash", ::flashlowammo); 
     self add_option("Sub Option 9", "^1Disco Camo", ::Toggle_DiscoCamo);
     self add_option("Sub Option 9", "^1Random Gun Drop", ::dropCanSwap);
     self add_option("Sub Option 9", "^2Weapon Menu+", ::submenu, "Sub Option 9.3", "Sub Option 9"); 
     
     
    
    
     self add_menu("Sub Option 9.3", "Sub Option 9", "Verified");
     self add_option("Sub Option 9.3", "^1Unlimited Ammo", ::unammo);  
     self add_option("Sub Option 9.3", "^1No Recoil", ::norecoil); 
     self add_option("Sub Option 9.3", "^1No Spread", ::nospread); 
     self add_option("Sub Option 9.3", "^1Rapid Fire", ::rapidfire);
     self add_option("Sub Option 9.3", "^1Left Hand", ::ToggleLeft);
     self add_option("Sub Option 9.3", "^1EB Bullet", ::explosivebullets);
     
     

     
     self add_menu("Sub Option 9.1", "Sub Option 9", "Verified");
     self add_option("Sub Option 9.1", "^1An94", ::an94);
     self add_option("Sub Option 9.1", "^1Type95", ::type95);         
     self add_option("Sub Option 9.1", "^1Xm8", ::xm8);      
     self add_option("Sub Option 9.1", "^1As50", ::as50);
     self add_option("Sub Option 9.1", "^1Dsr50", ::dsr50);
     self add_option("Sub Option 9.1", "^1Ballista", ::ballista);
     self add_option("Sub Option 9.1", "^1Fivesevendw", ::fivesevendw); 
     self add_option("Sub Option 9.1", "^2Weapons+", ::submenu, "Sub Option 9.11", "Sub Option 9"); 
     
     
     
     
     self add_menu("Sub Option 9.11", "Sub Option 9.1", "Verified");    
     self add_option("Sub Option 9.11", "^1Mk48", ::mk48);       
     self add_option("Sub Option 9.11", "^1Mp7", ::mp7);         
     self add_option("Sub Option 9.11", "^1Ksg", ::ksg);    
     self add_option("Sub Option 9.11", "^1Lsat", ::lsat);   
     self add_option("Sub Option 9.11", "^1Hamr", ::hamr); 
     
     
     
  
     
     self add_menu("Sub Option 9.2", "Sub Option 9", "Verified");
     self add_option("Sub Option 9.2", "^1Tar21", ::tar21);  
     self add_option("Sub Option 9.2", "^1Vector", ::vector);  
     self add_option("Sub Option 9.2", "^1Kap-40", ::karddw);
     self add_option("Sub Option 9.2", "^1Tac-45", ::fnp45);     
     self add_option("Sub Option 9.2", "^1Peacekeeper", ::peacekeeper);   
     self add_option("Sub Option 9.2", "^1Scar", ::scar); 
     self add_option("Sub Option 9.2", "^2Weapons+", ::submenu, "Sub Option 9.22", "Sub Option 9"); 
     
     
     
     
     self add_menu("Sub Option 9.22", "Sub Option 9.2", "Verified");
     self add_option("Sub Option 9.22", "^1Crossbow", ::crossbow);
     self add_option("Sub Option 9.22", "^1Mcs870", ::mcs870);  
     self add_option("Sub Option 9.22", "^1Riotshield", ::riotshield); 
     self add_option("Sub Option 9.22", "^1Minigun", ::minigun);       



     
     
     self add_menu("Sub Option 10", "Main Menu", "VIP");   
     self add_option("Sub Option 10", "^2Teleport Menu", ::submenu, "Teleport Menu", "Teleport Menu");
     self add_option("Sub Option 10", "^2Infection menu", ::submenu, "Sub Option 10.1", "Sub Option 10");  
     self add_option("Sub Option 10", "^1Add all perks", ::doPerks);
     self add_option("Sub Option 10", "^1Remove perks", ::PerksRemoveSelf);   
     self add_option("Sub Option 10", "^1Change Team", ::initTeamChange); 
     self add_option("Sub Option 10", "^1Rank 55", ::dorank);  
     self add_option("Sub Option 10", "^1Master Prestige", ::domaster); 
     self add_option("Sub Option 10", "^1Unlock camos", ::CamosBarThing);  
     
     
     
     
     self add_menu("Sub Option 10.1", "Sub Option 10", "Host");
     self add_option("Sub Option 10.1", "^2g_speed", ::testinfect); 
     self add_option("Sub Option 10.1", "^2melee Range", ::testinfect1);
     self add_option("Sub Option 10.1", "^2ladderPushVel", ::testinfect2);
     self add_option("Sub Option 10.1", "^2namessizes", ::testinfect3);
     self add_option("Sub Option 10.1", "^2knockback", ::testinfect4);
     self add_option("Sub Option 10.1", "^2killcam timer", ::testinfect5);
     self add_option("Sub Option 10.1", "^2drawThroughWalls", ::testinfect6);
     self add_option("Sub Option 10.1", "^2skyColor", ::testinfect7);
     self add_option("Sub Option 10.1", "^2Migration disabled", ::testinfect8);
     
     

     
     self add_menu("Sub Option 11", "Main Menu", "Host");
     self add_option("Sub Option 11", "^2Host Menu+", ::submenu, "Host Menu+", "Host Menu+");
     self add_option("Sub Option 11", "^1Player Menu", ::submenu, "Sub Option 13", "Sub Option 13");  
     self add_option("Sub Option 11", "^3Aimbot menu", ::submenu, "Sub Option 12", "Sub Option 11"); 
     self add_option("Sub Option 11", "^2Maps Changer", ::submenu, "Sub Option 2", "Sub Option 11"); 
     

     
     
     self add_menu("Host Menu+", "Sub Option 11", "Host");
     self add_option("Host Menu+", "^1Fake EndGame", ::FakeEndGame); 
     self add_option("Host Menu+", "^1Toggle Ranked", ::ToggleRanked);
     self add_option("Host Menu+", "^1No timeLimit", ::unlimtime); 
     self add_option("Host Menu+", "^1Block Joins", ::Joinblock);   
     self add_option("Host Menu+", "^1AntiQuit", ::AntiQuitV3); 
     self add_option("Host Menu+", "^1Insta End", ::instaEnd);
     self add_option("Host Menu+", "^1EndGame", ::endGame); 
     self add_option("Host Menu+", "Restart match", ::doRestart);
     self add_option("Host Menu+", "^1ForceHost", ::forceHost);   
     self add_option("Host Menu+", "^1meleerange", ::meleerange);  
     self add_option("Host Menu+", "^11Min Kill cam", ::killcam6); 

     self add_menu("Sub Option 12", "Sub Option 11", "Host");
     self add_option("Sub Option 12", "^2Wallhack", ::ToggleWallHack);
     self add_option("Sub Option 12", "^3Legit aim", ::tgl_MainRootAimbot2); 
     self add_option("Sub Option 12", "^3Legit no aim", ::tgl_MainRootAimbot1);    
     self add_option("Sub Option 12", "^3Knife Aim", ::TAK);
     self add_option("Sub Option 12", "^3Super Aim", ::doAimbots13); 
     self add_option("Sub Option 12", "^3TS Aim", ::doAimbots12);
     
      
      
      

     self add_menu("Game Settings", "Sub Option 4", "Host");
     self add_option("Game Settings", "Score limit 50", ::v36Score50);
     self add_option("Game Settings", "Score limit 100", ::v36Score100);
     self add_option("Game Settings", "Unlimited score", ::v36ScoreUnlimited);
     self add_option("Game Settings", "Restore score limit", ::v36ScoreRestore);
     self add_option("Game Settings", "^1Add 1min", ::addtime);    
     self add_option("Game Settings", "^1Remove 1min", ::removetime);     
     self add_option("Game Settings", "^1Superjump", ::superjump);
     self add_option("Game Settings", "^1Gravity", ::gravity);
     self add_option("Game Settings", "^1Super Walk", ::SuperFastWalk);
     self add_option("Game Settings", "^1INF Game", ::Inf_Game);     
     self add_option("Game Settings", "^1Timescale", ::Timescales); 
     
     
     
   

     
     
     self add_menu("Sub Option 13", "Sub Option 11", "Admin");
     self add_option("Sub Option 13", "^1List player count", ::v36PlayerCount);
     self add_option("Sub Option 13", "^1Show my team", ::v36MyTeam);
     self add_option("Sub Option 13", "^1Open player list", ::v36PlayerListHelp);
     self add_option("Sub Option 13", "^1Kill All", ::killall);
     self add_option("Sub Option 13", "^1Blind All", ::blindall);
     self add_option("Sub Option 13", "^1Unlim. Ammo All", ::infiniteammoall); 
     self add_option("Sub Option 13", "^1Disco Camo All", ::discocamoall);  
     self add_option("Sub Option 13", "^1Freeze All", ::freezeallplayers); 
     self add_option("Sub Option 13", "^1Fake Derank all", ::FakeDerankAll);  
     self add_option("Sub Option 13", "^1Send all to space", ::sendalltospace);
     self add_option("Sub Option 13", "^1hear all", ::hearallplayers);
     
     


     self add_menu("PlayersMenu", "Main Menu", "Admin");
     for (i = 0;i < level.players.size;i++)
     { 
     self add_menu("pOpt " + i, "PlayersMenu", "Co-Host");
     }
}

updatePlayersMenu()
{
     self.menu.menucount["PlayersMenu"] = 0;
     self.menu.menuopt["PlayersMenu"] = [];
     self.menu.menufunc["PlayersMenu"] = [];
     self.menu.menuinput["PlayersMenu"] = [];
     self.menu.menuinput1["PlayersMenu"] = [];
     for (i = 0;i < level.players.size;i++)
     {
          player = level.players[i];
          playerName = getPlayerName(player);
          
          playersizefixed = level.players.size - 1;
          if(self.menu.curs["PlayersMenu"] > playersizefixed)
          {
               self.menu.scrollerpos["PlayersMenu"] = playersizefixed;
               self.menu.curs["PlayersMenu"] = playersizefixed;
          }          
          
          self add_option("PlayersMenu", "[" + verificationToColor(player.status) + "^7] " + playerName, ::submenu, "pOpt " + i, "[" + verificationToColor(player.status) + "^7] " + playerName); // Dont change or remove this
          self add_menu_alt("pOpt " + i, "PlayersMenu");
          self add_option("pOpt " + i, "^1Give Co-Host", ::changeVerificationMenu, player, "Co-Host"); // Dont change or remove this
          self add_option("pOpt " + i, "^1Give Admin", ::changeVerificationMenu, player, "Admin"); // Dont change or remove this
          self add_option("pOpt " + i, "^1Give VIP", ::changeVerificationMenu, player, "VIP"); // Dont change or remove this
          self add_option("pOpt " + i, "^1Verify", ::changeVerificationMenu, player, "Verified"); // Dont change or remove this
          self add_option("pOpt " + i, "^1Unverify", ::changeVerificationMenu, player, "Unverified"); // Dont change or remove this
   
   }
   
}


add_menu_alt(Menu, prevmenu)
{
     if(!isDefined(self.menu.status[Menu]))
         self.menu.status[Menu] = "Co-Host";
     if(!isDefined(self.menu.curs[Menu]))
         self.menu.curs[Menu] = 0;
     if(!isDefined(self.menu.scrollerpos[Menu]))
         self.menu.scrollerpos[Menu] = 0;
     self.menu.getmenu[Menu] = Menu;
     self.menu.menucount[Menu] = 0;
     self.menu.previousmenu[Menu] = prevmenu;
     self.menu.menuopt[Menu] = [];
     self.menu.menufunc[Menu] = [];
     self.menu.menuinput[Menu] = [];
     self.menu.menuinput1[Menu] = [];
}

add_menu(Menu, prevmenu, status)
{
     self.menu.status[Menu] = status;
     self.menu.getmenu[Menu] = Menu;
     self.menu.scrollerpos[Menu] = 0;
     self.menu.curs[Menu] = 0;
     self.menu.menucount[Menu] = 0;
     self.menu.previousmenu[Menu] = prevmenu;
     self.menu.menuopt[Menu] = [];
     self.menu.menufunc[Menu] = [];
     self.menu.menuinput[Menu] = [];
     self.menu.menuinput1[Menu] = [];
}

add_option(Menu, Text, Func, arg1, arg2)
{
     Menu = self.menu.getmenu[Menu];
     Num = self.menu.menucount[Menu];
     if(!isDefined(self.menu.menuopt[Menu]))
         self.menu.menuopt[Menu] = [];
     self.menu.menuopt[Menu][Num] = Text;
     self.menu.menufunc[Menu][Num] = Func;
     self.menu.menuinput[Menu][Num] = arg1;
     self.menu.menuinput1[Menu][Num] = arg2;
     self.menu.menucount[Menu] += 1;
}

updateScrollbar()
{
     self.menu.scroller MoveOverTime(self.menu.scrollTime);
     self.menu.scroller.y = self.menu.listY + (self.menu.curs[self.menu.currentmenu] * self.menu.rowH);
     self.menu.scroller.archived = false;
}

openMenu()
{
    self freezeControls(false);
    self setClientUiVisibilityFlag("hud_visible", 0);
    self StoreText("Main Menu", "Home");
    
    
    self.menu.background FadeOverTime(0.30);
    self.menu.background.alpha = self.menu.bgAlpha;
    self.menu.background.archived = false;
    
    self.menu.background1 FadeOverTime(0.30);
    self.menu.background1.alpha = self.menu.fadeAlpha;
    self.menu.background1.archived = false;
    
    
    self.menu.line MoveOverTime(0.10);
    self.menu.line.y = 45;  
    self.menu.line.archived = false;
    self.menu.line.alpha = 1;
    
    if(isDefined(self.swagtext))
    {
        self.swagtext FadeOverTime(0.3);
        self.swagtext.alpha = 0.90;
    }

   

    self updateScrollbar();
    self.menu.open = true;
}

closeMenu()
{
    if(!isDefined(self.menu))
        return;
    if(isDefined(self.menu.options))
    {
        self.menu.options FadeOverTime(0.3);
        self.menu.options.alpha = 0;
    }
    self setClientUiVisibilityFlag("hud_visible", 1);
    if(isDefined(self.subtext1))
    {
        self.subtext1 FadeOverTime(0.3);
        self.subtext1.alpha = 0;
    }
    if(isDefined(self.subtext2))
    {
        self.subtext2 FadeOverTime(0.3);
        self.subtext2.alpha = 0;
    }
    if(isDefined(self.torq))
    {
        self.torq FadeOverTime(0.3);
        self.torq.alpha = 0;
    }
    if(isDefined(self.menu.background))
    {
        self.menu.background FadeOverTime(0.3);
        self.menu.background.alpha = 0;
    }
    if(isDefined(self.menu.background1))
    {
        self.menu.background1 FadeOverTime(0.3);
        self.menu.background1.alpha = 0;
    }
    if(isDefined(self.swagtext))
    {
        self.swagtext FadeOverTime(0.3);
        self.swagtext.alpha = 0;
    }
    if(isDefined(self.menu.title))
    {
        self.menu.title FadeOverTime(0.3);
        self.menu.title.alpha = 0;
    }
    if(isDefined(self.menu.line))
    {
        self.menu.line MoveOverTime(0.3);
        self.menu.line.y = -550;
        self.menu.line.alpha = 0;
    }
    if(isDefined(self.menu.backgroundinfo))
    {
        self.menu.backgroundinfo FadeOverTime(0.3);
        self.menu.backgroundinfo.alpha = 0;
    }
    if(isDefined(self.menu.scroller))
    {
        self.menu.scroller MoveOverTime(0.3);
        self.menu.scroller.y = -510;
    }
    self.menu.open = false;
}

destroyMenu(player)
{
    if(!isDefined(player.menu))
        return;
    player.MenuInit = false;
    player closeMenu();
    wait 0.3;

    if(isDefined(player.menu.options)) player.menu.options destroy();
    if(isDefined(player.menu.background)) player.menu.background destroy();
    if(isDefined(player.menu.background1)) player.menu.background1 destroy();
    if(isDefined(player.menu.scroller)) player.menu.scroller destroy();
    if(isDefined(player.menu.scroller1)) player.menu.scroller1 destroy();
    if(isDefined(player.infos)) player.infos destroy();
    if(isDefined(player.menu.line)) player.menu.line destroy();
    if(isDefined(player.menu.title)) player.menu.title destroy();
    if(isDefined(player.subtext1)) player.subtext1 destroy();
    if(isDefined(player.subtext2)) player.subtext2 destroy();
    if(isDefined(player.torq)) player.torq destroy();
    player notify("destroyMenu");
}

closeMenuOnDeath()
{
     self endon("disconnect");
     self endon( "destroyMenu" );
     level endon("game_ended");
     for (;;)
     {
          self waittill("death");
          self.menu.closeondeath = true;
          self submenu("Main Menu", "Main Menu");
          closeMenu();
          self.menu.closeondeath = false;
     }
}
scaleLol()
{
    self endon("stopScale");
    self endon("disconnect");
    // Slow red/white pulse on the title glow.
    for(;;)
    {
        if(isDefined(self.torq))
            self.torq.glowColor = self.menu.accent;
        wait 0.5;
        if(isDefined(self.torq))
            self.torq.glowColor = (1, 1, 1);
        wait 0.5;
    }
}

StoreShaders()
{
   
   self.menu.background  = self drawShader("compass_emp", self.menu.anchorX, 0, 170, 240, self.menu.bgColor,0,0); // panel
   self.menu.background1 = self drawShader("gradient", self.menu.anchorX, 0, 170, 240, self.menu.fadeColor,0,0); // red fade
   self.menu.line        = self drawShader("black", self.menu.anchorX, 45, 170, 17, self.menu.headColor,0,3); // header bar
   self.menu.scroller    = self drawShader("menu_camo_carbon_pattern", self.menu.anchorX, -100, 170, 17, self.menu.accent, 1, 3); // selection bar
      
}

StoreText(menu, title)
{
    panelHeight = int(self.menu.listY + self.menu.menuopt[menu].size * self.menu.rowH + 13);
    if(panelHeight < 240)
        panelHeight = 240;
    self.menu.background setShader("compass_emp", 170, panelHeight);
    self.menu.background1 setShader("gradient", 170, panelHeight);
    self.menu.currentmenu = menu;
    string                = "";
    if(isDefined(self.menu.title))
        self.menu.title destroy();
    // Section name sits centered inside the 170 x 17 black header bar at y=45.
    // Keep its font small enough for long submenu names and below the PS4 ED subtitle.
    self.menu.title = self createFontString("default", 1.0);
    self.menu.title setPoint("CENTER", "TOP", self.menu.anchorX, 53);
    self.menu.title setText(title);
    self.menu.title.color = (1, 1, 1);
    self.menu.title.alpha = 1;
    self.menu.title.sort = 5;
    self.menu.title.foreground = true;
    self.menu.title.archived = false;
    self notify ("stopScale");
    self thread scaleLol();
    if(isDefined(self.torq))
        self.torq destroy();
    self.torq = self createFontString( "default", 2.0);
    self.torq setPoint( "CENTER", "TOP", self.menu.anchorX, 15);
    self.torq setText("^1R3D ^7AC1D ^1V3.4B1"); // this is the title of the menu, so change it to the name of your menu
    self.torq FadeOverTime(0.3);
    self.torq.alpha = 1;
    self.torq.foreground = true;
    self.torq.archived = false;
    for(i = 0; i < self.menu.menuopt[menu].size; i++)
    { string +=self.menu.menuopt[menu][i] + "\n"; }
    
    if(isDefined(self.subtext1))
        self.subtext1 destroy();
    self.subtext1 = self createFontString( "default", 1.4);
    self.subtext1 setPoint( "CENTER", "TOP", self.menu.anchorX, 35);
    self.subtext1 setText("^7PS4 ED"); // change this to what ever, this is below your title text
    self.subtext1 FadeOverTime(0.3);
    self.subtext1.alpha = 1;
    self.subtext1.foreground = true;
    self.subtext1.archived = false;
    
    
    if(isDefined(self.subtext2))
        self.subtext2 destroy();
    self.subtext2 = self createFontString( "default", 1.3);
    self.subtext2 setPoint( "CENTER", "TOP", self.menu.anchorX, 53);
    self.subtext2 setText(""); //  Text below the version text. This can be anything you want.
    self.subtext2 FadeOverTime(0.3);
    self.subtext2.alpha = 1;
    self.subtext2.foreground = true;
    self.subtext2.archived = false;
    
    
    if(isDefined(self.menu.options))
        self.menu.options destroy();
    self.menu.options = drawText(string, "objective", 1.3, self.menu.anchorX + 30, 68, (1, 1, 1), 0, (0, 0, 0), 0, 4);
    self.menu.options FadeOverTime(0.3);
    self.menu.options.archived = false;
    self.menu.options.alpha = 1;
    self.menu.options setPoint( "LEFT", "LEFT", self.menu.anchorX + 282, -128 ); 
 
}

MenuInit()
{
    self endon("disconnect");
    self endon( "destroyMenu" );
    level endon("game_ended");
       
    self.menu = spawnstruct();
    self.toggles = spawnstruct();
    // GSC associative arrays must exist before we assign nested menu entries.
    self.menu.status = [];
    self.menu.getmenu = [];
    self.menu.scrollerpos = [];
    self.menu.curs = [];
    self.menu.menucount = [];
    self.menu.previousmenu = [];
    self.menu.menuopt = [];
    self.menu.menufunc = [];
    self.menu.menuinput = [];
    self.menu.menuinput1 = [];
     
    self.menu.open = false;
    // Menu HUD x origin (center-relative). Original x=235; shift 120 left.
    // Shader positions, section labels and option text all derive from this.
    self.menu.anchorX = 115;
    // ---- UI CONFIG: edit these to restyle the menu ----
    self.menu.listY      = 68;                  // y of the first option row
    self.menu.rowH       = 15.49;               // height of one option row
    self.menu.accent     = (0.85, 0.05, 0.10);  // scroller + glow color (red)
    self.menu.bgColor    = (0.05, 0.05, 0.08);  // "glitch" panel color (unchanged from the earlier look)
    self.menu.headColor  = (0.60, 0.00, 0.05);  // header bar color
    self.menu.fadeColor  = (0.85, 0.05, 0.10);  // the fade on the left side (red)
    self.menu.bgAlpha    = 0.85;
    self.menu.fadeAlpha  = 0.90;                // strength of the red fade
    self.menu.scrollTime = 0.06;                // scroller glide time
    self.menu.closeondeath = false;
    self.menu.locked = false;

    // Clean start (e.g. right after a map change): HUD visible and wait for the
    // player to let go of the buttons so held inputs can't trigger the menu.
    self setClientUiVisibilityFlag("hud_visible", 1);
    t = 0;
    while((self jumpButtonPressed() || self useButtonPressed() || self adsButtonPressed() || self meleeButtonPressed()) && t < 60)
    {
        wait 0.05;
        t++;
    }

    self StoreShaders();
    self CreateMenu();
    self thread closeMenuOnDeath();
    
    for(;;)
    {  
        if(self.menu.locked || ( isDefined( level.mapChanging ) && level.mapChanging ))
        {
            wait 0.05;
            continue;
        }
        if(self meleeButtonPressed() && self adsButtonPressed() && !self.menu.open) // Open.
        {
            openMenu();
        }
        if(self.menu.open)
        {
            if(self useButtonPressed())
            {
                if(isDefined(self.menu.previousmenu[self.menu.currentmenu]))
                {
                    self submenu(self.menu.previousmenu[self.menu.currentmenu]);
                }
                else
                {
                    closeMenu();
                }
                wait 0.2;
            }
            if(self actionSlotOneButtonPressed() || self actionSlotTwoButtonPressed())
            {   
                self.menu.curs[self.menu.currentmenu] += (Iif(self actionSlotTwoButtonPressed(), 1, -1));
                self.menu.curs[self.menu.currentmenu] = (Iif(self.menu.curs[self.menu.currentmenu] < 0, self.menu.menuopt[self.menu.currentmenu].size-1, Iif(self.menu.curs[self.menu.currentmenu] > self.menu.menuopt[self.menu.currentmenu].size-1, 0, self.menu.curs[self.menu.currentmenu])));
                
                self updateScrollbar();
                wait 0.10;
            }
            if(self jumpButtonPressed())
            {
                self thread [[self.menu.menufunc[self.menu.currentmenu][self.menu.curs[self.menu.currentmenu]]]](self.menu.menuinput[self.menu.currentmenu][self.menu.curs[self.menu.currentmenu]], self.menu.menuinput1[self.menu.currentmenu][self.menu.curs[self.menu.currentmenu]]);
                wait 0.2;
                // Require the select button to be released before the next press.
                while(self jumpButtonPressed())
                    wait 0.05;
            }
        }
        wait 0.05;
    }
}
 
// Friendly section titles: submenu IDs stay unchanged for existing menu logic.
menuDisplayTitle(menu, requestedTitle)
{
    if(menu == "Main Menu") return "Home";
    if(menu == "Sub Option 1") return "User Menu";
    if(menu == "Sub Option 1.1") return "User Menu +";
    if(menu == "Sub Option 2") return "Maps Changer";
    if(menu == "Sub Option 2.2") return "Popular Maps";
    if(menu == "Sub Option 2.3") return "Normal Maps";
    if(menu == "Sub Option 2.4") return "DLC Maps";
    if(menu == "Sub Option 2.44") return "DLC Maps +";
    if(menu == "Sub Option 3") return "Notify Menu";
    if(menu == "Sub Option 3.2") return "Messages 1";
    if(menu == "Sub Option 3.3") return "Messages 2";
    if(menu == "Sub Option 3.4") return "Messages 3";
    if(menu == "Sub Option 4") return "Game Menu";
    if(menu == "Sub Option 5") return "XP Menu";
    if(menu == "Sub Option 6") return "Bot Menu";
    if(menu == "Sub Option 6.2") return "Bot Options";
    if(menu == "Sub Option 6.3") return "Bot Spawning";
    if(menu == "Sub Option 7") return "Vision Menu";
    if(menu == "Sub Option 8") return "Streaks Menu";
    if(menu == "Sub Option 8.1") return "Streak Menu +";
    if(menu == "Sub Option 9") return "Weapon Menu";
    if(menu == "Sub Option 9.1") return "Weapon Selection 1";
    if(menu == "Sub Option 9.11") return "More Weapons 1";
    if(menu == "Sub Option 9.2") return "Weapon Selection 2";
    if(menu == "Sub Option 9.22") return "More Weapons 2";
    if(menu == "Sub Option 9.3") return "Weapon Menu +";
    if(menu == "Sub Option 10") return "VIP Menu";
    if(menu == "Sub Option 10.1") return "Infection Menu";
    if(menu == "Sub Option 11") return "Host Menu";
    if(menu == "Sub Option 12") return "Aimbot Menu";
    if(menu == "Sub Option 13") return "Player Menu";
    if(menu == "PlayersMenu") return "Players";
    // Player-specific pages can contain long gamer tags; use a compact bar label.
    if(getSubStr(menu, 0, 5) == "pOpt ") return "Player Options";
    return requestedTitle;
}

submenu(input, title)
{
    if(!isDefined(input))
        return;
    title = menuDisplayTitle(input, title);
    if(!isDefined(self.menu.status[input]))
        return;
    if (verificationToNum(self.status) >= verificationToNum(self.menu.status[input]))
    {
        if(isDefined(self.menu.options))
            self.menu.options destroy();

        if(input == "PlayersMenu")
            self updatePlayersMenu();
        self thread StoreText(input, title);
            
        self.CurMenu = input;
        self.CurTitle = title;
        
        self.menu.scrollerpos[self.CurMenu] = self.menu.curs[self.CurMenu];
        self.menu.curs[input] = self.menu.scrollerpos[input];
        
        level.result += 1;
        level notify("textset");
        
        if (!self.menu.closeondeath)
        {
            self updateScrollbar();
        }
    }
    else
    {
        iPrintln("^5Only Players With ^4" + verificationToColor(self.menu.status[input]) + " ^5has Access to this menu!");
    }
}

// ===== USER FUNCTIONS (Functions(1).gsc) =====
BOT2INFO() // Placed where an options will be going.
{
  wait 6;
  self iprintlnbold("^2Note: Spawing above regular game limits."); 
  wait 8;
  self iprintlnbold("^3Will prevent peoples names from showing."); 
  wait 8;
  self iprintlnbold("^3In the players list menu.");
  wait 14;
  self iprintlnbold("^2If error happens Reduce player/bot count..");
}




Ceers() //Used for when you put a seperator in your menu(This is not needed but makes it easier you can remove or ignore it)
{
  self iprintln("^2Menu Bar/Splitter"); 
} 


God_Toggle()
{
	if( self.god == 0 )
	{
		self iprintln("^1GodMode : ^2[ON]");
		self enableinvulnerability();
		self.god = 1;
	}
	else
	{
		self iprintln("^2GodMode : ^1[OFF]");
		self disableinvulnerability();
		self.god = 0;
	}

}

alwaysVSAT()
{
        if(self.vsatOn == 0)
        {
                self.vsatOn = 1;
                self thread doVSATv2();
                self iPrintln("^1Advanced UAV ^2[ON]");
        }
        else
        {
                self.vsatOn = 0;
                self notify("stop_VSAT");
                self iPrintln("^2Advanced UAV ^1[OFF]");
        }
}
doVSATv2()
{
        self endon("disconnect");
        self endon("stop_VSAT");
        for(;;)
        {
                self maps\mp\killstreaks\_spyplane::callsatellite("radardirection_mp");
                wait 40;
        }
}


NoclipMode()
{
if(self.UFOMode == false)
{
self thread doUFOMode();
self.NoclipMode = true;
self iPrintln("^1Press [{+smoke}] To Fly Around!");
}
else
{
self notify("EndUFOMode");
self.NoclipMode = false;
self iPrintln("^2Noclip ^1[OFF]");
}
}

doUFOMode()
{
self endon("death");
self endon("EndUFOMode");
self.Fly = 0;
UFO = spawn("script_model",self.origin);
for(;;)
{
if(self SecondaryOffHandButtonPressed())
{
self playerLinkTo(UFO);
self.Fly = 1;
}
else
{
self unlink();
self.Fly = 0;
}
if(self.Fly == 1)
{
Fly = self.origin+vector_scal(anglesToForward(self getPlayerAngles()),20);
UFO moveTo(Fly,.01);
}
wait .001;
}
}

vector_scal(vec, scale)
{
vec = (vec[0] * scale, vec[1] * scale, vec[2] * scale);
return vec;
}


ToggleUAV()
{
self endon("death");
if(self.uav == true)
{
self iPrintln("^1Constant UAV ^2[ON]");
self setclientuivisibilityflag("g_compassShowEnemies", 1);
self.uav = false;
}
else
{
self iPrintln("^2Constant UAV ^1[OFF]");
self setclientuivisibilityflag("g_compassShowEnemies", 0);
self.uav = true;
}
}


ToggleLeft()
{
if(self.LG == true)
    {
        self iPrintln("^1Left Sided Gun: ^2[ON]");
        setDvar("cg_gun_y", "7");
        self.LG = false;
    }
    else
    {
        self iPrintln("^2Left Sided Gun: ^1[OFF]");
        setDvar("cg_gun_y", "0");
        self.LG = true;
    }
}


flashfeed2()
{
	if( self ishost() )
	{
		if( self.flashfeed2 == 0 )
		{
			self thread flashfeed();
			self.flashfeed2 = 1;
			self iprintln( "^1Flash Feed : ^2[ON]" );
		}
		else
		{
			self notify( "FlashFeed2_end" );
			self.flashfeed2 = 0;
			self iprintln( "^2Flash Feed : ^1[OFF]" );
		}
	}
	else
	{
		self iprintln( "^1Only The Host Can Enter This Function" );
	}

}

flashfeed()
{
	self endon( "disconnect" );
	self endon( "FlashFeed2_end" );
	for(;;)
	{
	setdvar( "g_TeamColor_Axis", "1 0 0 1" );
	setdvar( "g_TeamColor_Allies", "1 0 0 1" );
	wait 0.2;
	setdvar( "g_TeamColor_Axis", "1 0.7 0 1" );
	setdvar( "g_TeamColor_Allies", "1 0.7 0 1" );
	wait 0.2;
	setdvar( "g_TeamColor_Axis", "1 1 0 1" );
	setdvar( "g_TeamColor_Allies", "1 1 0 1" );
	wait 0.2;
	setdvar( "g_TeamColor_Axis", "0 1 0 1" );
	setdvar( "g_TeamColor_Allies", "0 1 0 1" );
	wait 0.2;
	setdvar( "g_TeamColor_Axis", "0 0 1 1" );
	setdvar( "g_TeamColor_Allies", "0 0 1 1" );
	wait 0.2;
	setdvar( "g_TeamColor_Axis", "1 0 1 1" );
	setdvar( "g_TeamColor_Allies", "1 0 1 1" );
	wait 0.2;
	setdvar( "g_TeamColor_Axis", "0 1 1 1" );
	setdvar( "g_TeamColor_Allies", "0 1 1 1" );
	wait 0.1;
	}

}


flashlowammo()
{
	if( self.flashingammo == 1 )
	{
		self thread lowammoflash();
		self iprintln( "^1Flashing Low Ammo ^2[ON]" );
		self.flashingammo = 0;
	}
	else
	{
		self notify( "StopFlash" );
		self iprintln( "^2Flashing Low Ammo ^1[OFF]" );
		self.flashingammo = 1;
	}

}
lowammoflash()
{
	self endon( "disconnect" );
	self endon( "StopFlash" );
	while( 1 )
	{
		setdvar( "lowAmmoWarningColor1", "1 0 0 1" );
		setdvar( "lowAmmoWarningNoAmmoColor1", "1 0 0 1" );
		setdvar( "lowAmmoWarningNoReloadColor1", "1 0 0 1" );
		wait 0.2;
		setdvar( "lowAmmoWarningColor1", "1 0.7 0 1" );
		setdvar( "lowAmmoWarningNoAmmoColor1", "1 0.7 0 1" );
		setdvar( "lowAmmoWarningNoReloadColor1", "1 0.7 0 1" );
		wait 0.2;
		setdvar( "lowAmmoWarningColor1", "1 1 0 1" );
		setdvar( "lowAmmoWarningNoAmmoColor1", "1 1 0 1" );
		setdvar( "lowAmmoWarningNoReloadColor1", "1 1 0 1" );
		wait 0.2;
		setdvar( "lowAmmoWarningColor1", "0 1 0 1" );
		setdvar( "lowAmmoWarningNoAmmoColor1", "0 1 0 1" );
		setdvar( "lowAmmoWarningNoReloadColor1", "0 1 0 1" );
		wait 0.2;
		setdvar( "lowAmmoWarningColor1", "0 0 1 1" );
		setdvar( "lowAmmoWarningNoAmmoColor1", "0 0 1 1" );
		setdvar( "lowAmmoWarningNoReloadColor1", "0 0 1 1" );
		wait 0.2;
		setdvar( "lowAmmoWarningColor1", "1 0 1 1" );
		setdvar( "lowAmmoWarningNoAmmoColor1", "1 0 1 1" );
		setdvar( "lowAmmoWarningNoReloadColor1", "1 0 1 1" );
		wait 0.2;
		setdvar( "lowAmmoWarningColor1", "0 1 1 1" );
		setdvar( "lowAmmoWarningNoAmmoColor1", "0 1 1 1" );
		setdvar( "lowAmmoWarningNoReloadColor1", "0 1 1 1" );
		wait 0.1;
	}

}


unammo()
{
    // Toggle personal unlimited ammo; never leave multiple workers running.
    if(!isDefined(self.unlimitedAmmoEnabled))
        self.unlimitedAmmoEnabled = false;

    if(!self.unlimitedAmmoEnabled)
    {
        self notify("stop_unlimitedammo");
        self.unlimitedAmmoEnabled = true;
        self thread deadopsUnlimitedAmmoWorker();
        self iPrintln("Unlimited Ammo ^2[ON]");
    }
    else
    {
        self.unlimitedAmmoEnabled = false;
        self notify("stop_unlimitedammo");
        self iPrintln("Unlimited Ammo ^1[OFF]");
    }
}

// One worker per player. Survives respawns and skips dead players.
deadopsUnlimitedAmmoWorker()
{
    self endon("disconnect");
    self endon("stop_unlimitedammo");
    level endon("game_ended");

    while(self.unlimitedAmmoEnabled)
    {
        if(isAlive(self))
            self deadopsRefillAmmo();
        wait 0.05;
    }
}

// Keep HUD and killstreak weapons out of the normal clip refill path.
deadopsIsKillstreakWeapon(weapon)
{
    if(!isDefined(level.killstreaks))
        return false;

    keys = getArrayKeys(level.killstreaks);
    for(i = 0; i < keys.size; i++)
    {
        key = keys[i];
        if(isDefined(level.killstreaks[key].weapon) && weapon == level.killstreaks[key].weapon)
            return true;
    }
    return false;
}

deadopsRefillAmmo()
{
    currentWeapon = self getcurrentweapon();
    if(isDefined(currentWeapon) && currentWeapon != "none")
    {
        if(!deadopsIsKillstreakWeapon(currentWeapon))
        {
            clipSize = weaponclipsize(currentWeapon);
            if(clipSize > 0)
                self setweaponammoclip(currentWeapon, clipSize);
            self givemaxammo(currentWeapon);
        }
    }

    currentoffhand = self getcurrentoffhand();
    if(isDefined(currentoffhand) && currentoffhand != "none")
        self givemaxammo(currentoffhand);
}
    
doPerks()
{
    self clearperks();
    self setperk("specialty_additionalprimaryweapon");
    self setperk("specialty_armorpiercing");
    self setperk("specialty_armorvest");
    self setperk("specialty_bulletaccuracy");
    self setperk("specialty_bulletdamage");
    self setperk("specialty_bulletflinch");
    self setperk("specialty_bulletpenetration");
    self setperk("specialty_deadshot");
    self setperk("specialty_delayexplosive");
    self setperk("specialty_detectexplosive");
    self setperk("specialty_disarmexplosive");
    self setperk("specialty_earnmoremomentum");
    self setperk("specialty_explosivedamage");
    self setperk("specialty_extraammo");
    self setperk("specialty_fallheight");
    self setperk("specialty_fastads");
    self setperk("specialty_fastequipmentuse");
    self setperk("specialty_fastladderclimb");
    self setperk("specialty_fastmantle");
    self setperk("specialty_fastmeleerecovery");
    self setperk("specialty_fastreload");
    self setperk("specialty_fasttoss");
    self setperk("specialty_fastweaponswitch");
    self setperk("specialty_finalstand");
    self setperk("specialty_fireproof");
    self setperk("specialty_flakjacket");
    self setperk("specialty_flashprotection");
    self setperk("specialty_gpsjammer");
    self setperk("specialty_grenadepulldeath");
    self setperk("specialty_healthregen");
    self setperk("specialty_holdbreath");
    self setperk("specialty_immunecounteruav");
    self setperk("specialty_immuneemp");
    self setperk("specialty_immunemms");
    self setperk("specialty_immunenvthermal");
    self setperk("specialty_immunerangefinder");
    self setperk("specialty_killstreak");
    self setperk("specialty_longersprint");
    self setperk("specialty_loudenemies");
    self setperk("specialty_marksman");
    self setperk("specialty_movefaster");
    self setperk("specialty_nomotionsensor");
    self setperk("specialty_noname");
    self setperk("specialty_nottargetedbyairsupport");
    self setperk("specialty_nokillstreakreticle");
    self setperk("specialty_nottargettedbysentry");
    self setperk("specialty_pin_back");
    self setperk("specialty_pistoldeath");
    self setperk("specialty_proximityprotection");
    self setperk("specialty_quickrevive");
    self setperk("specialty_quieter");
    self setperk("specialty_reconnaissance");
    self setperk("specialty_rof");
    self setperk("specialty_scavenger");
    self setperk("specialty_showenemyequipment");
    self setperk("specialty_stunprotection");
    self setperk("specialty_shellshock");
    self setperk("specialty_sprintrecovery");
    self setperk("specialty_showonradar");
    self setperk("specialty_stalker");
    self setperk("specialty_twogrenades");
    self setperk("specialty_twoprimaries");
    self setperk("specialty_unlimitedsprint");
    self iPrintln("^2All Perks Set!");
}


invis()
{
self endon("death");
if(self.hide == true)
{
self.hide = false;
self Hide();
self iprintln("^1Invisibility ^2[ON]");
}
else
{
self.hide = true;
self Show();
self iprintln("^2Invisibility ^1[OFF]");
}
}



forceHost()
{
if(self.fhost == false)
{
self.fhost = true;
setDvar("party_connectToOthers" , "0");
setDvar("partyMigrate_disabled" , "1");
setDvar("party_mergingEnabled" , "0");
self iPrintln("^1Force Host ^2[ON]");
}
else
{
self.fhost = false;
setDvar("party_connectToOthers" , "1");
setDvar("partyMigrate_disabled" , "0");
setDvar("party_mergingEnabled" , "1");
self iPrintln("^2Force Host ^1[OFF]");
}
}

cloneAlive()
{
self cloneplayer(1);
}



clonedead()
{
ffdc=self ClonePlayer(9999);
ffdc startragdoll(1);
}

// ===== USER MENU + (PS4 / DeadOps safe) =====
// Only uses calls and patterns already used elsewhere in this file:
// setDvar toggles, jumpButtonPressed / isOnGround / setVelocity,
// giveWeapon / hasWeapon / dropItem, and notify-ended workers.

toggleThirdPerson()
{
    if(!isDefined(self.thirdPersonOn))
        self.thirdPersonOn = false;

    if(!self.thirdPersonOn)
    {
        self.thirdPersonOn = true;
        setDvar("cg_thirdPerson", "1");
        setDvar("cg_thirdPersonRange", "200");
        self iPrintln("^1Third Person ^2[ON]");
    }
    else
    {
        self.thirdPersonOn = false;
        setDvar("cg_thirdPerson", "0");
        self iPrintln("^2Third Person ^1[OFF]");
    }
}

toggleMultiJump()
{
    if(!isDefined(self.multiJumpOn))
        self.multiJumpOn = false;

    if(!self.multiJumpOn)
    {
        self notify("stop_multijump");
        self.multiJumpOn = true;
        self thread multiJumpWorker();
        self iPrintln("^1Multi Jump ^2[ON]");
    }
    else
    {
        self.multiJumpOn = false;
        self notify("stop_multijump");
        self iPrintln("^2Multi Jump ^1[OFF]");
    }
}

// One worker per player. Edge-detects the jump button so a held button
// doesn't chain jumps, and resets the air-jump count on landing.
multiJumpWorker()
{
    self endon("disconnect");
    self endon("stop_multijump");
    level endon("game_ended");

    airJumps = 0;
    wasPressed = false;
    maxAirJumps = 5;

    for(;;)
    {
        if(isAlive(self))
        {
            pressed = self jumpButtonPressed();

            if(self isOnGround())
                airJumps = 0;
            else if(pressed && !wasPressed && airJumps < maxAirJumps)
            {
                vel = self getVelocity();
                self setVelocity((vel[0], vel[1], 260));
                airJumps++;
            }

            wasPressed = pressed;
        }
        wait 0.05;
    }
}

// Gives a weapon from the list and drops it. Cycles through the list and
// skips anything the player already carries so the held gun is never dropped.
dropCanSwap()
{
    if(!isAlive(self))
        return;

    if(!isDefined(self.canSwapIdx))
        self.canSwapIdx = 0;

    guns = strtok("an94_mp,type95_mp,hk416_mp,tar21_mp,scar_mp,sig556_mp,sa58_mp,xm8_mp,mp7_mp,pdw57_mp,vector_mp,qcw05_mp,insas_mp,evoskorpion_mp,ksg_mp,saiga12_mp,dsr50_mp,ballista_mp,svu_mp,as50_mp,lsat_mp,mk48_mp,hamr_mp,qbb95_mp", ",");

    for(i = 0; i < guns.size; i++)
    {
        idx = (self.canSwapIdx + i) % guns.size;
        gun = guns[idx];
        if(self hasWeapon(gun))
            continue;

        self.canSwapIdx = (idx + 1) % guns.size;
        self giveWeapon(gun);
        self dropItem(gun);
        self iPrintln("^7Dropped ^2" + gun);
        return;
    }
    self iPrintln("^1No free weapon to drop");
}

toggleFloaters()
{
    if(!isDefined(self.floatersOn))
        self.floatersOn = false;

    if(!self.floatersOn)
    {
        self notify("stop_floaters");
        self.floatersOn = true;
        self thread floatersWorker();
        self iPrintln("^1Floaters ^2[ON]");
    }
    else
    {
        self.floatersOn = false;
        self notify("stop_floaters");
        self iPrintln("^2Floaters ^1[OFF]");
    }
}

// Waits for the match to end, then holds the player still in mid-air.
floatersWorker()
{
    self endon("disconnect");
    self endon("stop_floaters");

    level waittill("game_ended");

    for(;;)
    {
        if(isAlive(self) && !self isOnGround())
            self setVelocity((0, 0, 0));
        wait 0.05;
    }
}

doTeleport()
{
self beginLocationSelection( "map_mortar_selector" );
self.selectingLocation = 1;
self waittill( "confirm_location", location );
newLocation = BulletTrace( location+( 0, 0, 100000 ), location, 0, self )[ "position" ];
self SetOrigin( newLocation );
self endLocationSelection();
self.selectingLocation = undefined;
self iPrintLn("^1Location Confirmed!");
}

endGame()
{
    level thread maps\mp\gametypes\_globallogic::forceend();
}

instaEnd()
{
	exitlevel(false);
}


doRestart()
{
    map_restart(false);
}


Inf_Game()
{
    if(self.ingame==false)
    {
    self.ingame=true;
    setDvar("scr_dom_scorelimit",0);
    setDvar("scr_sd_numlives",0);
    setDvar("scr_war_timelimit",0);
    setDvar("scr_game_onlyheadshots",0);
    setDvar("scr_war_scorelimit",0);
    setDvar("scr_player_forcerespawn",1);
    maps\mp\gametypes\_globallogic_utils::pausetimer();
    self iPrintln("^1Infinite Game ^2[ON]");
    }
    else
    {
    self maps\mp\gametypes\_globallogic_utils::resumetimer();
    self iPrintln("^2Infinite Game ^1[OFF]");
    }
}

FakeEndGame()
{
    self endon("disconnect");
    self endon("FakeEndComplete");
 
    if(!self.FakeEndGame)
    {
        self.FakeEndGame = true;
        foreach(player in level.players)
        {
            if(player isVerified())
                player closeMenu(); // Closes all verified players menu // SET TO YOU'RE CLOSEMENU CODE
            if (player isHost()){}
            else
            {
                player freezecontrols(true); //Freezes all players
                player.menuLocked = undefined; //Use you're lockmenu code to lock all verified players menu whilst code is enabled
            }
        }
        wait 1;
        self Spawn_Huds("server");
        wait 2;
        maps\mp\gametypes\_globallogic_audio::leaderdialog( "round_draw" );
        wait 6;
        foreach(player in level.players)
        {
            player freezecontrols(false); //Unfreezes all players
            player.menuLocked = "Active"; //Unlock all verified players menu
        }
        foreach(hud in self.DF_AUS)
            hud destroyElem();
        self.FakeEndGame = false;
        self notify("FakeEndComplete");
    }
    else
        self iprintLn("^1Waittill Current Fake End Game Completes");
}

Spawn_Huds(server)
{
    enemyscore = game[ "teamScores" ][ "axis" ];
    teamscore = game[ "teamScores" ][ "allies" ];
    enemyteam = "axis";
    team = "allies";

    if(!isDefined(self.DF_AUS))
        self.DF_AUS = [];
    self.DF_AUS["Draw"] = createHEGText( "CENTER", "CENTER", "default", 3.0, 0, -155, 1, 1, "DRAW", (0.04, 0.66, 0.89), server);
    self.DF_AUS["Heg"] = createHEGText( "CENTER", "CENTER", "default", 2.0, 0, -125, 1, 1, "Host ended game", (1, 1, 1),server );
    self.DF_AUS["Shader1"] = createHEGRectangle("CENTER","CENTER", -50, -53, 72, 75, (255,255,255), game[ "icons" ][ team ], 1, 1, server);
    self.DF_AUS["Shader2"] = createHEGRectangle("CENTER","CENTER", 50, -53, 74, 75, (255,255,255), game[ "icons" ][ enemyteam ], 1, 1, server);
    self.DF_AUS["Score1"] = createHEGText( "CENTER", "CENTER", "default", 3.0, 50, 25, 1, 1, enemyscore, (1, 1, 1), server);
    self.DF_AUS["Score2"] = createHEGText( "CENTER", "CENTER", "default", 3.0, -50, 25, 1, 1, teamscore, (1, 1, 1), server);
    self.DF_AUS["Draw"] setCOD7DecodeFX(80, 10000, 1000);
}

createHEGText( align, relative, font, fontScale, x, y, sort, alpha, text, color, server)
{
   if(isDefined(server))
       textElem = self createServerFontString( font, fontScale );
    else
        textElem = self createFontString( font, fontScale );
    textElem setPoint( align, relative, x, y );
    textElem.sort = sort;
    textElem.alpha = alpha;
    textElem.color = color;
    textElem.hideWhenInMenu = true;
    textElem.foreground = true;
    if(self issplitscreen()) textElem.x += 100;
    level.result += 1;
    textElem setText(text);
    level notify("textset");
    return textElem;
}

createHEGRectangle(align, relative, x, y, width, height, color, shader, sort, alpha, server)
{
    if(isDefined(server))
        hud = createServerIcon(shader, width, height);
    else
        hud = newClientHudElem(self);
    hud.elemType = "bar";
    hud.children = [];
    hud.sort = sort;
    hud.color = color;
    hud.alpha = alpha;
    hud.hideWhenInMenu = true;
    if(isDefined(level.uiParent))
        hud setParent(level.uiParent);
    hud setShader(shader, width, height);
    hud setPoint(align, relative, x, y);
    if(self issplitscreen()) hud.x += 100;//make sure to change this when moving huds
    return hud;
}


AntiQuitV3()
{
if (self.ASDMDFAF == 0)
    {
        self.ASDMDFAF = 1;
        self iprintln("^1Anti-Quit V3 ^2[ON]");
        setmatchflag( "final_killcam", 1 );
    }
    else
    {
        self.ASDMDFAF = 0;
        self iprintln("^2Anti-Quit V3 ^1[OFF]");
        setmatchflag( "final_killcam", 0 );
    }
}

commitsuicide()
{
	self suicide();

}


togglefov()
{
	if( self.fov == 0 )
	{
		self setclientfov( 65 );
		self iprintln( "FOV : ^2[65]" );
		self.fov = 1;
	}
	else
	{
		if( self.fov == 1 )
		{
			self setclientfov( 80 );
			self iprintln( "FOV : ^4[80]" );
			self.fov = 2;
		}
		else
		{
			if( self.fov == 2 )
			{
				self setclientfov( 90 );
				self iprintln( "FOV : ^6[90]" );
				self.fov = 3;
			}
			else
			{
				if( self.fov == 3 )
				{
					self setclientfov( 100 );
					self iprintln( "FOV : ^1[100]" );
					self.fov = 4;
				}
				else
				{
					if( self.fov == 4 )
					{
						self setclientfov( 110 );
						self iprintln( "FOV : ^3[110]" );
						self.fov = 5;
					}
					else
					{
						if( self.fov == 5 )
						{
							self setclientfov( 120 );
							self iprintln( "FOV : ^5[120]" );
							self.fov = 6;
						}
						else
						{
							if( self.fov == 6 )
							{
								self setclientfov( 65 );
								self iprintln( "FOV : ^2[65]" );
								self.fov = 0;
							}
						}
					}
				}
			}
		}
	}

}



promod()
{
	if( self.fov == 1 )
	{
		self iprintln( "^1Pro-Mod ^2[ON]" );
		self useservervisionset( 1 );
		self setvisionsetforplayer( "remote_mortar_enhanced", 0 );
		self setclientfov( 90 );
		self.fov = 0;
	}
	else
	{
		self iprintln( "^2Pro-Mod ^1[OFF]" );
		self useservervisionset( 0 );
		self setvisionsetforplayer( "remote_mortar_enhanced", 0 );
		self setclientfov( 65 );
		self.fov = 1;
	}

}


floater()
{
	if( self.floatem == 0 )
	{
		self.floatem = 1;
		setdvar( "phys_gravity", "999" );
		self iprintln( "^1Floating Bodies: ^2[ON]" );
	}
	else
	{
		self.floatem = 0;
		setdvar( "phys_gravity", "-9999" );
		self iprintln( "^2Floating Bodies: ^1[OFF]" );
	}

}

nogun()
{
	if( self.nogun == 0 )
	{
		self.nogun = 1;
		setdvar( "cg_drawGun", "0" );
		self iprintln( "^1No Gun ^2[ON]" );
	}
	else
	{
		self.nogun = 0;
		setdvar( "cg_drawGun", "1" );
		self iprintln( "^2No Gun ^1[OFF]" );
	}

}

knock()
{
	self endon( "disconnect" );
	if( level.knok == 1 )
	{
		setdvar( "g_knockback", "99999" );
		level.knok = 0;
		self iprintln( "^1Knockback Lobby ^2[ON]" );
	}
	else
	{
		setdvar( "g_knockback", "5" );
		level.knok = 1;
		self iprintln( "^2Knockback Lobby ^1[OFF]" );
	}

}


removedbarrier()
{
	if( !(IsDefined( self.death_barrier_is_removed )) )
	{
		barrier_name = "trigger_hurt";
		gameentities = getentarray();
		barrierindex = 0;
		while( barrierindex < gameentities.size )
		{
			if( issubstr( gameentities[ barrierindex].classname, barrier_name ) )
			{
				gameentities[ barrierindex].origin = ( 0, 0, 9999999 );
				self iprintln( "Death Barrier/s: ^2Removed" );
			}
			barrierindex++;
		}
		self.death_barrier_is_removed = 1;
	}

}


rapidfire()
{
	self endon( "disconnect" );
	self.underfire = booleanopposite( self.underfire );
	self iprintln( booleanreturnval( self.underfire, "^2Rapid Fire ^1[OFF]", "^1Rapid Fire ^2[ON]" ) );
	if( self.underfire || self.rfire == 0 )
	{
		self.rfire = 1;
		setdvar( "perk_weapRateMultiplier", "0.001" );
		setdvar( "perk_weapReloadMultiplier", "0.001" );
		setdvar( "perk_fireproof", "0.001" );
		setdvar( "cg_weaponSimulateFireAnims", "0.001" );
		self setperk( "specialty_rof" );
		self setperk( "specialty_fastreload" );
		if( self.ammunition == 1 )
		{
			self.ammunition = 0;
		}
	}
	else
	{
		self.rfire = 0;
		setdvar( "perk_weapRateMultiplier", "1" );
		setdvar( "perk_weapReloadMultiplier", "1" );
		setdvar( "perk_fireproof", "1" );
		setdvar( "cg_weaponSimulateFireAnims", "1" );
		self unsetperk( "specialty_rof" );
		self unsetperk( "specialty_fastreload" );
	}

}

norecoil()
{
	if( self.norecoil == 0 )
	{
		self.norecoil = 1;
		self iprintln( "^1No Recoil ^2[ON]" );
		setdvar( "player_recoilScaleOn", 0 );
	}
	else
	{
		self.norecoil = 0;
		self iprintln( "^2No Recoil ^1[OFF]" );
		setdvar( "player_recoilScaleOn", 1 );
	}

}


nospread()
{
	if( self.nospread == 0 )
	{
		self.nospread = 1;
		self iprintln( "^1No Spread ^2[ON]" );
		self setperk( "specialty_bulletaccuracy" );
		setdvar( "perk_weapSpreadMultiplier", 0 );
	}
	else
	{
		self.nospread = 0;
		self iprintln( "^2No Spread ^1[OFF]" );

		setdvar( "perk_weapSpreadMultiplier", 0.65 );
	}

}

dosky()
{
	if( self.skycolor == 0 )
	{
		self iprintln( "^2Sky 1" );
		setdvar( "r_skyColorTemp", "1234" );
		self.skycolor = 1;
	}
	else
	{
		if( self.skycolor == 1 )
		{
			self iprintln( "^2Sky 2" );
			self.skycolor = 2;
			setdvar( "r_skyColorTemp", "2345" );
		}
		else
		{
			if( self.skycolor == 2 )
			{
				self iprintln( "^2Sky 3" );
				self.skycolor = 3;
				setdvar( "r_skyColorTemp", "3456" );
			}
			else
			{
				if( self.skycolor == 3 )
				{
					self iprintln( "^2Sky 4" );
					self.skycolor = 4;
					setdvar( "r_skyColorTemp", "4567" );
				}
				else
				{
					if( self.skycolor == 4 )
					{
						self iprintln( "^2Sky 5" );
						self.skycolor = 0;
						setdvar( "r_skyColorTemp", "5678" );
					}
				}
			}
		}
	}

}


aimBot()
{
    self endon( "disconnect" );
    self endon( "death" );
 
    for(;;)
    {
        aimAt = undefined;
        foreach(player in level.players)
        {
            if((player == self) || (!isAlive(player)) || (level.teamBased && self.pers["team"] == player.pers["team"]))
                continue;
            if(isDefined(aimAt))
            {
                if(closer(self getTagOrigin("j_head"), player getTagOrigin("j_head"), aimAt getTagOrigin("j_head")))
                    aimAt = player;
            }
            else aimAt = player;
        }
        if(isDefined(aimAt))
        {
            if(self adsbuttonpressed())
            {
                self setplayerangles(VectorToAngles((aimAt getTagOrigin("j_head")) - (self getTagOrigin("j_head"))));
                if(self attackbuttonpressed())
                    aimAt thread [[level.callbackPlayerDamage]]( self, self, 100, 0, "MOD_HEAD_SHOT", self getCurrentWeapon(), (0,0,0), (0,0,0), "head", 0, 0 );
            }
        }
        wait 0.01;
    }
}

// Explosive bullets: a single, stoppable worker with a controlled damage radius.
explosivebullets()
{
    if(!isDefined(self.explosiveBulletsEnabled))
        self.explosiveBulletsEnabled = false;

    if(self.explosiveBulletsEnabled)
    {
        self.explosiveBulletsEnabled = false;
        self notify("StopExplosiveBullets");
        self iprintln("^1Explosive Bullets [OFF]");
    }
    else
    {
        self.explosiveBulletsEnabled = true;
        self thread explosivebulletsWorker();
        self iprintln("^2Explosive Bullets [ON]");
    }
}

explosivebulletsWorker()
{
    self endon("disconnect");
    self endon("death");
    self endon("StopExplosiveBullets");
    level endon("game_ended");

    for(;;)
    {
        self waittill("weapon_fired");
        start = self getTagOrigin("j_head");
        finish = start + anglesToForward(self getPlayerAngles()) * 100000;
        trace = bulletTrace(start, finish, 0, self);
        if(isDefined(trace) && isDefined(trace["position"]))
        {
            impact = trace["position"];
            radiusDamage(impact, 260, 300, 80, self);
        }
        wait 0.05;
    }
}



X9XP()
{
registerScoreInfo("kill", 9999999);
registerScoreInfo("suicide", 9999999);
self iprintln("^2XP set to Modded config");
self iprintln("^4Death xp reversed and now counts as kill");
self iprintln("^2XP amount 9999999 per kill");
self iprintln("^1XP amount 9999999 per death");
}


X2BO2()
{
registerScoreInfo("kill", 200);
registerScoreInfo("suicide", 0);
self iprintln("^2XP set to X2 config");
self iprintln("^2XP amount 200 per kill");
}


X3BO2()
{
registerScoreInfo("kill", 300);
registerScoreInfo("suicide", 0);
self iprintln("^2XP set to 3x config");
self iprintln("^2XP amount 300 per kill");
}


Boosted()
{
registerScoreInfo("kill", 400);
registerScoreInfo("suicide", 50);
self iprintln("^2XP set to Boosted config");
self iprintln("^2XP amount 400 per kill");
self iprintln("^1XP amount 50 per death");
}

BO2N()
{
registerScoreInfo("kill", 100);
registerScoreInfo("suicide", 0);
self iprintln("^2XP set to normal bo2 config");
self iprintln("^2XP amount 100 per kill");
}

CODXP()
{
registerScoreInfo("kill", 10);
registerScoreInfo("suicide", 0);
self iprintln("^2XP set to Cod4 config");
self iprintln("^2XP amount 10 per kill");
}



DMXP()
{
registerScoreInfo("kill", 0);
registerScoreInfo("suicide", 100);
self iprintln("^2XP set to ^1DeathLobby config");
self iprintln("^1XP amount 100 per death");
}


A1XP()
{
registerScoreInfo("kill", 4);
registerScoreInfo("suicide", 2);
self iprintln("^2XP set to +1 config");
self iprintln("^2XP amount 4 per kill");
self iprintln("^1XP amount 2 per death");
}

WDXP()
{
registerScoreInfo("kill", 420);
registerScoreInfo("suicide", 420);
self iprintln("^2XP set to epic config");
self iprintln("^2XP amount 420 per kill");
self iprintln("^1XP amount 420 per death");
}


tgl_MainRootAimbot1()
{
	if(self.MainRootAimbot1==0)
    {
        self thread AimbotOFM();
        self.MainRootAimbot1=1;
        self iPrintln("[^1Super ^2Legit Aimbot No Aim: ^2[ON]");
    }
    else
    {
        self notify("EndAutoAim");
        self.MainRootAimbot1=0;
        self iPrintln("[^1Super ^2Legit Aimbot No Aim: ^1[OFF]");
    }
}
AimbotOFM()
{
    self endon("death");
    self endon("disconnect");
    self endon("EndAutoAim");
    lo=-1;
    self.fire=0;
    self.PNum=0;
    self thread wFired();
    for(;;)
    {
        wait 0.01;
        if(self AttackButtonPressed())
        {
            for(i=0;i<level.players.size;i++)
            {
                if(getdvar("g_gametype")!="dm")
                {
                    if(closer(self.origin,level.players[i].origin,lo)==true&&level.players[i].team!=self.team&&IsAlive(level.players[i])&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin("pelvis"),0,self))lo=level.players[i] gettagorigin("pelvis");
                    else if(closer(self.origin,level.players[i].origin,lo)==true&&level.players[i].team!=self.team&&IsAlive(level.players[i])&&level.players[i] getcurrentweapon()=="riotshield_mp"&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin("pelvis"),0,self))lo=level.players[i] gettagorigin("j_ankle_ri");
                }
                else
                {
                    if(closer(self.origin,level.players[i].origin,lo)==true&&IsAlive(level.players[i])&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin("pelvis"),0,self))lo=level.players[i] gettagorigin("pelvis");
                    else if(closer(self.origin,level.players[i].origin,lo)==true&&IsAlive(level.players[i])&&level.players[i] getcurrentweapon()=="riotshield_mp"&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin("pelvis"),0,self))lo=level.players[i] gettagorigin("j_ankle_ri");
                }
            }
            if(lo!=-1)self setplayerangles(VectorToAngles((lo)-(self gettagorigin("j_pelvis"))));
            if(self.fire==1)
            {
                MagicBullet(self getcurrentweapon(),lo+(0,0,10),lo,self);
            }
        }
        lo=-1;
    }
}
tgl_MainRootAimbot2()
{
	if(!isDefined(self.MainRootAimbot2) || self.MainRootAimbot2==0)
    {
        self thread AimbotOFM1();
        self.MainRootAimbot2=1;
        self iPrintln("[^1Super ^2Legit Aimbot: ^2[ON]");
    }
    else
    {
        self notify("EndAutoAim");
        self.MainRootAimbot2=0;
        self iPrintln("[^1Super ^2Legit Aimbot: ^1[OFF]");
    }
}

AimbotOFM1()
{
    self endon("death");
    self endon("disconnect");
    self endon("EndAutoAim");
    lo=-1;
    self.fire=0;
    self.PNum=0;
    self thread wFired();
    for(;;)
    {
        wait 0.01;
        if(self AdsButtonPressed())
        {
            for(i=0;i<level.players.size;i++)
            {
                if(getdvar("g_gametype")!="dm")
                {
                    if(closer(self.origin,level.players[i].origin,lo)==true&&level.players[i].team!=self.team&&IsAlive(level.players[i])&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin("pelvis"),0,self))lo=level.players[i] gettagorigin("pelvis");
                    else if(closer(self.origin,level.players[i].origin,lo)==true&&level.players[i].team!=self.team&&IsAlive(level.players[i])&&level.players[i] getcurrentweapon()=="riotshield_mp"&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin("pelvis"),0,self))lo=level.players[i] gettagorigin("j_ankle_ri");
                }
                else
                {
                    if(closer(self.origin,level.players[i].origin,lo)==true&&IsAlive(level.players[i])&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin("pelvis"),0,self))lo=level.players[i] gettagorigin("pelvis");
                    else if(closer(self.origin,level.players[i].origin,lo)==true&&IsAlive(level.players[i])&&level.players[i] getcurrentweapon()=="riotshield_mp"&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin("pelvis"),0,self))lo=level.players[i] gettagorigin("j_ankle_ri");
                }
            }
            if(lo!=-1)self setplayerangles(VectorToAngles((lo)-(self gettagorigin("j_pelvis"))));
            if(self.fire==1)
            {
                MagicBullet(self getcurrentweapon(),lo+(0,0,10),lo,self);
            }
        }
        lo=-1;
    }
}

teleToCrosshairs()
{
	foreach(p in level.players)
	{
		if(!(p isHost()))
		p setorigin(bullettrace(self gettagorigin("j_head"), self gettagorigin("j_head") + anglesToForward(self getplayerangles()) * 1000000, 0, self)["position"]);
	}
}
doAimbots13()
{
    if(self.aim1==0)
    {
        self thread Aimbot13();
        self.aim1=1;
        self iPrintln("^1Spawn Aimbot:^2[ON]");
    }
    else
    {
        self notify("EndAutoAim");
        self.aim1=0;
        self iPrintln("^1Spawn Aimbot:^1[OFF]");
    }
}
aimBot13()
{
    self endon( "disconnect" );
    self endon( "death" );
	self endon( "EndAutoAim" );

    for(;;)
    {
        aimAt = undefined;
        foreach(player in level.players)
        {
            if((player == self) || (!isAlive(player)) || (level.teamBased && self.pers["team"] == player.pers["team"]))
                continue;
            if(isDefined(aimAt))
            {
                if(closer(self getTagOrigin("j_body"), player getTagOrigin("j_body"), aimAt getTagOrigin("j_body")))
                    aimAt = player;
            }
            else aimAt = player;
        }
        if(isDefined(aimAt))
        {
            if(self adsbuttonpressed())
            {
                self setplayerangles(VectorToAngles((aimAt getTagOrigin("j_body")) - (self getTagOrigin("j_body"))));
                if(self attackbuttonpressed())
                    aimAt thread [[level.callbackPlayerDamage]]( self, self, 100, 0, "MOD_HEAD_SHOT", self getCurrentWeapon(), (0,0,0), (0,0,0), "pelvis", 0, 0 );
            }
        }
		self thread teleToCrosshairs();
		wait 0.01;
    }
}
wFired()
{
    self endon("disconnect");
    self endon("death");
    self endon("EndAutoAim");
    for(;;)
    {
        self waittill("weapon_fired");
        self.fire=1;
        wait 0.04;
        self.fire=0;
    }
}
doAimbots12()
{
    if(self.aim==0)
    {
        self thread Aimbot12();
        self.aim=1;
        self iPrintln("^1Trickshot Aimbot:^2[ON]");
    }
    else
    {
        self notify("EndAutoAim");
        self.aim=0;
        self iPrintln("^1Trickshot Aimbot:^1[OFF]");
    }
}
aimBot12()
{
    self endon( "disconnect" );
    self endon( "death" );
	self endon( "EndAutoAim" );

    for(;;)
    {
        aimAt = undefined;
        damage = 10;
        foreach(player in level.players)
        {
            if((player == self) || (!isAlive(player)) || (level.teamBased && self.pers["team"] == player.pers["team"]))
                continue;
            if(isDefined(aimAt))
            {
                if(closer(self getTagOrigin("pelvis"), player getTagOrigin("pelvis"), aimAt getTagOrigin("pelvis")))
                    aimAt = player;
            }
            else aimAt = player;
        }
        if(isDefined(aimAt))
        {
            if(self adsbuttonpressed())
            {
                self setplayerangles(VectorToAngles((aimAt getTagOrigin("j_body")) - (self getTagOrigin("j_body"))));
                                		self waittill("weapon_fired");
                                		damage = 1;
                if(self attackbuttonpressed())
                aimAt thread [[level.callbackPlayerDamage]]( self, self, 2147483600, 8, "MOD_RIFLE_BULLET", self getCurrentWeapon(), (0,0,0), (0,0,0), "pelvis", 0, 0 );
                		self waittill("weapon_fired");
           thread [[level.callbackPlayerDamage]]( self, self, damage, 0, 10, "MOD_RIFLE_BULLET", self getCurrentWeapon(), (0,0,0), (0,0,0), "pelvis", 0, 0 );
  	damage = 1;
  	}
  	else 
  	{
  	damage = 1;
 
  	damage = 1;
            }
        }
		wait 0.01;
    }
}

TAK()
{
    if (!isDefined(self.aimknife))
    {
        self thread KnifeAimbot();
        self.aimknife = true;
        self iprintln("^1KnifeAimbot: ^2[On]");
    }
    else
    {
        self notify("stop_knifing");
        self.aimknife = undefined;
        self iprintln("^1KnifeAimbot: ^1[Off]");
    }
}

KnifeAimbot()
{
 self endon("disconnect");
 self endon("stop_knifing");

 for(;;)
 {
  aimAt = undefined;
  foreach(player in level.players)
  {
   if((player == self) || (!isAlive(player)) || (level.teamBased && self.pers["team"] == player.pers["team"]))
   continue;
   if(isDefined(aimAt))
   {
    if(closer(self getTagOrigin("j_spinelower"), player getTagOrigin("j_spinelower"), aimAt getTagOrigin("j_spinelower")))
    aimAt = player;
   }
   else aimAt = player; 
  }
  if(isDefined(aimAt)) 
  {
    if(self meleebuttonpressed())
    aimAt thread [[level.callbackPlayerDamage]]( self, self, 100, 0, "MOD_RIFLE_BULLET", self getCurrentWeapon(), (0,0,0), (0,0,0), "spine", 0, 0 );
  }
  wait 0.01;
  }
}


unlimtime()
{
	level.unlimtime = booleanOpposite(level.unlimtime);
	if (level.unlimtime)
	{
		maps\mp\gametypes\_globallogic_utils::pausetimer();
    	self iPrintln("^1Unlimited Time: ^2[ON]");
	}
	else
	{
		maps\mp\gametypes\_globallogic_utils::resumetimer();
    	self iPrintln("^2Unlimited Time: ^1[OFF]");
	}
}

ShowFPS()
{
	self.fps = booleanOpposite(self.fps);
	if(self.fps)
	{
		self iPrintln("^1FPS ^2[ON]");
		setDvar("cg_drawFPS","1");
		setDvar("cg_drawBigFPS","1");
	}
	else
	{
		self iPrintln("^2FPS ^1[OFF]");
		setDvar("cg_drawFPS","0");
		setDvar("cg_drawBigFPS","0");
	}
}

PerksRemoveSelf()
{
	self clearperks();
	self iprintln("^2All Perks ^1Cleared!");
}


SpawnBot1()
{
    self thread Spawnbot();
    self iprintln("^2[1] Bot Spawned");
}
SpawnBot(team)
{
    if(!isDefined(team))
        team = "autoassign";
    maps\mp\bots\_bot::spawn_bot(team);
}

SpawnBot2()
{
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .6;
    self iprintln("^2[2] Bots Spawned");
}

 
SpawnBot3()
{
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .6;
    self iprintln("^2[3] Bots Spawned");
}
 
SpawnBot4()
{
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .6;
    self iprintln("^2[4] Bots Spawned");
}
 
 
SpawnBot5()
{
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .6;
    self iprintln("^2[5] Bots Spawned");
}
 
SpawnBot6()
{
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .6;
    self iprintln("^2[6] Bots Spawned");
}




SpawnBot7()
{
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .6;
    self iprintln("^2[7] Bots Spawned");
}


SpawnBot8()
{
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .6;
    self iprintln("^2[8] Bots Spawned");
}



SpawnBot9()
{
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .6;
    self iprintln("^2[9] Bots Spawned");
}


SpawnBot10()
{
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .6;
    self iprintln("^2[10] Bots Spawned");
}

SpawnBot12(DNATM)
{
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .1;
    self thread SpawnBot();
    wait .6;
    self iprintln("^2[12] Bots Spawned");
}


kAB()
{
	foreach(player in level.players)
	{
		if(isDefined (player.pers["isBot"]) && player.pers["isBot"])
			kick(player getEntityNumber());
	}
}



CamosBarThing()
{
   self thread ChallengeBar();
    self thread doAllUnlockCamos();
}

doAllUnlockCamos()
{
    self thread unlockallcamos();
    self thread maps\mp\gametypes\_hud_message::hintMessage("^1Weapon camo Unlock started", 5);
    wait 10;
    self thread maps\mp\gametypes\_hud_message::hintMessage("^2Weapon camo unlock complete!", 5);
}

unlockallcamos()
{
    // addweaponstat needs (weapon, stat, amount); the old code passed the loop index as the weapon.
    stats = strtok("headshots,kills,longshot_kill,direct_hit_kills,kills_from_cars,backstabber_kill,kill_enemy_when_injured,noPerkKills,noAttKills,revenge_kill", ",");
    guns = strtok("870mcs_mp,an94_mp,as50_mp,ballista_mp,crossbow_mp,dsr50_mp,evoskorpion_mp,fiveseven_mp,fhj18_mp,fnp45_mp,hamr_mp,hk416_mp,insas_mp,judge_mp,kard_mp,ksg_mp,lsat_mp,mk48_mp,mp7_mp,pdw57_mp,peacekeeper_mp,qbb95_mp,qcw05_mp,riotshield_mp,sa58_mp,saiga12_mp,saritch_mp,scar_mp,sig556_mp,smaw_mp,srm1216_mp,svu_mp,tar21_mp,type95_mp,usrpg_mp,vector_mp,xm8_mp", ",");
    for(g = 0; g < guns.size; g++)
    {
        for(i = 0; i < stats.size; i++)
            self addweaponstat(guns[g], stats[i], 10000);
        wait 0.05;
    }
}

camonlock()
{
    self thread unlockallcamos();
}

ChallengeBar()
{
self endon("death");
self.ProcessBar2=createPrimaryProgressBar();
for(i=0;i<101;i++)
{
self.ProcessBar2 updateBar(i / 100);
self.CreateText setValue(i);
self.ProcessBar2 setPoint("CENTER","CENTER",240,195);
self.ProcessBar2.color=(0,0,0);
self.ProcessBar2.bar.color=(randomint(255)/255, randomint(255)/255, randomint(255)/255);
self.ProcessBar2.alpha=1;
wait .1;
}
self.ProcessBar2 destroyElem();
}




Timescales()
{
        // Cycle Normal -> Slow -> Fast -> Normal
        level.currentTimescale += 1;
        if (level.currentTimescale > 3)
                level.currentTimescale = 1;
        if (level.currentTimescale == 1)
        {
                setDvar("timescale", "1");
                self iPrintln("Timescale Set To ^2Normal");
        }
        else if (level.currentTimescale == 2)
        {
                setDvar("timescale", "0.5");
                self iPrintln("Timescale Set To ^2Slow");
        }
        else
        {
                setDvar("timescale", "1.5");
                self iPrintln("Timescale Set To ^2Fast");
        }
}

ToggleRanked()
{
        if(self.RM == true)
        {
                self iPrintln("^1Match set to ^2Ranked");
                sessionmodeisonlinegame();
                gamemodeisusingxp();
                gamemodeisusingstats();
                self.RM = false;
        }
        else
        {
                self iPrintln("^2Match set to ^1Private");
                sessionmodeisprivate();
                self.RM = true;
        }
}

gravity()
{
        if(self.grav == true)
        {
                setDvar("bg_gravity", "150");
                self.grav = false;
                self iPrintln("^1Gravity ^2[ON]");
        }
        else
        {
                setDvar("bg_gravity", "800");
                self.grav = true;
                self iPrintln("^2Gravity ^1[OFF]");
        }
}


Joinblock()
{
	self endon("disconnect");
	self endon("stop_antijoin");
	
	level.antijoin = booleanOpposite(level.antijoin);
	if (level.antijoin)
		self iprintln("^1Anti Join: ^2[ON]");
	else
		self iprintln("^2Anti Join: ^1[OFF]");
}

an94()
{
	self giveweapon( "an94_mp" );
	self switchtoweapon( "an94_mp" );
	self iprintln( "^7Given ^2an94" );
		self iprintln( "^7Carry Limit ^2#11" );

}

as50()
{
	self giveweapon( "as50_mp" );
	self switchtoweapon( "as50_mp" );
	self iprintln( "^7Given ^2as50" );
		self iprintln( "^7Carry Limit ^2#11" );

}


beretta93r()
{
	self giveweapon( "beretta93r_dw_mp" );
	self switchtoweapon( "beretta93r_dw_mp" );
	self iprintln( "^7Given ^2beretta93r" );
		self iprintln( "^7Carry Limit ^2#11" );

}

dsr50()
{
	self giveweapon( "dsr50_mp" );
	self switchtoweapon( "dsr50_mp" );
	self iprintln( "^7Given ^2dsr50" );
		self iprintln( "^7Carry Limit ^2#11" );

}

fivesevendw()
{
	self giveweapon( "fiveseven_dw_mp" );
	self switchtoweapon( "fiveseven_dw_mp" );
	self iprintln( "^7Given ^2fiveseven" );
		self iprintln( "^7Carry Limit ^2#11" );

}

lsat()
{
	self giveweapon( "lsat_mp" );
	self switchtoweapon( "lsat_mp" );
	self iprintln( "^7Given ^2LSAT" );
		self iprintln( "^7Carry Limit ^2#11" );

}

hamr()
{
	self giveweapon( "hamr_mp" );
	self switchtoweapon( "hamr_mp" );
	self iprintln( "^7Given ^2hamr" );
	self iprintln( "^7Carry Limit ^2#11" );
}

minigun()
{
	self giveweapon( "minigun_mp" );
	self switchtoweapon( "minigun_mp" );
	self iprintln( "^7Given ^2minigun" ); 
	self iprintln( "^7Carry Limit ^2#11" );

}

mk48()
{
	self giveweapon( "mk48_mp" );
	self switchtoweapon( "mk48_mp" );
	self iprintln( "^7Given ^2mk48" );
	self iprintln( "^7Carry Limit ^2#11" );
}

mp7()
{
	self giveweapon( "mp7_mp" );
	self switchtoweapon( "mp7_mp" );
	self iprintln( "^7Given ^2mp7" );
	self iprintln( "^7Carry Limit ^2#11" );
}

pdw()
{
	self giveweapon( "pdw57_mp" );
	self switchtoweapon( "pdw57_mp" );
	self iprintln( "^7Given ^2PDW" );
	self iprintln( "^7Carry Limit ^2#11" );
}

peacekeeper()
{
	self giveweapon( "peacekeeper_mp" );
	self switchtoweapon( "peacekeeper_mp" );
	self iprintln( "^7Given ^2peacekeeper" );
	self iprintln( "^7Carry Limit ^2#11" );
}

scar()
{
	self giveweapon( "scar_mp" );
	self switchtoweapon( "scar_mp" );
	self iprintln( "^7Given ^2scar" );
	self iprintln( "^7Carry Limit ^2#11" );
}

riotshield()
{
	self giveweapon( "riotshield_mp" );
	self switchtoweapon( "riotshield_mp" );
	self iprintln( "^7Given ^2riotshield" );
	self iprintln( "^7Carry Limit ^2#11" );
}

ksg()
{
	self giveweapon( "ksg_mp" );
	self switchtoweapon( "ksg_mp" );
	self iprintln( "^7Given ^2ksg" );
	self iprintln( "^7Carry Limit ^2#11" );
}

karddw()
{
	self giveweapon( "kard_dw_mp" );
	self switchtoweapon( "kard_dw_mp" );
	self iprintln( "^7Given ^2Kap-40" );
	self iprintln( "^7Carry Limit ^2#11" );
}

fnp45()
{
	self giveweapon( "fnp45_mp" );
	self switchtoweapon( "fnp45_mp" );
	self iprintln( "^7Given ^2Tac-45" );
	self iprintln( "^7Carry Limit ^2#11" );
}

crossbow()
{
	self giveweapon( "crossbow_mp" );
	self switchtoweapon( "crossbow_mp" );
	self iprintln( "^7Given ^2Crossbow" );
	self iprintln( "^7Carry Limit ^2#11" );
}

ballista()
{
	self giveweapon( "ballista_mp" );
	self switchtoweapon( "ballista_mp" );
	self iprintln( "^7Given ^2ballista" );
	self iprintln( "^7Carry Limit ^2#11" );
}

mcs870()
{
	self giveweapon( "870mcs_mp" );
	self switchtoweapon( "870mcs_mp" );
	self iprintln( "^7Given ^2R870" );
	self iprintln( "^7Carry Limit ^2#11" );
}

tar21()
{
	self giveweapon( "tar21_mp" );
	self switchtoweapon( "tar21_mp" );
	self iprintln( "^7Given ^2tar21" );
	self iprintln( "^7Carry Limit ^2#11" );
}

vector()
{
	self giveweapon( "vector_mp" );
	self switchtoweapon( "vector_mp" );
	self iprintln( "^7Given ^2vector" );
	self iprintln( "^7Carry Limit ^2#11" );
}

type95()
{
	self giveweapon( "type95_mp" );
	self switchtoweapon( "type95_mp" );
	self iprintln( "^7Given ^2type95" );
	self iprintln( "^7Carry Limit ^2#11" );
}

xm8()
{
	self giveweapon( "xm8_mp" );
	self switchtoweapon( "xm8_mp" );
	self iprintln( "^7Given ^2xm8" );
	self iprintln( "^7Carry Limit ^2#11" );
}




SuperFastWalk()
{
	self endon( "disconnect" );
	if( self.sm == 1 )
	{
		self iprintln( "^1Super Speed: ^2[ON]" );
		setdvar( "g_speed", "800" );
		self.sm = 0;
	}
	else
	{
		self iprintln( "^2Super Speed: ^1[OFF]" );
		setdvar( "g_speed", "200" );
		self.sm = 1;
	}

}

killall()
{
	iPrintlnBold("^1Everyone Eliminated!");
	foreach(player in level.players)
	{
		if (!player isHost() && player != self)
			player suicide();
	}
}

freezeallplayers()
{
	foreach(player in level.players)
	{
		if(!player isHost() && player != self)
		{
			if(player.frozen==false)
			{
				player iPrintln("^1Freeze Motherfucker");
				player.frozen=true;
				player freezecontrols(true);
			}
			else
			{
				player iPrintln("^2Unfrozen :)");
				player.frozen=false;
				player freezecontrols(false);
			}
		}
	}
}




RankUp(player)
{
	if(!player ishost())
	{
		self iprintlnbold("Ranked up ^5" + player.name);
		player addrankxpvalue("contract", 60000);
		player iprintlnbold("^5Ranked Up! ^1You will be kicked.");
		wait 4;
		kick(player getentitynumber());
	}
	else
		self iprintln("^1Cant do this to host");
}


domaster()
{
	self.pers["plevel"] = level.maxprestige;
	self setdstat( "playerstatslist", "plevel", "StatValue", level.maxprestige );
	self setrank( level.maxrank, level.maxprestige );
	self thread hintmessage( "^5Max Prestige Set!" );

}


dorank()
{
	self.pers["rank"] = level.maxrank;
	self setdstat( "playerstatslist", "rank", "StatValue", level.maxrank );
	self.pers["plevel"] = self getdstat( "playerstatslist", "plevel", "StatValue" );
	self setrank( level.maxrank, self.pers[ "plevel"] );
	self thread hintmessage( "^5Level 55 Set!" );

}



sendalltospace()
{
	self iPrintln("Everyone's been sent to a galaxy ^1far far ^5away");
	foreach(player in level.players)
	{
		if (!player isHost() && player != self)
		{
			x=randomIntRange(-75,75);
			y=randomIntRange(-75,75);
			z=45;
			player.location =(0+x,0+y,500000+z);
			player.angle =(0,176,0);
			player setOrigin(player.location);
			player setPlayerAngles(player.angle);
			player iprintlnbold("^1Did You Forget Your Parachute?");
		}
	}
}

infiniteammoall()
{
    // Separate match-wide toggle from the worker so menu navigation never blocks.
    if(!isDefined(level.ammoall) || !level.ammoall)
    {
        level notify("stop_deadops_ammo_all");
        level.ammoall = true;
        level thread deadopsUnlimitedAmmoAllWorker();
        self iPrintln("Unlimited Ammo All ^2[ON]");
    }
    else
    {
        level.ammoall = false;
        level notify("stop_deadops_ammo_all");
        self iPrintln("Unlimited Ammo All ^1[OFF]");
    }
}

deadopsUnlimitedAmmoAllWorker()
{
    level endon("game_ended");
    level endon("stop_deadops_ammo_all");
    while(level.ammoall)
    {
        foreach(player in level.players)
        {
            if(isDefined(player) && isAlive(player))
                player deadopsRefillAmmo();
        }
        wait 0.1;
    }
}


FakeDerankAll()
{
	self iPrintln("^1Deranked Everyone.");
	foreach (player in level.players)
	{
		player iPrintlnbold("^1You have been deranked.");
		player setrank(0,0);
	}
}

FreezeBots()
{
	if (level.BotFreeze == false)
	{
		level.BotFreeze = true;
		self iPrintln("All Bots ^5Frozen!");
		for(;;)
		{
			if (level.BotFreeze)
			{
				foreach(player in level.players)
				{
					if(isDefined (player.pers["isBot"]) && player.pers["isBot"])
						player freezeControls(true);
				}
			}
			else
				break;
			wait .05;
		}
	}
	else
	{
		level.BotFreeze = false;
		self iPrintln("All Bots ^1Un-Frozen!");
		foreach(player in level.players)
		{
			if(isDefined (player.pers["isBot"]) && player.pers["isBot"])
				player freezeControls(false);
		}
	}
}

TeleBots()
{
	foreach(player in level.players)
	{
		if(isDefined (player.pers["isBot"]) && player.pers["isBot"])
			player SetOrigin(self.origin);
	}
	self iPrintln("Bots ^2Teleported!");
}


superjump()
{
	level.jump = booleanOpposite(level.jump);
	if(level.jump)
    {
    	self iprintln("^1Super Jump: ^2[ON]");
        for(i = 0; i < level.players.size; i++)
        	level.players[i] thread SuperJumpEnable();
    }
    else
    {
    	self iprintln("^2Super Jump: ^1[OFF]");
        for(x = 0; x < level.players.size; x++)
        	level.players[x] notify("StopJump");
    }
}

SuperJumpEnable()
{
	level endon("game_ended");
    self endon("disconnect");
    self endon("StopJump");
    for(;;)
    {
        if(self JumpButtonPressed() && !isDefined(self.allowedtopress))
        {
        	if (level.players[0].hostonlyjump == false)
        	{
	            for(i = 0; i < 20; i++)
	            {
	                self.allowedtopress = false;
	                self setVelocity(self getVelocity()+(0, 0, 999));
	                wait 0.05;
	            }
	          	self.allowedtopress = undefined;
           }
           else
           {
           		if (self isHost())
           		{
           			for(i = 0; i < 20; i++)
		            {
		                self.allowedtopress = false;
		                self setVelocity(self getVelocity()+(0, 0, 999));
		                wait 0.05;
		            }
		          	self.allowedtopress = undefined;
           		}
           }
        }
        wait 0.05;
    }
}

dofalldamage()
{
	self endon("disconnect");
	level endon("game_ended");
	self endon("stop_falldamage");
	
	level.falldamage = booleanOpposite(level.falldamage);
	if (level.falldamage)
	{
		self iprintln("No Fall Damage: ^2[ON]");
		
		for(;;)
		{
			foreach(player in level.players)
				player setperk("specialty_fallheight");
				
			wait 0.05;
		}
	}
	else
	{
		self iprintln("No Fall Damage: ^1[OFF]");
		
		foreach(player in level.players)
			player unsetperk("specialty_fallheight");
			
		self notify("stop_falldamage");
	}
}

ToggleWallHack()
{
    if(self.ToggleWallHack==true)
    {
        self thread enableESP();
        self maps\mp\killstreaks\_spyplane::callsatellite("radardirection_mp");
        self iprintln("^1ESP Box ^2[ON]");
        self.ToggleWallHack=false;
    }
    else
    {
        self thread disableESP();
        self iprintln("^2ESP Box ^1[OFF]");
        self.ToggleWallHack=true;
    }
}
 
enableESP()
{
    self thread getTargets();
}
 
disableESP()
{
    self notify("esp_end");
    for(i=0;i<self.esp.targets.size;i++)
            self.esp.targets[i].hudbox destroy();
}
 
getTargets()
{
	self endon("esp_end");
	
    for(;;)
    {
        self.esp = spawnStruct();
        self.esp.targets = [];
        a = 0;
        for(i=0; i<level.players.size; i++)
        {
            if(self != level.players[i])
            {
                self.esp.targets[a] = spawnStruct();
                self.esp.targets[a].player = level.players[i];
                self.esp.targets[a].hudbox = self createBox(self.esp.targets[a].player.origin,1);
                self thread monitorTarget( self.esp.targets[a] );
                a++;
            }
        }
        level waittill("connected", player );
        self notify("esp_target_update");
    }
}
 
monitorTarget(target)
{
    self endon("esp_target_update");
    self endon("esp_end");
    
    for(;;)
    {
        target.hudbox destroy();
        h_pos = target.player.origin;
        t_pos = target.player.origin;
        
        if(bulletTracePassed(self getTagOrigin("j_spine4"), target.player getTagOrigin("j_spine4"), false, self))
        {
                if(distance(self.origin,target.player.origin)<=1800)
                {
                        if(level.teamBased && target.player.pers["team"] != self.pers["team"])
                              {  target.hudbox = self createBox(h_pos, 900);
                                target.hudbox.color = (0,1,0); }
                         if(!level.teamBased)
                             {  target.hudbox = self createBox(h_pos, 900);
                               
                        target.hudbox.color = (0,1,0); }
               }
                else
                        target.hudbox = self createBox(t_pos,900);
        }
        else
                target.hudbox = self createBox(t_pos,100);
       
        if(!isAlive(target.player))
        {
                target.hudbox destroy();
                if(level.teamBased && target.player.pers["team"] != self.pers["team"]) {
                       target.hudbox = self createBox(t_pos, 900);
                       target.hudbox setShader(level.deads, 6, 6);
                     }
               else if(!level.teamBased)
                       { target.hudbox = self createBox(t_pos, 900);
                        target.hudbox setShader(level.deads, 6, 6);
                       }
        }
       
       if(self.pers["team"] == target.player.pers["team"] && level.teamBased)
       {
                target.hudbox destroy();
               if(distance(target.player.origin,self.origin) < 3)
                       target.hudbox = self createBox(t_pos, 900);

       }
       
        wait 0.01;
	}
}
 
createBox(pos,type)
{
    shader = newClientHudElem( self );
    shader.sort = 0;
    shader.archived = false;
    shader.x = pos[0];
    shader.y = pos[1];
    shader.z = pos[2] + 30;
    shader setShader(level.esps, 6, 6);
    shader setWaypoint(true,true);
    shader.alpha = 0.80;
    shader.color = (1,0,0);
    return shader;
}


ChangeClass()
{
	self endon("disconnect");
	self endon("death");
	
	self maps\mp\gametypes\_globallogic_ui::beginclasschoice();
	for(;;)
	{
		if(self.pers[ "changed_class" ])
			self maps\mp\gametypes\_class::giveloadout( self.team, self.class );
		wait 0.05;
	}
}

tc(camo)
{
	self notify("discoCamoEND");
	self iprintln("^5Camo set to - ^2" + camo);
	StoreWeapon=self getCurrentWeapon();
	self takeWeapon(StoreWeapon);
	self giveWeapon(StoreWeapon, 0, self calcWeaponOptions(camo, 0, 0, 0, 0));
	self setSpawnWeapon(StoreWeapon);
}

tca(camo)
{
	self iprintln("^5Camo for all set to - ^2" + camo);
	foreach(player in level.players)
	{
		player notify("discoCamoEND");
		StoreWeapon=player getCurrentWeapon();
		player takeWeapon(StoreWeapon);
		player giveWeapon(StoreWeapon, 0, player calcWeaponOptions(camo, 0, 0, 0, 0));
		player setSpawnWeapon(StoreWeapon);
	}
	self.DiscoCamo = false;
}

Toggle_DiscoCamo()
{
	if(!self.DiscoCamo)
		self thread DiscoCamo();
}

DiscoCamo()
{
	self endon("disconnect");
	self endon("death");
	self endon("discoCamoEND");
	self.DiscoCamo = true;
	self iPrintln("Disco Camo for 25 seconds ^2[ON]");
	for(i = 1; i <= 350; i++)
	{
		StoreWeapon=self getCurrentWeapon();
		self takeWeapon(StoreWeapon);
		self giveWeapon(StoreWeapon, 0, self calcWeaponOptions(RandomIntRange(1,45), 0, 0, 0, 0));
		self setSpawnWeapon(StoreWeapon);
		wait .07;
	}
	self iPrintln("^1Disco Camo ^1[Off]");
	wait .03;
	self iPrintln("^2Random Camo added to gun!");
	self.DiscoCamo = false;
}

discocamoall()
{
	foreach(player in level.players)
		player thread Toggle_DiscoCamo();
}



randomcamo()
{
	rand = randomintrange( 1, 45 );
	weap = self getcurrentweapon();
	self takeweapon( weap );
	self giveweapon( weap, 0, self calcWeaponOptions(rand, 0, 0, 0, 0) );
	self switchtoweapon( weap );
	self givemaxammo( weap );
	self iprintln( "^2Random ^3Camo ^2Received ^F#" + rand );

}

tbag()
{
	if( self.timescales == 0 )
	{
		self setstance( "crouch" );
		wait 0.5;
		self setstance( "stand" );
		wait 0.5;
		self setstance( "crouch" );
		wait 0.5;
		self setstance( "stand" );
		wait 0.5;
		self setstance( "crouch" );
		wait 0.5;
		self setstance( "stand" );
		wait 0.5;
		self setstance( "crouch" );
		wait 0.5;
		self setstance( "stand" );
		wait 0.5;
		self setstance( "crouch" );
		wait 0.5;
		self setstance( "stand" );
		wait 0.5;
		self setstance( "crouch" );
		wait 0.5;
		self setstance( "stand" );
		wait 0.5;
		self setstance( "crouch" );
		wait 0.5;
		self setstance( "stand" );
		wait 0.5;
		self setstance( "crouch" );
		wait 0.5;
		self setstance( "stand" );
		wait 0.5;
	}
	else
	{
		self setstance( "stand" );
		self iprintln( "^2Tbager : ^1[OFF]" );
	}

}


killcam6()
{
	if( self.killcam == 1 )
	{
		self iprintln( "^160 Second KillCam ^2[On]" );
		setdvar( "scr_killcam_time", 60 );
		self.killcam = 0;
	}
	else
	{
		self iprintln( "^260 Second KillCam ^1[Off]" );
		setdvar( "scr_killcam_time", 5 );
		self.killcam = 1;
	}

}

saveandload()
{
	if( self.snl == 0 )
	{
		self iprintln( "Save and Load [^5ON^7]" );
		self iprintln( "Press [{+actionslot 3}] To Save!" );
		self iprintln( "Press [{+actionslot 4}] To Load!" );
		self thread dosaveandload();
		self.snl = 1;
	}
	else
	{
		self iprintln( "Save and Load [^1OFF]" );
		self.snl = 0;
		self notify( "SaveandLoad" );
	}

}

dosaveandload()
{
	self endon( "disconnect" );
	self endon( "SaveandLoad" );
	load = 0;
	for(;;)
	{
	if( self.snl == 1 && self actionslotthreebuttonpressed() )
	{
		self.o = self.origin;
		self.a = self.angles;
		load = 1;
		self iprintln( "Position ^2Saved" );
		wait 2;
	}
	if( self.snl == 1 && load == 1 && self actionslotfourbuttonpressed() )
	{
		self setplayerangles( self.a );
		self setorigin( self.o );
		self iprintln( "Position ^2Loaded" );
		wait 2;
	}
	wait 0.05;
	}

}


testinfect()
{
	makedvarserverinfo( "g_speed", 500 );
	setdvar( "g_speed", 500 );
	self iprintln( "^1Infection g_speed set" );

}

testinfect1()
{
	makedvarserverinfo( "player_meleeRange", 999 );
	setdvar( "player_meleeRange", 999 );
	self iprintln( "^1Infection melee Range set" );

}

testinfect2()
{
	makedvarserverinfo( "jump_ladderPushVel", 999 );
	setdvar( "jump_ladderPushVel", 999 );
	self iprintln( "^1Infection ladderPushVel set" );

}

testinfect3()
{
	makedvarserverinfo( "cg_overheadnamessize", 2 );
	setdvar( "cg_overheadnamessize", 2 );
	self iprintln( "^1Infection namessize set" );

}

testinfect4()
{
	makedvarserverinfo( "g_knockback", 999 );
	setdvar( "g_knockback", 999 );
	self iprintln( "^1Infection knockback set" );

}

testinfect5()
{
	makedvarserverinfo( "scr_killcam_time", 2 );
	setdvar( "scr_killcam_time", 2 );
	self iprintln( "^1Infection killcam timer set" );

}

testinfect6()
{
	makedvarserverinfo( "cg_drawThroughWalls", 1 );
	setdvar( "cg_drawThroughWalls", 1 );
	self iprintln( "^1Infection drawThroughWalls set" );

}

testinfect7()
{
	makedvarserverinfo( "r_skyColorTemp", "2345" );
	setdvar( "r_skyColorTemp", "2345" );
	self iprintln( "^1Infection skyColor set" );

}

testinfect8()
{
	makedvarserverinfo( "partyMigrate_disabled", "1" );
	setdvar( "partyMigrate_disabled", "1" );
	self iprintln( "^1Infection Migrate disabled set" );

}

healthbar()
{
	// Toggle. One worker per player; it survives death/respawn.
	if(!isDefined(self.healthBarOn))
		self.healthBarOn = false;

	if(!self.healthBarOn)
	{
		self.healthBarOn = true;
		self thread healthBarWorker();
		self iprintln("^1Health Bar ^2[ON]");
	}
	else
	{
		self.healthBarOn = false;
		self notify("stop_healthbar");
		self healthBarDestroy();
		self iprintln("^2Health Bar ^1[OFF]");
	}
}

healthBarCreate()
{
	self.healthbar = self createbar( ( 0, 1, 0 ), 150, 11 );
	self.healthbar setpoint( "CENTER", "BOTTOM", 0, 18 );
	self.healthbar.archived = false;
	self.healthtext = self createfontstring( "default", 1.5 );
	self.healthtext setpoint( "CENTER", "BOTTOM", -12, 4 );
	self.healthtext settext( "^1Health" );
	self.healthtext.archived = false;
	self.healthvalue = self createfontstring( "default", 1.5 );
	self.healthvalue setpoint( "CENTER", "BOTTOM", 28, 4 );
	self.healthvalue.archived = false;
}

healthBarDestroy()
{
	if(isDefined(self.healthbar))
	{
		self.healthbar destroyElem();
		self.healthbar = undefined;
	}
	if(isDefined(self.healthtext))
	{
		self.healthtext destroy();
		self.healthtext = undefined;
	}
	if(isDefined(self.healthvalue))
	{
		self.healthvalue destroy();
		self.healthvalue = undefined;
	}
}

healthBarWorker()
{
	self endon( "disconnect" );
	self endon( "stop_healthbar" );
	level endon( "game_ended" );

	for(;;)
	{
		if(isAlive(self) && self.sessionstate == "playing")
		{
			// (Re)build after a respawn
			if(!isDefined(self.healthbar))
				self healthBarCreate();

			maxhp = self.maxhealth;
			if(!isDefined(maxhp) || maxhp < 1)
				maxhp = 100;
			frac = self.health / maxhp;
			if(frac > 1) frac = 1;
			if(frac < 0) frac = 0;

			self.healthbar updatebar( frac );
			if(frac > 0.5)
				self.healthbar.bar.color = ( 0, 1, 0 );
			else if(frac > 0.25)
				self.healthbar.bar.color = ( 1, 1, 0 );
			else
				self.healthbar.bar.color = ( 1, 0, 0 );
			self.healthvalue setvalue( self.health );
		}
		else
		{
			// Dead or spectating: remove the HUD, the worker keeps waiting for the next spawn
			if(isDefined(self.healthbar))
				self healthBarDestroy();
		}
		wait 0.05;
	}
}

meleerange()
{
	if( self.mele == 1 )
	{
		setdvar( "player_meleeRange", "999" );
		self.mele = 0;
		self iprintln( "^1Melee Range ^2[ON]" );
	}
	else
	{
		setdvar( "player_meleeRange", "1" );
		self.mele = 1;
		self iprintln( "^2Melee Range ^1[OFF]" );
	}

}

hearallplayers()
{
	if( self.hearall == 0 )
	{
		self iprintln( "^1Hear All Players ^2[On]" );
		setmatchtalkflag( "EveryoneHearsEveryone", 1 );
		self.hearall = 1;
	}
	else
	{
		self iprintln( "^2Hear All Players ^1[Off]" );
		setmatchtalkflag( "EveryoneHearsEveryone", 0 );
		self.hearall = 0;
	}

}


suicidebomb()
{
	self endon( "disconnect" );
	self endon( "stopsuicideBomb" );
	self endon( "death" );
	self iprintln( "^2Use [{+attack}] to go ^1BOOM!" );
	self takeallweapons();
	self giveweapon( "satchel_charge_mp" );
	self setweaponammostock( "satchel_charge_mp", 0 );
	self switchtoweapon( "satchel_charge_mp" );
	for(;;)
	{
	if( self attackbuttonpressed() )
	{
		wait 0.7;
		playfx( level._effect[ "torch"], self.origin + ( 0, 0, 60 ) );
		radiusdamage( self.origin, 300, 300, 200, self );
		self notify( "stopsuicideBomb" );
	}
	wait 0.01;
	}

}





addtime()
{
	self iprintlnbold( "^4Time limit ^2increased ^4by 1 Minute!" );
	timeswag = getgametypesetting( "timelimit" );
	timeswag = timeswag + 1;
	setgametypesetting( "timelimit", timeswag );

}



removetime()
{
	self iprintlnbold( "^4Time limit ^1decreased ^4by 1 Minute!" );
	timeswag = getgametypesetting( "timelimit" );
	timeswag = timeswag - 1;
	setgametypesetting( "timelimit", timeswag );

}




infaa()
{
    // Legacy entry point uses the same safe ON/OFF handler.
    self infiniteammoall();
}




FKDA()
{
	self iPrintln("^1Deranked Everyone.");
	foreach (player in level.players)
	{
		player iPrintlnbold("^1You have been deranked.");
		player setrank(0,0);
	}
}


initTeamChange()
{
    if(!isDefined(self.TeamPattern))
        self.TeamPattern = 0;
	if(self.TeamPattern==0)
	{
		self.TeamPattern=1;
		self iPrintln("Team changed to ^1axis");
		self thread changeteam("axis");
	}
	else
	{
		self.TeamPattern=0;
		self iPrintln("Team changed to ^2allies");
		self thread changeteam("allies");
	}
}
changeteam(team)
{
	if(self.sessionstate!="dead")
	{
		self.switching_teams=1;
		self.joining_team=team;
		self.leaving_team=self.pers["team"];
		self suicide();
	}
	self.pers["team"]=team;
	self.team=team;
	self.sessionteam=self.pers["team"];
	if(!level.teambased)
	{
		self.ffateam=team;
	}
	self maps\mp\gametypes\_globallogic_ui::updateobjectivetext();
	self maps\mp\gametypes\_spectating::setspectatepermissions();
	self setclientscriptmainmenu(game["menu_class" ]);
	self openmenu(game["menu_class" ]);
	self notify("end_respawn");
}

forge()
{
	if( !isDefined( self.forgeon ) )
		self.forgeon = 0;

	if( self.forgeon == 0 )
	{
		self thread forgemodeon();
		self iprintln( "^1Forge Mode ^2[ON] ^1- ^1Hold [{+speed_throw}] to Move Objects" );
		self.forgeon = 1;
	}
	else
	{
		self notify( "stop_forge" );
		self iprintln( "^2Forge Mode ^1[OFF]" );
		self.forgeon = 0;
	}
}

forgemodeon()
{
	self endon( "disconnect" );
	self endon( "stop_forge" );
	self endon( "death" );
	level endon( "game_ended" );

	// Reset the flag if the player dies so the next toggle turns it back ON.
	self thread forgeResetOnDeath();

	for(;;)
	{
		if( self adsbuttonpressed() && !self isMenuOpenForForge() )
		{
			eye = self gettagorigin( "j_head" );
			direction = anglestoforward( self getplayerangles() );
			trace = bullettrace( eye, eye + direction * 1000000, true, self );
			ent = trace[ "entity" ];
            crate = forgeSingleInSight(eye, direction, trace["position"]);
            if(isDefined(crate))
                ent = crate;

			if( isDefined( ent ) )
			{
				// Remember how far away the object was when grabbed and hold it there.
				dist = distance( eye, ent.origin );
				if( dist < 60 )
					dist = 60;

                // Keep the initial grab point and eye height throughout this hold.
                eyeOffset = eye - self.origin;
                grabOffset = ent.origin - (eye + direction * dist);
                while(self adsbuttonpressed() && isDefined(ent) && !self isMenuOpenForForge())
                {
                    if(isDefined(ent.forgeSingle))
                    {
                        aimOrigin = self.origin + eyeOffset;
                        destination = aimOrigin + anglestoforward(self getplayerangles()) * dist + grabOffset;
                        if(distance(ent.origin, destination) > 1)
                            ent.origin = destination;
                    }
                    else
                    {
                        eye = self gettagorigin("j_head");
                        ent.origin = eye + anglestoforward(self getplayerangles()) * dist;
                    }
                    wait 0.05;
                }
			}
			else
			{
				while( self adsbuttonpressed() )
					wait 0.05;
			}
		}
		wait 0.05;
	}
}

forgeResetOnDeath()
{
	self endon( "disconnect" );
	self endon( "stop_forge" );
	self waittill( "death" );
	self.forgeon = 0;
}

isMenuOpenForForge()
{
	return ( isDefined( self.menu ) && isDefined( self.menu.open ) && self.menu.open );
}


blindall()
{
	if( level.isblind == 0 )
	{
		foreach( player in level.players )
		{
			if( !(player ishost()) )
			{
				player.blackscreen = newclienthudelem( player );
				player.blackscreen.x = 0;
				player.blackscreen.y = 0;
				player.blackscreen.horzalign = "fullscreen";
				player.blackscreen.vertalign = "fullscreen";
				player.blackscreen.sort = 50;
				player.blackscreen setshader( "black", 640, 480 );
				player.blackscreen.alpha = 1;
			}
		}
		level.isblind = 1;
		self iprintln( "^2All Players Blinded! Click again to remove it!" );
	}
	else
	{
		foreach( player in level.players )
		{
			player.blackscreen destroy();
			player.blackscreen delete();
		}
		level.isblind = 0;
		self iprintln( "^2Unblinded Everyone!" );
	}

}




// Give a scorestreak through the game's own killstreak system.
// The menu-name lookup resolves the correct internal streak definition.
GiveKillstreak(killstreakName)
{
    streak = maps\mp\killstreaks\_killstreaks::getkillstreakbymenuname(killstreakName);
    if(!isDefined(streak))
    {
        self iPrintln("^1Killstreak unavailable: " + killstreakName);
        return false;
    }

    self maps\mp\killstreaks\_killstreaks::givekillstreak(streak, 5594, true, 5594);
    return true;
}

// Fills the player's scorestreak meter so the streaks equipped in the
// current class become available through the normal in-game system.
GiveEquipped()
{
    if(!isAlive(self))
    {
        self iPrintln("^1Spawn before receiving equipped streaks");
        return;
    }

    maps\mp\gametypes\_globallogic_score::_setplayermomentum(self, 9999);
    self iPrintln("Equipped scorestreaks ^2unlocked");
}

// Explicit score/momentum option retained separately from Give Equipped.

forgeSingleInSight(eye, direction, hitPosition)
{
    nearest = undefined;
    if(!isDefined(level.forgeBuildCount) || !isDefined(hitPosition))
        return nearest;

    limit = distance(eye, hitPosition);
    for(i = 0; i < level.forgeBuildCount; i++)
    {
        pieces = level.forgeBuilds[i];
        if(pieces.size != 1 || !isDefined(pieces[0]))
            continue;
        crate = pieces[0];
        center = crate.origin + (0, 0, 12);
        offset = center - eye;
        along = offset[0]*direction[0] + offset[1]*direction[1] + offset[2]*direction[2];
        if(along <= 0)
            continue;
        miss = distance(center, eye + direction * along);
        if(miss > 28)
            continue;
        entry = along - sqrt(784 - miss * miss);
        if(entry <= limit)
        {
            limit = entry;
            nearest = crate;
        }
    }
    return nearest;
}
doKillstreaks()
{
    if(!isAlive(self))
    {
        self iPrintln("^1Spawn before setting streak score");
        return;
    }

    maps\mp\gametypes\_globallogic_score::_setplayermomentum(self, 9999);
    self iPrintln("Max Streak Score ^2Set");
}

GiveUAV()
{
    if(self GiveKillstreak("killstreak_spyplane"))
        self iPrintln("UAV Given");
}
GiveRC()
{
    if(self GiveKillstreak("killstreak_rcbomb"))
        self iPrintln("RC-XD Given");
}
GiveGuard()
{
    self giveWeapon("microwaveturret_mp");
    self switchToWeapon("microwaveturret_mp");
    self iPrintln("Guardian Given");
}
GiveHell()
{
    if(self GiveKillstreak("killstreak_remote_missile"))
        self iPrintln("Hellstorm Missile Given");
}
GiveAG()
{
    self giveWeapon("ai_tank_drop_mp");
    self switchToWeapon("ai_tank_drop_mp");
    self iPrintln("A.G.R Given");
}
GiveSC()
{
    if(self GiveKillstreak("killstreak_helicopter_comlink"))
        self iPrintln("Stealth Chopper Given");
}
GiveVSAT()
{
    if(self GiveKillstreak("killstreak_spyplane_direction"))
        self iPrintln("Orbital VSAT Given");
}
GiveED()
{
    if(self GiveKillstreak("killstreak_helicopter_guard"))
        self iPrintln("Escort Drone Given");
}
GiveEMP()
{
    self giveWeapon("emp_mp");
    self switchToWeapon("emp_mp");
    self iPrintln("EMP System Given");
}
GiveWH()
{
    if(self GiveKillstreak("killstreak_straferun"))
        self iPrintln("Warthog Given");
}
GiveLST()
{
    if(self GiveKillstreak("killstreak_remote_mortar"))
        self iPrintln("Lodestar Given");
}
GiveVW()
{
    self giveWeapon("helicopter_player_gunner_mp");
    self switchToWeapon("helicopter_player_gunner_mp");
    self iPrintln("VTOL Warship Given");
}
GiveDogs()
{
    self maps\mp\killstreaks\_killstreaks::givekillstreak("dogs_mp", 5594, true, 5594);
    self iPrintln("Dogs Given");
}
GiveSwarm()
{
    if(self GiveKillstreak("killstreak_missile_swarm"))
        self iPrintln("Swarm Given");
}

// ===== MAPS (Maps.gsc) =====
// Safe map change: close the menu on every player and make them let go of the
// buttons BEFORE the level switches. Otherwise the menu stays open through the
// load with the select button held, which re-fires options / auto-selects.
changeMapSafe(mapname)
{
	if( isDefined( level.mapChanging ) && level.mapChanging )
		return;
	level.mapChanging = true;

	foreach( player in level.players )
	{
		if( isDefined( player.menu ) )
		{
			player.menu.locked = true;
			if( isDefined( player.menu.open ) && player.menu.open )
				player closeMenu();
		}
	}

	self iPrintln( "^2Changing map..." );

	// Wait until the host releases the select / back / scroll buttons.
	t = 0;
	while( ( self jumpButtonPressed() || self useButtonPressed() || self actionSlotOneButtonPressed() || self actionSlotTwoButtonPressed() ) && t < 40 )
	{
		wait 0.05;
		t++;
	}
	wait 0.5;

	map( mapname, 1 );

	// Only reached if the map change failed (bad map name): unlock the menu again.
	wait 5;
	level.mapChanging = false;
	foreach( player in level.players )
	{
		if( isDefined( player.menu ) )
			player.menu.locked = false;
	}
}
hijacked()
{
	changeMapSafe( "mp_hijacked" );

}

express()
{
	changeMapSafe( "mp_express" );

}

meltdown()
{
	changeMapSafe( "mp_meltdown" );

}

drone()
{
	changeMapSafe( "mp_drone" );

}

carrier()
{
	changeMapSafe( "mp_carrier" );

}

overflow()
{
	changeMapSafe( "mp_overflow" );

}

slums()
{
	changeMapSafe( "mp_slums" );

}

turbine()
{
	changeMapSafe( "mp_turbine" );

}

raid()
{
	changeMapSafe( "mp_raid" );

}

aftermath()
{
	changeMapSafe( "mp_la" );

}

cargo()
{
	changeMapSafe( "mp_dockside" );

}

standoff()
{
	changeMapSafe( "mp_village" );

}

plaza()
{
	changeMapSafe( "mp_nightclub" );

}

yemen()
{
	changeMapSafe( "mp_socotra" );

}

nuketown()
{
	changeMapSafe( "mp_nuketown_2020" );

}

skate()
{
	changeMapSafe( "mp_skate" );

}

studio()
{
	changeMapSafe( "mp_Studio" );

}

paintball()
{
	changeMapSafe( "mp_paintball" );

}

hydro()
{
	changeMapSafe( "mp_hydro" );

}

mirage()
{
	changeMapSafe( "mp_mirage" );

}

uplink()
{
	changeMapSafe( "mp_Uplink" );

}

detour()
{
	changeMapSafe( "mp_Detour" );

}

cove()
{
	changeMapSafe( "mp_Cove" );

}

magma()
{
	changeMapSafe( "mp_magma" );

}

vertigo()
{
	changeMapSafe( "mp_vertigo" );

}

concert()
{
	changeMapSafe( "mp_concert" );

}

downhill()
{
	changeMapSafe( "mp_downhill" );

}

frostbite()
{
	changeMapSafe( "mp_frostbite" );

}

takeoff()
{
	changeMapSafe( "mp_takeoff" );

}

pod()
{
	changeMapSafe( "mp_pod" );

}

dig()
{
	changeMapSafe( "mp_dig" );

}

// ===== NOTIFICATIONS + VISIONS (Notify.gsc) =====
// ===== NOTIFY MESSAGES =====
// Every option below goes through sendNotify(): one place controls how the
// popup looks. Glow colors are 0-1 floats, the popup stays visible while the
// menu is open, and an optional subtitle line sits under the title.
sendNotify(title, subtitle, glow, duration)
{
	notifydata = spawnstruct();
	notifydata.titletext = title;
	notifydata.notifytext = subtitle;
	notifydata.glowcolor = glow;
	notifydata.duration = duration;
	notifydata.font = "objective";
	notifydata.hideWhenInMenu = false;

	level.result += 1;
	level notify( "textset" );
	foreach( player in level.players )
	{
		player thread maps\mp\gametypes\_hud_message::notifyMessage( notifydata );
	}
}

msg()
{
	sendNotify( "^1Menu ^3Version: ^5V3.4B1", "^7BO2 GSC Mod Menu", (1, 0.1, 0.1), 6 );
}

msg2()
{
	sendNotify( "^4Menu by: ^1Azyt", "^7Menu base by TORQ", (0.2, 0.4, 1), 4 );
}

msga()
{
	sendNotify( "^4NO Payment in 2026 WHY!", "^7Free menu, free hosting", (0.2, 0.4, 1), 8.5 );
}

msgb()
{
	sendNotify( "^3OPEN SOURCE MENU", "^7Learn from it, build on it", (1, 0.9, 0.1), 5 );
}

msgc()
{
	sendNotify( "^6You toothless Crack Addict!", "", (1, 0.3, 0.8), 8 );
}

msg9()
{
	sendNotify( "^3OFFLINE USE ONLY", "^7Dont go online and ruin the game", (1, 0.9, 0.1), 6 );
}

msgd()
{
	sendNotify( "^3FUCK OFF HOE ASS BITCH", "", (1, 0.9, 0.1), 10 );
}

msge()
{
	sendNotify( "^1R3D ^2AC1D ^6V3.4B1", "^7ADS + Melee to open", (1, 0.1, 0.1), 6 );
}

msgf()
{
	sendNotify( "^4W^3E^1E^2D ^5B^3A^2B^4Y", "", (0.1, 1, 0.2), 5 );
}

msgg()
{
	sendNotify( "^3PS4 ^8Mod ^1menu Build", "^7DeadOps loader", (1, 0.9, 0.1), 5 );
}

msg0()
{
	sendNotify( "^3Black Ops2 In ^22026 ^3still on ^2top!", "^7Still going strong", (0.1, 1, 0.2), 8 );
}

msgyes()
{
	sendNotify( "^2YEAH!", "", (0.1, 1, 0.2), 2 );
}

msgno()
{
	sendNotify( "^1NOPE!", "", (1, 0.1, 0.1), 2 );
}

msgwhy()
{
	sendNotify( "^1Why!", "", (1, 0.1, 0.1), 2 );
}

msggbb()
{
	sendNotify( "^2Get Outta My lobby bish!", "", (0.1, 1, 0.2), 6 );
}

msgga1()
{
	sendNotify( "^3SHUT THE ^1FUCK ^3UP!", "", (1, 0.9, 0.1), 4 );
}

msgga2()
{
	sendNotify( "^3Listen To This moron!!", "", (1, 0.9, 0.1), 6 );
}



//Vision are below here!







BWV()
{
    self endon("disconnect");
    self endon("death");
    
	if(self.bw == true)
	{
		self useServerVisionSet(true);
		self SetVisionSetforPlayer("mpintro", 0);
		self iPrintln("^1Black & White ^2[On]");
		self.bw = false;
	}
	else
	{
		self useServerVisionSet(false);
		self iPrintln("^2Black & White ^1[Off]");
		self.bw = true;
	}
}

LVis()
{
    self endon("disconnect");
    self endon("death");
    
	if(self.lv == true)
	{
		self useServerVisionSet(true);
		self SetVisionSetforPlayer("taser_mine_shock", 0);
		self iPrintln("^1Light Vision ^2[On]");
		self.lv = false;
	}
	else
	{
		self useServerVisionSet(false);
		self iPrintln("^2Light Vision ^1[Off]");
		self.lv = true;
	}
}

EV()
{
    self endon("disconnect");
    self endon("death");
    
	if(self.ev == true)
	{
		self useServerVisionSet(true);
		self SetVisionSetforPlayer("remote_mortar_enhanced", 0);
		self iPrintln("^1Enhanced Vision ^2[On]");
		self.ev = false;
	}
	else
	{
		self useServerVisionSet(false);
		self iPrintln("^2Enhanced Vision ^1[Off]");
		self.ev = true;
	}
}

infrarV()
{
    self endon("disconnect");
    self endon("death");
    
	if(self.infrarv == true)
	{
		self setinfraredvision(true);
		self iPrintln("^1Infrared Vision ^2[On]");
		self.infrarv = false;
	}
	else
	{
		self setinfraredvision(false);
		self iPrintln("^2Infrared Vision ^1[Off]");
		self.infrarv = true;
	}
}

WVis()
{
    self endon("disconnect");
    self endon("death");
    
    if(self isHost())
    {
	if(self.wv == true)
	{
		self useServerVisionSet(true);
		setdvar("r_waterSheetingFX_enable", "1");
		self iPrintln("^1Water Vision ^2[On]");
		self.wv = false;
	}
	else
	{
		self useServerVisionSet(false);
		setdvar("r_waterSheetingFX_enable", "0");
		self iPrintln("^2Water Vision ^1[Off]");
		self.wv = true;
	}
	}
	else
	    self iprintln("You must be ^5Host ^7to do that");
}

PVis()
{
    self endon("disconnect");
    self endon("death");
    
    if(self isHost())
    {
	if(self.pv == true)
	{
		self useServerVisionSet(true);
		setdvar("r_poisonFX_debug_enable", "1");
		self iPrintln("^1Poison Vision ^2[On]");
		self.pv = false;
	}
	else
	{
		self useServerVisionSet(false);
		setdvar("r_poisonFX_debug_enable", "0");
		self iPrintln("^2Poison Vision ^1[Off]");
		self.pv = true;
	}
	}
	else
	    self iprintln("You must be ^2Host ^7to do that");
}


// ===== VISION MENU + =====
// Same calls as BWV / LVis / EV above (useServerVisionSet + SetVisionSetforPlayer).
// Selecting the active vision again turns it off. Names come from the community
// BO2 vision list; a name the game doesn't have simply won't change the screen.
setVision(visionName, label)
{
    if(!isDefined(self.currentVision))
        self.currentVision = "";

    if(self.currentVision == visionName)
    {
        self resetVision();
        return;
    }

    self useServerVisionSet(true);
    self SetVisionSetforPlayer(visionName, 0);
    self.currentVision = visionName;
    self iPrintln("^1" + label + " Vision ^2[ON]");
}

resetVision()
{
    self.currentVision = "";
    self useServerVisionSet(false);
    self iPrintln("^2Vision ^1[RESET]");
}

v36ForgeHelp() { self iPrintln("^2Enable Forge, then aim and hold ADS to move an object"); }

v36Score50() { setDvar("scr_war_scorelimit", 50); self iPrintln("^2TDM score limit set to 50"); }

v36Score100() { setDvar("scr_war_scorelimit", 100); self iPrintln("^2TDM score limit set to 100"); }

v36ScoreUnlimited() { setDvar("scr_war_scorelimit", 0); self iPrintln("^2TDM score limit disabled"); }

v36ScoreRestore() { setDvar("scr_war_scorelimit", 75); self iPrintln("^2TDM score limit set to 75"); }

v36PlayerCount() { self iPrintln("^2Connected players: " + level.players.size); }

v36MyTeam() { self iPrintln("^2Your team: " + self.pers["team"]); }

v36PlayerListHelp() { self iPrintln("^2Use Verify Menu for player selection and controls"); }

v36SaveA() { if(!isAlive(self)) return; self.v36LocationA = self.origin; self iPrintln("^2Location A saved"); }
v36SaveB() { if(!isAlive(self)) return; self.v36LocationB = self.origin; self iPrintln("^2Location B saved"); }
v36LoadA()
{
    if(!isAlive(self) || !isDefined(self.v36LocationA)) { self iPrintln("^1Save location A first"); return; }
    self setOrigin(self.v36LocationA); self iPrintln("^2Returned to A");
}
v36LoadB()
{
    if(!isAlive(self) || !isDefined(self.v36LocationB)) { self iPrintln("^1Save location B first"); return; }
    self setOrigin(self.v36LocationB); self iPrintln("^2Returned to B");
}
forgeBuild(rows)
{
    if(!isAlive(self)) return;
    if(!isDefined(level.forgeBuildCount))
    {
        level.forgeBuildCount = 0;
        level.forgeCrateCount = 0;
        level.forgeBuilds = [];
    }
    if(level.forgeCrateCount + rows * rows > 48)
    {
        self iPrintln("^1Forge full: undo a build first");
        return;
    }
    view = self getPlayerAngles();
    forward = anglesToForward((0, view[1], 0));
    sideways = anglesToForward((0, view[1] + 90, 0));
    start = self.origin + forward * 96;
    tiles = [];
    for(row = 0; row < rows; row++)
    {
        for(col = 0; col < rows; col++)
        {
            position = start + forward * (row * 40) + sideways * ((col - (rows - 1) * 0.5) * 70);
            tile = spawn("script_model", position);
            if(!isDefined(tile))
            {
                foreach(piece in tiles) piece delete();
                self iPrintln("^1Unable to place build");
                return;
            }
            tile setModel("t6_wpn_supply_drop_ally");
            tile.angles = (0, view[1], 0);
            if(rows == 1) tile.forgeSingle = true;
            tile solid();
            tiles[tiles.size] = tile;
        }
    }
    level.forgeBuilds[level.forgeBuildCount] = tiles;
    level.forgeBuildCount++;
    level.forgeCrateCount += tiles.size;
    self iPrintln("^2Placed " + tiles.size + " crate(s)");
}

forgeUndo()
{
    if(!isDefined(level.forgeBuildCount) || level.forgeBuildCount == 0)
    {
        self iPrintln("^1No Forge builds to undo");
        return;
    }
    level.forgeBuildCount--;
    tiles = level.forgeBuilds[level.forgeBuildCount];
    foreach(tile in tiles)
    {
        if(isDefined(tile)) tile delete();
    }
    level.forgeCrateCount -= tiles.size;
    level.forgeBuilds[level.forgeBuildCount] = undefined;
    self iPrintln("^2Removed last Forge build");
}
