// ============================================================================
// R3D AC1D V3.4B1
// Copyright (c) 2026 AZYT - Released under the MIT License (see LICENSE).
// Menu base by TORQ.
// Intended for private/offline use. Provided "as is", without warranty.
// ============================================================================

// R3D AC1D V3.4B1 - BO2 Multiplayer DeadOps PS4/PS5 port
// Install as: /data/DeadOps/t6_mp/_clientids.gsc
// Converted from main.gsc + Functions(1).gsc + Maps.gsc + Notify.gsc
// The DeadOps.sprx loader compiles this plain GSC when a match is started.
// Multiplayer only. Not compatible with t6_zm without a separate rewrite.

#include maps\mp\gametypes\_hud;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\_utility;
#include common_scripts\utility;
#include maps\mp\teams\_teams;
#include maps\mp\killstreaks\_ai_tank;
#include maps\mp\killstreaks\_remotemissile;
#include maps\mp\killstreaks\_killstreaks;
#include maps\mp\gametypes\_weapons;
#include maps\mp\_development_dvars;
#include maps\mp\gametypes\_hud_message;
#include maps\mp\gametypes\_globallogic;
#include maps\mp\gametypes\_rank;
#include maps\mp\killstreaks\_turret_killstreak;
#include maps\mp\killstreaks\_supplydrop;
#include maps\mp\gametypes\_spectating;

init()
{   
    precacheModel("t6_wpn_supply_drop_ally");
    PrecacheShader("compass_emp");
    PrecacheShader("menu_camo_carbon_pattern"); 
    PrecacheShader("gradient_fadein");  
   	precacheShader("headicon_dead");
    PrecacheShader("gradient");
    PrecacheShader("black");             
    level thread onPlayerConnect();
    level.clientid = 0;
    level.currentTimescale = 0;
    level.result = 0;
	level.deads = "headicon_dead";
	level.esps = "hud_remote_missile_target";
}

onPlayerConnect()
{
    for(;;)
    {
        level waittill("connected", player);
        player.MenuInit = false;
        
        if(player isHost())
             player.status = "Host";
        else
             player.status = "Unverified";
             
        if(player isVerified())
             player giveMenu();
             
        player thread onPlayerSpawned();
        player.clientid = level.clientid;
        level.clientid++;
    }
}

onPlayerSpawned()
{
     self endon("disconnect");
     level endon("game_ended");
     isFirstSpawn = true;
     self freezecontrols(false);
     for(;;)
     {
          self waittill("spawned_player");
          // Reset explosive bullets after each respawn (worker ends on death).
          self notify("StopExplosiveBullets");
          self.explosiveBulletsEnabled = false;
          if(isFirstSpawn)
          {
               if (self isHost()) // The if (self isHost()) line is a self host checker, so any code that is in this function it only shows for the host!
               {
                    self iprintln("ADS + Melee ^6To Open"); // this shows a text on the left side 
                    self iprintln("^4Black ^6OPS II: ^1R3D ^3AC1D ^FV3.4B1 ^2Now ^1Running!"); // this shows a text on the left side 
                              wait 0.05;
                    self iprintln("^6Menu Built by: AZYT");
                              wait 0.35;
                    self iprintln("^2Menu Base By: TORQ");
                              
                    thread overflowfix();
                    self thread welcomeMessage();
               }
               isFirstSpawn = false;
          }
         
     }
}
welcomeMessage()
{
    self endon("disconnect");
    level endon("game_ended");

    // Wait out the pre-match intro so the game's own splash doesn't cover it.
    while(isDefined(level.inPrematchPeriod) && level.inPrematchPeriod)
        wait 0.05;
    wait 1.5;

    // Own popup instead of the stock notify: the stock one is locked to
    // screen center (overlaps the menu) and left the third line stuck on screen.
    // Move it with popX / popY (negative x = further left).
    popX = -170;
    popY = 30;

    title = self createFontString("objective", 2.0);
    title setPoint("CENTER", "TOP", popX, popY);
    title setText("^1R3D ^7AC1D ^1V3.4B1");
    title.glowColor = (0.85, 0.05, 0.10);
    title.glowAlpha = 1;
    title.alpha = 0;
    title.foreground = true;
    title.archived = false;
    title.hideWhenInMenu = false;

    sub1 = self createFontString("objective", 1.4);
    sub1 setPoint("CENTER", "TOP", popX, popY + 22);
    sub1 setText("^7BO2 GSC MOD MENU");
    sub1.alpha = 0;
    sub1.foreground = true;
    sub1.archived = false;
    sub1.hideWhenInMenu = false;

    sub2 = self createFontString("objective", 1.2);
    sub2 setPoint("CENTER", "TOP", popX, popY + 38);
    sub2 setText("^7ADS + Melee to open");
    sub2.alpha = 0;
    sub2.foreground = true;
    sub2.archived = false;
    sub2.hideWhenInMenu = false;

    title FadeOverTime(0.5);  title.alpha = 1;
    sub1  FadeOverTime(0.5);  sub1.alpha = 1;
    sub2  FadeOverTime(0.5);  sub2.alpha = 1;
    wait 6;
    title FadeOverTime(0.5);  title.alpha = 0;
    sub1  FadeOverTime(0.5);  sub1.alpha = 0;
    sub2  FadeOverTime(0.5);  sub2.alpha = 0;
    wait 0.6;
    title destroy();
    sub1 destroy();
    sub2 destroy();
}

overflowfix()
{
     level endon("game_ended");
     level.test = createServerFontString("default",1.5);
     level.test setText("xTUL");
     level.test.alpha = 0;
     for(;;)
     {
          level waittill("textset");
          if(level.result >= 50)
          {
               level.test ClearAllTextAfterHudElem();
               level.result = 0;
               foreach(player in level.players)
               {
                    if(isDefined(player.menu) && isDefined(player.menu.open) && player.menu.open)
                    {
                         player recreateText();
                    }
               }
          }
          wait 0.01;
     }
}

recreateText()
{
     self endon("disconnect");
     self endon("death");
     
     if(!isDefined(self.CurMenu) || !isDefined(self.CurTitle))
         return;
     input = self.CurMenu;
     title = self.CurTitle;
     
     self thread submenu(input, title);
}

giveMenu()
{
     if (self isVerified())
     {
          if (!self.MenuInit)
          {
               self.MenuInit = 1;
               self thread MenuInit();
          }
     }
}

isVerified()
{
     if (self.status == "Host" || self.status == "Verified" || self.status == "VIP" || self.status == "Admin" || self.status == "Co-Host")
     {
          return true;
     }
     else
     {
          return false;
     }
}

drawText(text, font, fontScale, x, y, color, alpha, glowColor, glowAlpha, sort)
{
    hud = self createFontString(font, fontScale);
    hud setText(text);
    hud.x = x;
    hud.y = y;
    hud.color = color;
    hud.alpha = alpha;
    hud.glowColor = glowColor;
    hud.glowAlpha = glowAlpha;
    hud.sort = sort;
    hud.alpha = alpha;
    
    level.result += 1;
    hud setText(text);
    level notify("textset");
    
    return hud;
}

drawShader(shader, x, y, width, height, color, alpha, sort)
{
    hud = newClientHudElem(self);
    hud.elemtype = "icon";
    hud.color = color;
    hud.alpha = alpha;
    hud.sort = sort;
    hud.children = [];
    if(isDefined(level.uiParent))
        hud setParent(level.uiParent);
    hud setShader(shader, width, height);
    hud.x = x;
    hud.y = y;
    return hud;
}

changeVerificationMenu(player, verlevel)
{
     if (player.status != verlevel && !player isHost())
     {
          player notify("statusChanged");
          player.status = verlevel;
          wait 0.05;
          player giveMenu();
          
          if(player.status == "Unverified")
          {
               player thread destroyMenu(player);
          }
          if(player isVerified())
          {
               self iprintln("^7 " + getPlayerName(player) + " Is Now " + verificationToColor(verlevel));
               player iPrintln("^2You Are Now" + verificationToColor(verlevel));
               player iprintln("^3Press ADS + Melee ^2To Open The Menu");
          }
     }
     else
     {
          if (player isHost())
              self iPrintln("You Cannot Change The Access Level of The " + verificationToColor(player.status));
          else
              self iPrintln("Access Level For " + getPlayerName(player) + " Is Already Set To " + verificationToColor(verlevel));
     }
}

changeVerification(player, verlevel)
{
     player notify("statusChanged");
     player.status = verlevel;
     wait 0.05;
     player giveMenu();
     
     if(player.status == "Unverified")
     {
          player thread destroyMenu(player);
          player iPrintln("^6Sorry You don't have access!");
     }
     if(player isVerified())
     {
          player iPrintln("^1You Are Now" + verificationToColor(verlevel));
          player iprintln("^1Press^2 ADS + Melee ^2To Open The Menu");
     }
}

getPlayerName(player)
{
    playerName = getSubStr(player.name, 0, player.name.size);
    for(i=0; i < playerName.size; i++)
    {
        if(playerName[i] == "]")
            break;
    }
    if(playerName.size != i)
        playerName = getSubStr(playerName, i + 1, playerName.size);
    return playerName;
}

verificationToNum(status)
{
    if (status == "Host") //HOST
        return 5;
    if (status == "Co-Host") // Co-Host
        return 4;
    if (status == "Admin") // Admin
        return 3;
    if (status == "VIP") // VIP
        return 2;
    if (status == "Verified") // Verified
        return 1;
    else
        return 0;
}

verificationToColor(status)
{
    if (status == "Host")
        return "^2Host";
    if (status == "Co-Host")
        return "^2Co-Host";
    if (status == "Admin")
        return "^2Admin";
    if (status == "VIP")
        return "^2VIP";
    if (status == "Verified")
        return "^2Verified";
    else
        return "^2Unverified";
}

Iif(bool, rTrue, rFalse)
{
    if(bool)
        return rTrue;
    else
        return rFalse;
}

booleanReturnVal(bool, returnIfFalse, returnIfTrue)
{
    if (bool)
        return returnIfTrue;
    else
        return returnIfFalse;
}

booleanOpposite(bool)
{
    if(!isDefined(bool))
        return true;
    if (bool)
        return false;
    else
        return true;
}

CreateMenu()
{
     self add_menu("Main Menu", Undefined, "Verified");
     self add_option("Main Menu", "^1User Menu", ::submenu, "Sub Option 1", "Sub Option 1");
     self add_option("Main Menu", "^1Weapon Menu", ::submenu, "Sub Option 9", "Sub Option 9");  
     self add_option("Main Menu", "^1Vision Menu", ::submenu, "Sub Option 7", "Sub Option 7");
     self add_option("Main Menu", "^1Streaks Menu", ::submenu, "Sub Option 8", "Sub Option 8");
     self add_option("Main Menu", "^1Notify Menu", ::submenu, "Sub Option 3", "Sub Option 3");
     self add_option("Main Menu", "^1Game Menu", ::submenu, "Sub Option 4", "Sub Option 4");
     self add_option("Main Menu", "^1Vip Menu", ::submenu, "Sub Option 10", "Sub Option 10");
     self add_option("Main Menu", "^1Host Menu", ::submenu, "Sub Option 11", "Sub Option 11");       
     self add_option("Main Menu", "^1Verify Menu", ::submenu, "PlayersMenu", "Players Menu");
     self add_option("Main Menu", "^1Forge Menu", ::submenu, "Forge Menu", "Forge Menu");

     self add_menu("Teleport Menu", "Sub Option 10", "VIP");
     self add_option("Teleport Menu", "^2Save location A", ::v36SaveA);
     self add_option("Teleport Menu", "^2Return to A", ::v36LoadA);
     self add_option("Teleport Menu", "^2Save location B", ::v36SaveB);
     self add_option("Teleport Menu", "^2Return to B", ::v36LoadB);
     self add_option("Teleport Menu", "^2Map teleport", ::doTeleport);

     self add_menu("Forge Menu", "Main Menu", "Host");
     self add_option("Forge Menu", "^1Forge Pickup", ::forge);
     self add_option("Forge Menu", "^1Spawn crate", ::forgeBuild, 1);
     self add_option("Forge Menu", "^1Build platform 2x2", ::forgeBuild, 2);
     self add_option("Forge Menu", "^1Build platform 3x3", ::forgeBuild, 3);
     self add_option("Forge Menu", "^1Undo last build", ::forgeUndo);
     self add_option("Forge Menu", "Forge help", ::v36ForgeHelp);






     
     
     self add_menu("Sub Option 1", "Main Menu", "Verified"); 
     self add_option("Sub Option 1", "^1GodMode", ::God_Toggle);  
     self add_option("Sub Option 1", "^1Auto TBag", ::tbag); 
     self add_option("Sub Option 1", "^1Noclip", ::NoclipMode);
     self add_option("Sub Option 1", "^1Invisibility", ::invis);     
     self add_option("Sub Option 1", "^1healthbar", ::healthbar); 
     self add_option("Sub Option 1", "^1End it All", ::commitsuicide);
     self add_option("Sub Option 1", "^1Hide Gun", ::nogun); 
     self add_option("Sub Option 1", "^1Change Fov", ::togglefov);
     self add_option("Sub Option 1", "^1Draw Fps", ::ShowFPS);
     self add_option("Sub Option 1", "^2User Menu+", ::submenu, "Sub Option 1.1", "Sub Option 1");



     self add_menu("Sub Option 1.1", "Sub Option 1", "Verified");
     self add_option("Sub Option 1.1", "^1Third Person", ::toggleThirdPerson);
     self add_option("Sub Option 1.1", "^1Multi Jump", ::toggleMultiJump);
     self add_option("Sub Option 1.1", "^1Floaters", ::toggleFloaters);
     self add_option("Sub Option 1.1", "^1Dead clone", ::clonedead);
     self add_option("Sub Option 1.1", "^1Alive clone", ::cloneAlive);
       
       

     self add_menu("Sub Option 2", "Sub Option 11", "Co-Host"); 
     self add_option("Sub Option 2", "^1-^4-^2-^4-^1Map Selection^1-^2-^2-^4-", ::Ceers);
     self add_option("Sub Option 2", "^2Popular ^1Maps", ::submenu, "Sub Option 2.2", "Sub Option 2");     
     self add_option("Sub Option 2", "^2Normal ^1Maps", ::submenu, "Sub Option 2.3", "Sub Option 2");   
     self add_option("Sub Option 2", "^2DLC ^1Maps", ::submenu, "Sub Option 2.4", "Sub Option 2");  
     self add_option("Sub Option 2", "^1-^4-^2-^4-^1Map Selection^1-^2-^2-^4-", ::Ceers);

     
     
     self add_menu("Sub Option 2.2", "Sub Option 2", "Co-Host");
     self add_option("Sub Option 2.2", "^1Nuketown", ::Nuketown);
     self add_option("Sub Option 2.2", "^1Express", ::Express);
     self add_option("Sub Option 2.2", "^1Standoff", ::Standoff);  
     self add_option("Sub Option 2.2", "^1Cargo", ::Cargo); 
     self add_option("Sub Option 2.2", "^1Carrier", ::Carrier);
     self add_option("Sub Option 2.2", "^1Hijacked", ::Hijacked);            
     
     
     
     self add_menu("Sub Option 2.3", "Sub Option 2", "Co-Host");
     self add_option("Sub Option 2.3", "^1Meltdown", ::Meltdown);
     self add_option("Sub Option 2.3", "^1Drone", ::Drone);
     self add_option("Sub Option 2.3", "^1Overflow", ::Overflow);
     self add_option("Sub Option 2.3", "^1Slums", ::Slums);
     self add_option("Sub Option 2.3", "^1Turbine", ::Turbine);
     self add_option("Sub Option 2.3", "^1Raid", ::Raid);
     self add_option("Sub Option 2.3", "^1Aftermath", ::Aftermath);
     self add_option("Sub Option 2.3", "^1Plaza", ::Plaza);
     self add_option("Sub Option 2.3", "^1Yemen", ::Yemen);



     self add_menu("Sub Option 2.4", "Sub Option 2", "Co-Host");   							
     self add_option("Sub Option 2.4", "^1Skate", ::skate);     
     self add_option("Sub Option 2.4", "^1studio", ::studio);       
     self add_option("Sub Option 2.4", "^1paintball", ::paintball);       
     self add_option("Sub Option 2.4", "^1hydro", ::hydro);       
     self add_option("Sub Option 2.4", "^1mirage", ::mirage);       
     self add_option("Sub Option 2.4", "^1uplink", ::uplink);      
     self add_option("Sub Option 2.4", "^1detour", ::detour);       
     self add_option("Sub Option 2.4", "^1cove", ::cove);       
     self add_option("Sub Option 2.4", "^1magma", ::magma);
     self add_option("Sub Option 2.4", "^2DLC+", ::submenu, "Sub Option 2.44", "Sub Option 2"); 
     
     
     
     self add_menu("Sub Option 2.44", "Sub Option 2.4", "Co-Host"); 
     self add_option("Sub Option 2.44", "^1vertigo", ::vertigo);       
     self add_option("Sub Option 2.44", "^1concert", ::concert);       
     self add_option("Sub Option 2.44", "^1downhill", ::downhill);      
     self add_option("Sub Option 2.44", "^1frostbite", ::frostbite);       
     self add_option("Sub Option 2.44", "^1takeoff", ::takeoff);       
     self add_option("Sub Option 2.44", "^1pod", ::pod);       
     self add_option("Sub Option 2.44", "^1dig", ::dig); 
     
     


     

     self add_menu("Sub Option 3", "Main Menu", "Host"); 
     self add_option("Sub Option 3", "^1-^4-^2-^4-^1Menu messages^1-^2-^2-^4-", ::Ceers);
     self add_option("Sub Option 3", "^1Messages 1", ::submenu, "Sub Option 3.2", "Sub Option 3");     
     self add_option("Sub Option 3", "^1Messages 2", ::submenu, "Sub Option 3.3", "Sub Option 3");   
     self add_option("Sub Option 3", "^1Messages 3", ::submenu, "Sub Option 3.4", "Sub Option 3");
     self add_option("Sub Option 3", "^1-^4-^2-^4-^1Menu messages^1-^2-^2-^4-", ::Ceers);

     
     
     
     
     self add_menu("Sub Option 3.2", "Sub Option 3", "Host"); 
     self add_option("Sub Option 3.2", "^1Menu Version", ::msg);
     self add_option("Sub Option 3.2", "^1Creator", ::msg2);
     self add_option("Sub Option 3.2", "^1Build for", ::msgg); 
     self add_option("Sub Option 3.2", "^1Source Menu", ::msgb); 
     self add_option("Sub Option 3.2", "^1Free Hosting", ::msga);     
     self add_option("Sub Option 3.2", "^1Offline Menu", ::msg9);
     
     
     self add_menu("Sub Option 3.3", "Sub Option 3", "Host");
     self add_option("Sub Option 3.3", "^1YES", ::msgyes);
     self add_option("Sub Option 3.3", "^1NO", ::msgno);
     self add_option("Sub Option 3.3", "^1STFU", ::msgga1);    
     self add_option("Sub Option 3.3", "^1MORON", ::msgga2);    
     self add_option("Sub Option 3.3", "^1WHY", ::msgwhy);
     self add_option("Sub Option 3.3", "^1Get Out", ::msggbb);  
     
     
     
     self add_menu("Sub Option 3.4", "Sub Option 3", "Host");
     self add_option("Sub Option 3.4", "^1Crack Addict", ::msgc);
     self add_option("Sub Option 3.4", "^1FKUOH", ::msgd);
     self add_option("Sub Option 3.4", "^1Menu promo", ::msge);
     self add_option("Sub Option 3.4", "^1Green Grass", ::msgf); 
     self add_option("Sub Option 3.4", "^1BO2OT", ::msg0);  
     
     

     
     self add_menu("Sub Option 4", "Main Menu", "Co-Host");
     self add_option("Sub Option 4", "^2Bot Menu", ::submenu, "Sub Option 6", "Sub Option 4");
     self add_option("Sub Option 4", "^2XP Menu", ::submenu, "Sub Option 5", "Sub Option 4");
     self add_option("Sub Option 4", "^1Flashing Killfeed", ::flashfeed2);
     self add_option("Sub Option 4", "^1KnockBack", ::knock);  
     self add_option("Sub Option 4", "^2Game Settings", ::submenu, "Game Settings", "Game Settings");
     // Retain the former Game Menu+ host-only access.
     if(verificationToNum(self.status) >= verificationToNum("Host"))
     {
          self add_option("Sub Option 4", "^1Floating Bodies", ::floater);
          self add_option("Sub Option 4", "^1Remove kill barrier", ::removedbarrier);
          self add_option("Sub Option 4", "^1Vsat 24/7", ::alwaysVSAT);
          self add_option("Sub Option 4", "^1Sky color", ::dosky);
          self add_option("Sub Option 4", "^1No Fall Damage", ::dofalldamage);
     }





     self add_menu("Sub Option 5", "Sub Option 4", "Host");
     self add_option("Sub Option 5", "^1Max Xp", ::X9XP);
     self add_option("Sub Option 5", "^1+420XP", ::WDXP);     
     self add_option("Sub Option 5", "^1Normal XP", ::BO2N); 
     self add_option("Sub Option 5", "^1Cod 4 XP", ::CODXP); 
     self add_option("Sub Option 5", "^1+1 XP", ::A1XP);
     self add_option("Sub Option 5", "^1Death XP", ::DMXP);
     self add_option("Sub Option 5", "^1Double XP", ::X2BO2);
     self add_option("Sub Option 5", "^1Triple XP", ::X3BO2);
     self add_option("Sub Option 5", "^1Boosted XP", ::Boosted);          
     

     
     self add_menu("Sub Option 6", "Sub Option 4", "Host"); 
     self add_option("Sub Option 6", "^1-^4-^2-^4-^1Bot Options^1-^2-^2-^4-", ::Ceers);
     self add_option("Sub Option 6", "^3Spawning ^2info", ::BOT2INFO);
     self add_option("Sub Option 6", "^1Bot Options", ::submenu, "Sub Option 6.2", "Sub Option 6");  
     self add_option("Sub Option 6", "^1Bot Spawning", ::submenu, "Sub Option 6.3", "Sub Option 6");   
     self add_option("Sub Option 6", "^1-^4-^2-^4-^1Bot Options^1-^2-^2-^4-", ::Ceers);

     
     
     self add_menu("Sub Option 6.2", "Sub Option 6", "Host");
     self add_option("Sub Option 6.2", "^1Freeze Bots", ::FreezeBots);
     self add_option("Sub Option 6.2", "^1Tele Bots", ::TeleBots);
     self add_option("Sub Option 6.2", "^1Kick Bots", ::kAB); 
     
     
     
     self add_menu("Sub Option 6.3", "Sub Option 6", "Host");
     self add_option("Sub Option 6.3", "^1Spawn 1", ::SpawnBot1);
     self add_option("Sub Option 6.3", "^2Spawn 2", ::SpawnBot2);
     self add_option("Sub Option 6.3", "^3Spawn 3", ::SpawnBot3);     
     self add_option("Sub Option 6.3", "^4Spawn 4", ::SpawnBot4); 
     self add_option("Sub Option 6.3", "^5Spawn 5", ::SpawnBot5);     
     self add_option("Sub Option 6.3", "^2Spawn 6", ::SpawnBot6);
     self add_option("Sub Option 6.3", "^7Spawn 7", ::SpawnBot7);     
     self add_option("Sub Option 6.3", "^8Spawn 8", ::SpawnBot8);
     self add_option("Sub Option 6.3", "^9Spawn 9", ::SpawnBot9);     
     self add_option("Sub Option 6.3", "^1Spawn 10", ::SpawnBot10);  
     
     

     
     self add_menu("Sub Option 7", "Main Menu", "Verified");
     self add_option("Sub Option 7", "^1Black and White", ::BWV);
     self add_option("Sub Option 7", "^1Light Vision", ::LVis);
     self add_option("Sub Option 7", "^1Enhanced Vision", ::EV);
     self add_option("Sub Option 7", "^1Infrared Vision", ::infrarV); 
     self add_option("Sub Option 7", "^1Water Vision", ::WVis);
     self add_option("Sub Option 7", "^1Poison Vision", ::PVis);
     self add_option("Sub Option 7", "^1Flare", ::setVision, "flare", "Flare");
     self add_option("Sub Option 7", "^1Mortar Infrared", ::setVision, "remote_mortar_infrared", "Mortar Infrared");
     self add_option("Sub Option 7", "^2Reset Vision", ::resetVision);


     
     

     self add_menu("Sub Option 8", "Main Menu", "VIP");
     self add_option("Sub Option 8", "^1Max Streak Score", ::doKillstreaks);
     self add_option("Sub Option 8", "^1Give Equipped", ::GiveEquipped);
     self add_option("Sub Option 8", "^1Give UAV", ::GiveUAV);
     self add_option("Sub Option 8", "^1Give RC-XD", ::GiveRC);
     self add_option("Sub Option 8", "^1Give guardian", ::GiveGuard);
     self add_option("Sub Option 8", "^1Give HellStorm", ::GiveHell);
     self add_option("Sub Option 8", "^1Give S.Chopper ", ::GiveSC); 
     self add_option("Sub Option 8", "^1Give VSAT", ::GiveVSAT);
     self add_option("Sub Option 8", "^1Give Escort.D", ::GiveED); 
     self add_option("Sub Option 8", "^2Streak Menu+", ::submenu, "Sub Option 8.1", "Sub Option 8");  
     



     self add_menu("Sub Option 8.1", "Sub Option 8", "VIP"); 
     self add_option("Sub Option 8.1", "^1Give Warthog", ::GiveWH);
     self add_option("Sub Option 8.1", "^1Give Lodestar", ::GiveLST);
     self add_option("Sub Option 8.1", "^1Give VTOL.W", ::GiveVW);
     self add_option("Sub Option 8.1", "^1Give Dogs", ::GiveDogs);  
     self add_option("Sub Option 8.1", "^1Give Swarm", ::GiveSwarm);  
     self add_option("Sub Option 8.1", "^1Give A.G.R", ::GiveAG); 
     self add_option("Sub Option 8.1", "^1Give EMP ", ::GiveEMP);



    
     self add_menu("Sub Option 9", "Main Menu", "Verified"); 
     self add_option("Sub Option 9", "^2Weapon Selection #1", ::submenu, "Sub Option 9.1", "Sub Option 9");     
     self add_option("Sub Option 9", "^2Weapon Selection #2", ::submenu, "Sub Option 9.2", "Sub Option 9"); 
     self add_option("Sub Option 9", "^1-^4-^2-^4-^1Weapon Mods^1-^2-^2-^4-", ::Ceers);   
     self add_option("Sub Option 9", "^1ChangeClass", ::ChangeClass);
     self add_option("Sub Option 9", "^1Random Camo", ::randomcamo);  
     self add_option("Sub Option 9", "^1Low ammo flash", ::flashlowammo); 
     self add_option("Sub Option 9", "^1Disco Camo", ::Toggle_DiscoCamo);
     self add_option("Sub Option 9", "^1Random Gun Drop", ::dropCanSwap);
     self add_option("Sub Option 9", "^2Weapon Menu+", ::submenu, "Sub Option 9.3", "Sub Option 9"); 
     
     
    
    
     self add_menu("Sub Option 9.3", "Sub Option 9", "Verified");
     self add_option("Sub Option 9.3", "^1Unlimited Ammo", ::unammo);  
     self add_option("Sub Option 9.3", "^1No Recoil", ::norecoil); 
     self add_option("Sub Option 9.3", "^1No Spread", ::nospread); 
     self add_option("Sub Option 9.3", "^1Rapid Fire", ::rapidfire);
     self add_option("Sub Option 9.3", "^1Left Hand", ::ToggleLeft);
     self add_option("Sub Option 9.3", "^1EB Bullet", ::explosivebullets);
     
     

     
     self add_menu("Sub Option 9.1", "Sub Option 9", "Verified");
     self add_option("Sub Option 9.1", "^1An94", ::an94);
     self add_option("Sub Option 9.1", "^1Type95", ::type95);         
     self add_option("Sub Option 9.1", "^1Xm8", ::xm8);      
     self add_option("Sub Option 9.1", "^1As50", ::as50);
     self add_option("Sub Option 9.1", "^1Dsr50", ::dsr50);
     self add_option("Sub Option 9.1", "^1Ballista", ::ballista);
     self add_option("Sub Option 9.1", "^1Fivesevendw", ::fivesevendw); 
     self add_option("Sub Option 9.1", "^2Weapons+", ::submenu, "Sub Option 9.11", "Sub Option 9"); 
     
     
     
     
     self add_menu("Sub Option 9.11", "Sub Option 9.1", "Verified");    
     self add_option("Sub Option 9.11", "^1Mk48", ::mk48);       
     self add_option("Sub Option 9.11", "^1Mp7", ::mp7);         
     self add_option("Sub Option 9.11", "^1Ksg", ::ksg);    
     self add_option("Sub Option 9.11", "^1Lsat", ::lsat);   
     self add_option("Sub Option 9.11", "^1Hamr", ::hamr); 
     
     
     
  
     
     self add_menu("Sub Option 9.2", "Sub Option 9", "Verified");
     self add_option("Sub Option 9.2", "^1Tar21", ::tar21);  
     self add_option("Sub Option 9.2", "^1Vector", ::vector);  
     self add_option("Sub Option 9.2", "^1Kap-40", ::karddw);
     self add_option("Sub Option 9.2", "^1Tac-45", ::fnp45);     
     self add_option("Sub Option 9.2", "^1Peacekeeper", ::peacekeeper);   
     self add_option("Sub Option 9.2", "^1Scar", ::scar); 
     self add_option("Sub Option 9.2", "^2Weapons+", ::submenu, "Sub Option 9.22", "Sub Option 9"); 
     
     
     
     
     self add_menu("Sub Option 9.22", "Sub Option 9.2", "Verified");
     self add_option("Sub Option 9.22", "^1Crossbow", ::crossbow);
     self add_option("Sub Option 9.22", "^1Mcs870", ::mcs870);  
     self add_option("Sub Option 9.22", "^1Riotshield", ::riotshield); 
     self add_option("Sub Option 9.22", "^1Minigun", ::minigun);       



     
     
     self add_menu("Sub Option 10", "Main Menu", "VIP");   
     self add_option("Sub Option 10", "^2Teleport Menu", ::submenu, "Teleport Menu", "Teleport Menu");
     self add_option("Sub Option 10", "^2Infection menu", ::submenu, "Sub Option 10.1", "Sub Option 10");  
     self add_option("Sub Option 10", "^1Add all perks", ::doPerks);
     self add_option("Sub Option 10", "^1Remove perks", ::PerksRemoveSelf);   
     self add_option("Sub Option 10", "^1Change Team", ::initTeamChange); 
     self add_option("Sub Option 10", "^1Rank 55", ::dorank);  
     self add_option("Sub Option 10", "^1Master Prestige", ::domaster); 
     self add_option("Sub Option 10", "^1Unlock camos", ::CamosBarThing);  
     
     
     
     
     self add_menu("Sub Option 10.1", "Sub Option 10", "Host");
     self add_option("Sub Option 10.1", "^2g_speed", ::testinfect); 
     self add_option("Sub Option 10.1", "^2melee Range", ::testinfect1);
     self add_option("Sub Option 10.1", "^2ladderPushVel", ::testinfect2);
     self add_option("Sub Option 10.1", "^2namessizes", ::testinfect3);
     self add_option("Sub Option 10.1", "^2knockback", ::testinfect4);
     self add_option("Sub Option 10.1", "^2killcam timer", ::testinfect5);
     self add_option("Sub Option 10.1", "^2drawThroughWalls", ::testinfect6);
     self add_option("Sub Option 10.1", "^2skyColor", ::testinfect7);
     self add_option("Sub Option 10.1", "^2Migration disabled", ::testinfect8);
     
     

     
     self add_menu("Sub Option 11", "Main Menu", "Host");
     self add_option("Sub Option 11", "^2Host Menu+", ::submenu, "Host Menu+", "Host Menu+");
     self add_option("Sub Option 11", "^1Player Menu", ::submenu, "Sub Option 13", "Sub Option 13");  
     self add_option("Sub Option 11", "^3Aimbot menu", ::submenu, "Sub Option 12", "Sub Option 11"); 
     self add_option("Sub Option 11", "^2Maps Changer", ::submenu, "Sub Option 2", "Sub Option 11"); 
     

     
     
     self add_menu("Host Menu+", "Sub Option 11", "Host");
     self add_option("Host Menu+", "^1Fake EndGame", ::FakeEndGame); 
     self add_option("Host Menu+", "^1Toggle Ranked", ::ToggleRanked);
     self add_option("Host Menu+", "^1No timeLimit", ::unlimtime); 
     self add_option("Host Menu+", "^1Block Joins", ::Joinblock);   
     self add_option("Host Menu+", "^1AntiQuit", ::AntiQuitV3); 
     self add_option("Host Menu+", "^1Insta End", ::instaEnd);
     self add_option("Host Menu+", "^1EndGame", ::endGame); 
     self add_option("Host Menu+", "Restart match", ::doRestart);
     self add_option("Host Menu+", "^1ForceHost", ::forceHost);   
     self add_option("Host Menu+", "^1meleerange", ::meleerange);  
     self add_option("Host Menu+", "^11Min Kill cam", ::killcam6); 

     self add_menu("Sub Option 12", "Sub Option 11", "Host");
     self add_option("Sub Option 12", "^2Wallhack", ::ToggleWallHack);
     self add_option("Sub Option 12", "^3Legit aim", ::tgl_MainRootAimbot2); 
     self add_option("Sub Option 12", "^3Legit no aim", ::tgl_MainRootAimbot1);    
     self add_option("Sub Option 12", "^3Knife Aim", ::TAK);
     self add_option("Sub Option 12", "^3Super Aim", ::doAimbots13); 
     self add_option("Sub Option 12", "^3TS Aim", ::doAimbots12);
     
      
      
      

     self add_menu("Game Settings", "Sub Option 4", "Host");
     self add_option("Game Settings", "Score limit 50", ::v36Score50);
     self add_option("Game Settings", "Score limit 100", ::v36Score100);
     self add_option("Game Settings", "Unlimited score", ::v36ScoreUnlimited);
     self add_option("Game Settings", "Restore score limit", ::v36ScoreRestore);
     self add_option("Game Settings", "^1Add 1min", ::addtime);    
     self add_option("Game Settings", "^1Remove 1min", ::removetime);     
     self add_option("Game Settings", "^1Superjump", ::superjump);
     self add_option("Game Settings", "^1Gravity", ::gravity);
     self add_option("Game Settings", "^1Super Walk", ::SuperFastWalk);
     self add_option("Game Settings", "^1INF Game", ::Inf_Game);     
     self add_option("Game Settings", "^1Timescale", ::Timescales); 
     
     
     
   

     
     
     self add_menu("Sub Option 13", "Sub Option 11", "Admin");
     self add_option("Sub Option 13", "^1List player count", ::v36PlayerCount);
     self add_option("Sub Option 13", "^1Show my team", ::v36MyTeam);
     self add_option("Sub Option 13", "^1Open player list", ::v36PlayerListHelp);
     self add_option("Sub Option 13", "^1Kill All", ::killall);
     self add_option("Sub Option 13", "^1Blind All", ::blindall);
     self add_option("Sub Option 13", "^1Unlim. Ammo All", ::infiniteammoall); 
     self add_option("Sub Option 13", "^1Disco Camo All", ::discocamoall);  
     self add_option("Sub Option 13", "^1Freeze All", ::freezeallplayers); 
     self add_option("Sub Option 13", "^1Fake Derank all", ::FakeDerankAll);  
     self add_option("Sub Option 13", "^1Send all to space", ::sendalltospace);
     self add_option("Sub Option 13", "^1hear all", ::hearallplayers);
     
     


     self add_menu("PlayersMenu", "Main Menu", "Admin");
     for (i = 0;i < level.players.size;i++)
     { 
     self add_menu("pOpt " + i, "PlayersMenu", "Co-Host");
     }
}

updatePlayersMenu()
{
     self.menu.menucount["PlayersMenu"] = 0;
     self.menu.menuopt["PlayersMenu"] = [];
     self.menu.menufunc["PlayersMenu"] = [];
     self.menu.menuinput["PlayersMenu"] = [];
     self.menu.menuinput1["PlayersMenu"] = [];
     for (i = 0;i < level.players.size;i++)
     {
          player = level.players[i];
          playerName = getPlayerName(player);
          
          playersizefixed = level.players.size - 1;
          if(self.menu.curs["PlayersMenu"] > playersizefixed)
          {
               self.menu.scrollerpos["PlayersMenu"] = playersizefixed;
               self.menu.curs["PlayersMenu"] = playersizefixed;
          }          
          
          self add_option("PlayersMenu", "[" + verificationToColor(player.status) + "^7] " + playerName, ::submenu, "pOpt " + i, "[" + verificationToColor(player.status) + "^7] " + playerName); // Dont change or remove this
          self add_menu_alt("pOpt " + i, "PlayersMenu");
          self add_option("pOpt " + i, "^1Give Co-Host", ::changeVerificationMenu, player, "Co-Host"); // Dont change or remove this
          self add_option("pOpt " + i, "^1Give Admin", ::changeVerificationMenu, player, "Admin"); // Dont change or remove this
          self add_option("pOpt " + i, "^1Give VIP", ::changeVerificationMenu, player, "VIP"); // Dont change or remove this
          self add_option("pOpt " + i, "^1Verify", ::changeVerificationMenu, player, "Verified"); // Dont change or remove this
          self add_option("pOpt " + i, "^1Unverify", ::changeVerificationMenu, player, "Unverified"); // Dont change or remove this
   
   }
   
}


add_menu_alt(Menu, prevmenu)
{
     if(!isDefined(self.menu.status[Menu]))
         self.menu.status[Menu] = "Co-Host";
     if(!isDefined(self.menu.curs[Menu]))
         self.menu.curs[Menu] = 0;
     if(!isDefined(self.menu.scrollerpos[Menu]))
         self.menu.scrollerpos[Menu] = 0;
     self.menu.getmenu[Menu] = Menu;
     self.menu.menucount[Menu] = 0;
     self.menu.previousmenu[Menu] = prevmenu;
     self.menu.menuopt[Menu] = [];
     self.menu.menufunc[Menu] = [];
     self.menu.menuinput[Menu] = [];
     self.menu.menuinput1[Menu] = [];
}

add_menu(Menu, prevmenu, status)
{
     self.menu.status[Menu] = status;
     self.menu.getmenu[Menu] = Menu;
     self.menu.scrollerpos[Menu] = 0;
     self.menu.curs[Menu] = 0;
     self.menu.menucount[Menu] = 0;
     self.menu.previousmenu[Menu] = prevmenu;
     self.menu.menuopt[Menu] = [];
     self.menu.menufunc[Menu] = [];
     self.menu.menuinput[Menu] = [];
     self.menu.menuinput1[Menu] = [];
}

add_option(Menu, Text, Func, arg1, arg2)
{
     Menu = self.menu.getmenu[Menu];
     Num = self.menu.menucount[Menu];
     if(!isDefined(self.menu.menuopt[Menu]))
         self.menu.menuopt[Menu] = [];
     self.menu.menuopt[Menu][Num] = Text;
     self.menu.menufunc[Menu][Num] = Func;
     self.menu.menuinput[Menu][Num] = arg1;
     self.menu.menuinput1[Menu][Num] = arg2;
     self.menu.menucount[Menu] += 1;
}

updateScrollbar()
{
     self.menu.scroller MoveOverTime(self.menu.scrollTime);
     self.menu.scroller.y = self.menu.listY + (self.menu.curs[self.menu.currentmenu] * self.menu.rowH);
     self.menu.scroller.archived = false;
}

openMenu()
{
    self freezeControls(false);
    self setClientUiVisibilityFlag("hud_visible", 0);
    self StoreText("Main Menu", "Home");
    
    
    self.menu.background FadeOverTime(0.30);
    self.menu.background.alpha = self.menu.bgAlpha;
    self.menu.background.archived = false;
    
    self.menu.background1 FadeOverTime(0.30);
    self.menu.background1.alpha = self.menu.fadeAlpha;
    self.menu.background1.archived = false;
    
    
    self.menu.line MoveOverTime(0.10);
    self.menu.line.y = 45;  
    self.menu.line.archived = false;
    self.menu.line.alpha = 1;
    
    if(isDefined(self.swagtext))
    {
        self.swagtext FadeOverTime(0.3);
        self.swagtext.alpha = 0.90;
    }

   

    self updateScrollbar();
    self.menu.open = true;
}

closeMenu()
{
    if(!isDefined(self.menu))
        return;
    if(isDefined(self.menu.options))
    {
        self.menu.options FadeOverTime(0.3);
        self.menu.options.alpha = 0;
    }
    self setClientUiVisibilityFlag("hud_visible", 1);
    if(isDefined(self.subtext1))
    {
        self.subtext1 FadeOverTime(0.3);
        self.subtext1.alpha = 0;
    }
    if(isDefined(self.subtext2))
    {
        self.subtext2 FadeOverTime(0.3);
        self.subtext2.alpha = 0;
    }
    if(isDefined(self.torq))
    {
        self.torq FadeOverTime(0.3);
        self.torq.alpha = 0;
    }
    if(isDefined(self.menu.background))
    {
        self.menu.background FadeOverTime(0.3);
        self.menu.background.alpha = 0;
    }
    if(isDefined(self.menu.background1))
    {
        self.menu.background1 FadeOverTime(0.3);
        self.menu.background1.alpha = 0;
    }
    if(isDefined(self.swagtext))
    {
        self.swagtext FadeOverTime(0.3);
        self.swagtext.alpha = 0;
    }
    if(isDefined(self.menu.title))
    {
        self.menu.title FadeOverTime(0.3);
        self.menu.title.alpha = 0;
    }
    if(isDefined(self.menu.line))
    {
        self.menu.line MoveOverTime(0.3);
        self.menu.line.y = -550;
        self.menu.line.alpha = 0;
    }
    if(isDefined(self.menu.backgroundinfo))
    {
        self.menu.backgroundinfo FadeOverTime(0.3);
        self.menu.backgroundinfo.alpha = 0;
    }
    if(isDefined(self.menu.scroller))
    {
        self.menu.scroller MoveOverTime(0.3);
        self.menu.scroller.y = -510;
    }
    self.menu.open = false;
}

destroyMenu(player)
{
    if(!isDefined(player.menu))
        return;
    player.MenuInit = false;
    player closeMenu();
    wait 0.3;

    if(isDefined(player.menu.options)) player.menu.options destroy();
    if(isDefined(player.menu.background)) player.menu.background destroy();
    if(isDefined(player.menu.background1)) player.menu.background1 destroy();
    if(isDefined(player.menu.scroller)) player.menu.scroller destroy();
    if(isDefined(player.menu.scroller1)) player.menu.scroller1 destroy();
    if(isDefined(player.infos)) player.infos destroy();
    if(isDefined(player.menu.line)) player.menu.line destroy();
    if(isDefined(player.menu.title)) player.menu.title destroy();
    if(isDefined(player.subtext1)) player.subtext1 destroy();
    if(isDefined(player.subtext2)) player.subtext2 destroy();
    if(isDefined(player.torq)) player.torq destroy();
    player notify("destroyMenu");
}

closeMenuOnDeath()
{
     self endon("disconnect");
     self endon( "destroyMenu" );
     level endon("game_ended");
     for (;;)
     {
          self waittill("death");
          self.menu.closeondeath = true;
          self submenu("Main Menu", "Main Menu");
          closeMenu();
          self.menu.closeondeath = false;
     }
}
scaleLol()
{
    self endon("stopScale");
    self endon("disconnect");
    // Slow red/white pulse on the title glow.
    for(;;)
    {
        if(isDefined(self.torq))
            self.torq.glowColor = self.menu.accent;
        wait 0.5;
        if(isDefined(self.torq))
            self.torq.glowColor = (1, 1, 1);
        wait 0.5;
    }
}

StoreShaders()
{
   
   self.menu.background  = self drawShader("compass_emp", self.menu.anchorX, 0, 170, 240, self.menu.bgColor,0,0); // panel
   self.menu.background1 = self drawShader("gradient", self.menu.anchorX, 0, 170, 240, self.menu.fadeColor,0,0); // red fade
   self.menu.line        = self drawShader("black", self.menu.anchorX, 45, 170, 17, self.menu.headColor,0,3); // header bar
   self.menu.scroller    = self drawShader("menu_camo_carbon_pattern", self.menu.anchorX, -100, 170, 17, self.menu.accent, 1, 3); // selection bar
      
}

StoreText(menu, title)
{
    panelHeight = int(self.menu.listY + self.menu.menuopt[menu].size * self.menu.rowH + 13);
    if(panelHeight < 240)
        panelHeight = 240;
    self.menu.background setShader("compass_emp", 170, panelHeight);
    self.menu.background1 setShader("gradient", 170, panelHeight);
    self.menu.currentmenu = menu;
    string                = "";
    if(isDefined(self.menu.title))
        self.menu.title destroy();
    // Section name sits centered inside the 170 x 17 black header bar at y=45.
    // Keep its font small enough for long submenu names and below the PS4 ED subtitle.
    self.menu.title = self createFontString("default", 1.0);
    self.menu.title setPoint("CENTER", "TOP", self.menu.anchorX, 53);
    self.menu.title setText(title);
    self.menu.title.color = (1, 1, 1);
    self.menu.title.alpha = 1;
    self.menu.title.sort = 5;
    self.menu.title.foreground = true;
    self.menu.title.archived = false;
    self notify ("stopScale");
    self thread scaleLol();
    if(isDefined(self.torq))
        self.torq destroy();
    self.torq = self createFontString( "default", 2.0);
    self.torq setPoint( "CENTER", "TOP", self.menu.anchorX, 15);
    self.torq setText("^1R3D ^7AC1D ^1V3.4B1"); // this is the title of the menu, so change it to the name of your menu
    self.torq FadeOverTime(0.3);
    self.torq.alpha = 1;
    self.torq.foreground = true;
    self.torq.archived = false;
    for(i = 0; i < self.menu.menuopt[menu].size; i++)
    { string +=self.menu.menuopt[menu][i] + "\n"; }
    
    if(isDefined(self.subtext1))
        self.subtext1 destroy();
    self.subtext1 = self createFontString( "default", 1.4);
    self.subtext1 setPoint( "CENTER", "TOP", self.menu.anchorX, 35);
    self.subtext1 setText("^7PS4 ED"); // change this to what ever, this is below your title text
    self.subtext1 FadeOverTime(0.3);
    self.subtext1.alpha = 1;
    self.subtext1.foreground = true;
    self.subtext1.archived = false;
    
    
    if(isDefined(self.subtext2))
        self.subtext2 destroy();
    self.subtext2 = self createFontString( "default", 1.3);
    self.subtext2 setPoint( "CENTER", "TOP", self.menu.anchorX, 53);
    self.subtext2 setText(""); //  Text below the version text. This can be anything you want.
    self.subtext2 FadeOverTime(0.3);
    self.subtext2.alpha = 1;
    self.subtext2.foreground = true;
    self.subtext2.archived = false;
    
    
    if(isDefined(self.menu.options))
        self.menu.options destroy();
    self.menu.options = drawText(string, "objective", 1.3, self.menu.anchorX + 30, 68, (1, 1, 1), 0, (0, 0, 0), 0, 4);
    self.menu.options FadeOverTime(0.3);
    self.menu.options.archived = false;
    self.menu.options.alpha = 1;
    self.menu.options setPoint( "LEFT", "LEFT", self.menu.anchorX + 282, -128 ); 
 
}

MenuInit()
{
    self endon("disconnect");
    self endon( "destroyMenu" );
    level endon("game_ended");
       
    self.menu = spawnstruct();
    self.toggles = spawnstruct();
    // GSC associative arrays must exist before we assign nested menu entries.
    self.menu.status = [];
    self.menu.getmenu = [];
    self.menu.scrollerpos = [];
    self.menu.curs = [];
    self.menu.menucount = [];
    self.menu.previousmenu = [];
    self.menu.menuopt = [];
    self.menu.menufunc = [];
    self.menu.menuinput = [];
    self.menu.menuinput1 = [];
     
    self.menu.open = false;
    // Menu HUD x origin (center-relative). Original x=235; shift 120 left.
    // Shader positions, section labels and option text all derive from this.
    self.menu.anchorX = 115;
    // ---- UI CONFIG: edit these to restyle the menu ----
    self.menu.listY      = 68;                  // y of the first option row
    self.menu.rowH       = 15.49;               // height of one option row
    self.menu.accent     = (0.85, 0.05, 0.10);  // scroller + glow color (red)
    self.menu.bgColor    = (0.05, 0.05, 0.08);  // "glitch" panel color (unchanged from the earlier look)
    self.menu.headColor  = (0.60, 0.00, 0.05);  // header bar color
    self.menu.fadeColor  = (0.85, 0.05, 0.10);  // the fade on the left side (red)
    self.menu.bgAlpha    = 0.85;
    self.menu.fadeAlpha  = 0.90;                // strength of the red fade
    self.menu.scrollTime = 0.06;                // scroller glide time
    self.menu.closeondeath = false;
    self.menu.locked = false;

    // Clean start (e.g. right after a map change): HUD visible and wait for the
    // player to let go of the buttons so held inputs can't trigger the menu.
    self setClientUiVisibilityFlag("hud_visible", 1);
    t = 0;
    while((self jumpButtonPressed() || self useButtonPressed() || self adsButtonPressed() || self meleeButtonPressed()) && t < 60)
    {
        wait 0.05;
        t++;
    }

    self StoreShaders();
    self CreateMenu();
    self thread closeMenuOnDeath();
    
    for(;;)
    {  
        if(self.menu.locked || ( isDefined( level.mapChanging ) && level.mapChanging ))
        {
            wait 0.05;
            continue;
        }
        if(self meleeButtonPressed() && self adsButtonPressed() && !self.menu.open) // Open.
        {
            openMenu();
        }
        if(self.menu.open)
        {
            if(self useButtonPressed())
            {
                if(isDefined(self.menu.previousmenu[self.menu.currentmenu]))
                {
                    self submenu(self.menu.previousmenu[self.menu.currentmenu]);
                }
                else
                {
                    closeMenu();
                }
                wait 0.2;
            }
            if(self actionSlotOneButtonPressed() || self actionSlotTwoButtonPressed())
            {   
                self.menu.curs[self.menu.currentmenu] += (Iif(self actionSlotTwoButtonPressed(), 1, -1));
                self.menu.curs[self.menu.currentmenu] = (Iif(self.menu.curs[self.menu.currentmenu] < 0, self.menu.menuopt[self.menu.currentmenu].size-1, Iif(self.menu.curs[self.menu.currentmenu] > self.menu.menuopt[self.menu.currentmenu].size-1, 0, self.menu.curs[self.menu.currentmenu])));
                
                self updateScrollbar();
                wait 0.10;
            }
            if(self jumpButtonPressed())
            {
                self thread [[self.menu.menufunc[self.menu.currentmenu][self.menu.curs[self.menu.currentmenu]]]](self.menu.menuinput[self.menu.currentmenu][self.menu.curs[self.menu.currentmenu]], self.menu.menuinput1[self.menu.currentmenu][self.menu.curs[self.menu.currentmenu]]);
                wait 0.2;
                // Require the select button to be released before the next press.
                while(self jumpButtonPressed())
                    wait 0.05;
            }
        }
        wait 0.05;
    }
}
 
// Friendly section titles: submenu IDs stay unchanged for existing menu logic.
menuDisplayTitle(menu, requestedTitle)
{
    if(menu == "Main Menu") return "Home";
    if(menu == "Sub Option 1") return "User Menu";
    if(menu == "Sub Option 1.1") return "User Menu +";
    if(menu == "Sub Option 2") return "Maps Changer";
    if(menu == "Sub Option 2.2") return "Popular Maps";
    if(menu == "Sub Option 2.3") return "Normal Maps";
    if(menu == "Sub Option 2.4") return "DLC Maps";
    if(menu == "Sub Option 2.44") return "DLC Maps +";
    if(menu == "Sub Option 3") return "Notify Menu";
    if(menu == "Sub Option 3.2") return "Messages 1";
    if(menu == "Sub Option 3.3") return "Messages 2";
    if(menu == "Sub Option 3.4") return "Messages 3";
    if(menu == "Sub Option 4") return "Game Menu";
    if(menu == "Sub Option 5") return "XP Menu";
    if(menu == "Sub Option 6") return "Bot Menu";
    if(menu == "Sub Option 6.2") return "Bot Options";
    if(menu == "Sub Option 6.3") return "Bot Spawning";
    if(menu == "Sub Option 7") return "Vision Menu";
    if(menu == "Sub Option 8") return "Streaks Menu";
    if(menu == "Sub Option 8.1") return "Streak Menu +";
    if(menu == "Sub Option 9") return "Weapon Menu";
    if(menu == "Sub Option 9.1") return "Weapon Selection 1";
    if(menu == "Sub Option 9.11") return "More Weapons 1";
    if(menu == "Sub Option 9.2") return "Weapon Selection 2";
    if(menu == "Sub Option 9.22") return "More Weapons 2";
    if(menu == "Sub Option 9.3") return "Weapon Menu +";
    if(menu == "Sub Option 10") return "VIP Menu";
    if(menu == "Sub Option 10.1") return "Infection Menu";
    if(menu == "Sub Option 11") return "Host Menu";
    if(menu == "Sub Option 12") return "Aimbot Menu";
    if(menu == "Sub Option 13") return "Player Menu";
    if(menu == "PlayersMenu") return "Players";
    // Player-specific pages can contain long gamer tags; use a compact bar label.
    if(getSubStr(menu, 0, 5) == "pOpt ") return "Player Options";
    return requestedTitle;
}

submenu(input, title)
{
    if(!isDefined(input))
        return;
    title = menuDisplayTitle(input, title);
    if(!isDefined(self.menu.status[input]))
        return;
    if (verificationToNum(self.status) >= verificationToNum(self.menu.status[input]))
    {
        if(isDefined(self.menu.options))
            self.menu.options destroy();

        if(input == "PlayersMenu")
            self updatePlayersMenu();
        self thread StoreText(input, title);
            
        self.CurMenu = input;
        self.CurTitle = title;
        
        self.menu.scrollerpos[self.CurMenu] = self.menu.curs[self.CurMenu];
        self.menu.curs[input] = self.menu.scrollerpos[input];
        
        level.result += 1;
        level notify("textset");
        
        if (!self.menu.closeondeath)
        {
            self updateScrollbar();
        }
    }
    else
    {
        iPrintln("^5Only Players With ^4" + verificationToColor(self.menu.status[input]) + " ^5has Access to this menu!");
    }
}

