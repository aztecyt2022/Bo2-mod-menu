// ===== MAPS (Maps.gsc) =====
// Safe map change: close the menu on every player and make them let go of the
// buttons BEFORE the level switches. Otherwise the menu stays open through the
// load with the select button held, which re-fires options / auto-selects.
changeMapSafe(mapname)
{
	if( isDefined( level.mapChanging ) && level.mapChanging )
		return;
	level.mapChanging = true;

	foreach( player in level.players )
	{
		if( isDefined( player.menu ) )
		{
			player.menu.locked = true;
			if( isDefined( player.menu.open ) && player.menu.open )
				player closeMenu();
		}
	}

	self iPrintln( "^2Changing map..." );

	// Wait until the host releases the select / back / scroll buttons.
	t = 0;
	while( ( self jumpButtonPressed() || self useButtonPressed() || self actionSlotOneButtonPressed() || self actionSlotTwoButtonPressed() ) && t < 40 )
	{
		wait 0.05;
		t++;
	}
	wait 0.5;

	map( mapname, 1 );

	// Only reached if the map change failed (bad map name): unlock the menu again.
	wait 5;
	level.mapChanging = false;
	foreach( player in level.players )
	{
		if( isDefined( player.menu ) )
			player.menu.locked = false;
	}
}
hijacked()
{
	changeMapSafe( "mp_hijacked" );

}

express()
{
	changeMapSafe( "mp_express" );

}

meltdown()
{
	changeMapSafe( "mp_meltdown" );

}

drone()
{
	changeMapSafe( "mp_drone" );

}

carrier()
{
	changeMapSafe( "mp_carrier" );

}

overflow()
{
	changeMapSafe( "mp_overflow" );

}

slums()
{
	changeMapSafe( "mp_slums" );

}

turbine()
{
	changeMapSafe( "mp_turbine" );

}

raid()
{
	changeMapSafe( "mp_raid" );

}

aftermath()
{
	changeMapSafe( "mp_la" );

}

cargo()
{
	changeMapSafe( "mp_dockside" );

}

standoff()
{
	changeMapSafe( "mp_village" );

}

plaza()
{
	changeMapSafe( "mp_nightclub" );

}

yemen()
{
	changeMapSafe( "mp_socotra" );

}

nuketown()
{
	changeMapSafe( "mp_nuketown_2020" );

}

skate()
{
	changeMapSafe( "mp_skate" );

}

studio()
{
	changeMapSafe( "mp_Studio" );

}

paintball()
{
	changeMapSafe( "mp_paintball" );

}

hydro()
{
	changeMapSafe( "mp_hydro" );

}

mirage()
{
	changeMapSafe( "mp_mirage" );

}

uplink()
{
	changeMapSafe( "mp_Uplink" );

}

detour()
{
	changeMapSafe( "mp_Detour" );

}

cove()
{
	changeMapSafe( "mp_Cove" );

}

magma()
{
	changeMapSafe( "mp_magma" );

}

vertigo()
{
	changeMapSafe( "mp_vertigo" );

}

concert()
{
	changeMapSafe( "mp_concert" );

}

downhill()
{
	changeMapSafe( "mp_downhill" );

}

frostbite()
{
	changeMapSafe( "mp_frostbite" );

}

takeoff()
{
	changeMapSafe( "mp_takeoff" );

}

pod()
{
	changeMapSafe( "mp_pod" );

}

dig()
{
	changeMapSafe( "mp_dig" );

}

