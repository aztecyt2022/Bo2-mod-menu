// ===== NOTIFICATIONS + VISIONS (Notify.gsc) =====
// ===== NOTIFY MESSAGES =====
// Every option below goes through sendNotify(): one place controls how the
// popup looks. Glow colors are 0-1 floats, the popup stays visible while the
// menu is open, and an optional subtitle line sits under the title.
sendNotify(title, subtitle, glow, duration)
{
	notifydata = spawnstruct();
	notifydata.titletext = title;
	notifydata.notifytext = subtitle;
	notifydata.glowcolor = glow;
	notifydata.duration = duration;
	notifydata.font = "objective";
	notifydata.hideWhenInMenu = false;

	level.result += 1;
	level notify( "textset" );
	foreach( player in level.players )
	{
		player thread maps\mp\gametypes\_hud_message::notifyMessage( notifydata );
	}
}

msg()
{
	sendNotify( "^1Menu ^3Version: ^5V3.4B1", "^7BO2 GSC Mod Menu", (1, 0.1, 0.1), 6 );
}

msg2()
{
	sendNotify( "^4Menu by: ^1Azyt", "^7Menu base by TORQ", (0.2, 0.4, 1), 4 );
}

msga()
{
	sendNotify( "^4NO Payment in 2026 WHY!", "^7Free menu, free hosting", (0.2, 0.4, 1), 8.5 );
}

msgb()
{
	sendNotify( "^3OPEN SOURCE MENU", "^7Learn from it, build on it", (1, 0.9, 0.1), 5 );
}

msgc()
{
	sendNotify( "^6You toothless Crack Addict!", "", (1, 0.3, 0.8), 8 );
}

msg9()
{
	sendNotify( "^3OFFLINE USE ONLY", "^7Dont go online and ruin the game", (1, 0.9, 0.1), 6 );
}

msgd()
{
	sendNotify( "^3FUCK OFF HOE ASS BITCH", "", (1, 0.9, 0.1), 10 );
}

msge()
{
	sendNotify( "^1R3D ^2AC1D ^6V3.4B1", "^7ADS + Melee to open", (1, 0.1, 0.1), 6 );
}

msgf()
{
	sendNotify( "^4W^3E^1E^2D ^5B^3A^2B^4Y", "", (0.1, 1, 0.2), 5 );
}

msgg()
{
	sendNotify( "^3PS4 ^8Mod ^1menu Build", "^7DeadOps loader", (1, 0.9, 0.1), 5 );
}

msg0()
{
	sendNotify( "^3Black Ops2 In ^22026 ^3still on ^2top!", "^7Still going strong", (0.1, 1, 0.2), 8 );
}

msgyes()
{
	sendNotify( "^2YEAH!", "", (0.1, 1, 0.2), 2 );
}

msgno()
{
	sendNotify( "^1NOPE!", "", (1, 0.1, 0.1), 2 );
}

msgwhy()
{
	sendNotify( "^1Why!", "", (1, 0.1, 0.1), 2 );
}

msggbb()
{
	sendNotify( "^2Get Outta My lobby bish!", "", (0.1, 1, 0.2), 6 );
}

msgga1()
{
	sendNotify( "^3SHUT THE ^1FUCK ^3UP!", "", (1, 0.9, 0.1), 4 );
}

msgga2()
{
	sendNotify( "^3Listen To This moron!!", "", (1, 0.9, 0.1), 6 );
}



//Vision are below here!







BWV()
{
    self endon("disconnect");
    self endon("death");
    
	if(self.bw == true)
	{
		self useServerVisionSet(true);
		self SetVisionSetforPlayer("mpintro", 0);
		self iPrintln("^1Black & White ^2[On]");
		self.bw = false;
	}
	else
	{
		self useServerVisionSet(false);
		self iPrintln("^2Black & White ^1[Off]");
		self.bw = true;
	}
}

LVis()
{
    self endon("disconnect");
    self endon("death");
    
	if(self.lv == true)
	{
		self useServerVisionSet(true);
		self SetVisionSetforPlayer("taser_mine_shock", 0);
		self iPrintln("^1Light Vision ^2[On]");
		self.lv = false;
	}
	else
	{
		self useServerVisionSet(false);
		self iPrintln("^2Light Vision ^1[Off]");
		self.lv = true;
	}
}

EV()
{
    self endon("disconnect");
    self endon("death");
    
	if(self.ev == true)
	{
		self useServerVisionSet(true);
		self SetVisionSetforPlayer("remote_mortar_enhanced", 0);
		self iPrintln("^1Enhanced Vision ^2[On]");
		self.ev = false;
	}
	else
	{
		self useServerVisionSet(false);
		self iPrintln("^2Enhanced Vision ^1[Off]");
		self.ev = true;
	}
}

infrarV()
{
    self endon("disconnect");
    self endon("death");
    
	if(self.infrarv == true)
	{
		self setinfraredvision(true);
		self iPrintln("^1Infrared Vision ^2[On]");
		self.infrarv = false;
	}
	else
	{
		self setinfraredvision(false);
		self iPrintln("^2Infrared Vision ^1[Off]");
		self.infrarv = true;
	}
}

WVis()
{
    self endon("disconnect");
    self endon("death");
    
    if(self isHost())
    {
	if(self.wv == true)
	{
		self useServerVisionSet(true);
		setdvar("r_waterSheetingFX_enable", "1");
		self iPrintln("^1Water Vision ^2[On]");
		self.wv = false;
	}
	else
	{
		self useServerVisionSet(false);
		setdvar("r_waterSheetingFX_enable", "0");
		self iPrintln("^2Water Vision ^1[Off]");
		self.wv = true;
	}
	}
	else
	    self iprintln("You must be ^5Host ^7to do that");
}

PVis()
{
    self endon("disconnect");
    self endon("death");
    
    if(self isHost())
    {
	if(self.pv == true)
	{
		self useServerVisionSet(true);
		setdvar("r_poisonFX_debug_enable", "1");
		self iPrintln("^1Poison Vision ^2[On]");
		self.pv = false;
	}
	else
	{
		self useServerVisionSet(false);
		setdvar("r_poisonFX_debug_enable", "0");
		self iPrintln("^2Poison Vision ^1[Off]");
		self.pv = true;
	}
	}
	else
	    self iprintln("You must be ^2Host ^7to do that");
}


// ===== VISION MENU + =====
// Same calls as BWV / LVis / EV above (useServerVisionSet + SetVisionSetforPlayer).
// Selecting the active vision again turns it off. Names come from the community
// BO2 vision list; a name the game doesn't have simply won't change the screen.
setVision(visionName, label)
{
    if(!isDefined(self.currentVision))
        self.currentVision = "";

    if(self.currentVision == visionName)
    {
        self resetVision();
        return;
    }

    self useServerVisionSet(true);
    self SetVisionSetforPlayer(visionName, 0);
    self.currentVision = visionName;
    self iPrintln("^1" + label + " Vision ^2[ON]");
}

resetVision()
{
    self.currentVision = "";
    self useServerVisionSet(false);
    self iPrintln("^2Vision ^1[RESET]");
}

v36ForgeHelp() { self iPrintln("^2Enable Forge, then aim and hold ADS to move an object"); }

v36Score50() { setDvar("scr_war_scorelimit", 50); self iPrintln("^2TDM score limit set to 50"); }

v36Score100() { setDvar("scr_war_scorelimit", 100); self iPrintln("^2TDM score limit set to 100"); }

v36ScoreUnlimited() { setDvar("scr_war_scorelimit", 0); self iPrintln("^2TDM score limit disabled"); }

v36ScoreRestore() { setDvar("scr_war_scorelimit", 75); self iPrintln("^2TDM score limit set to 75"); }

v36PlayerCount() { self iPrintln("^2Connected players: " + level.players.size); }

v36MyTeam() { self iPrintln("^2Your team: " + self.pers["team"]); }

v36PlayerListHelp() { self iPrintln("^2Use Verify Menu for player selection and controls"); }

v36SaveA() { if(!isAlive(self)) return; self.v36LocationA = self.origin; self iPrintln("^2Location A saved"); }
v36SaveB() { if(!isAlive(self)) return; self.v36LocationB = self.origin; self iPrintln("^2Location B saved"); }
v36LoadA()
{
    if(!isAlive(self) || !isDefined(self.v36LocationA)) { self iPrintln("^1Save location A first"); return; }
    self setOrigin(self.v36LocationA); self iPrintln("^2Returned to A");
}
v36LoadB()
{
    if(!isAlive(self) || !isDefined(self.v36LocationB)) { self iPrintln("^1Save location B first"); return; }
    self setOrigin(self.v36LocationB); self iPrintln("^2Returned to B");
}
forgeBuild(rows)
{
    if(!isAlive(self)) return;
    if(!isDefined(level.forgeBuildCount))
    {
        level.forgeBuildCount = 0;
        level.forgeCrateCount = 0;
        level.forgeBuilds = [];
    }
    if(level.forgeCrateCount + rows * rows > 48)
    {
        self iPrintln("^1Forge full: undo a build first");
        return;
    }
    view = self getPlayerAngles();
    forward = anglesToForward((0, view[1], 0));
    sideways = anglesToForward((0, view[1] + 90, 0));
    start = self.origin + forward * 96;
    tiles = [];
    for(row = 0; row < rows; row++)
    {
        for(col = 0; col < rows; col++)
        {
            position = start + forward * (row * 40) + sideways * ((col - (rows - 1) * 0.5) * 70);
            tile = spawn("script_model", position);
            if(!isDefined(tile))
            {
                foreach(piece in tiles) piece delete();
                self iPrintln("^1Unable to place build");
                return;
            }
            tile setModel("t6_wpn_supply_drop_ally");
            tile.angles = (0, view[1], 0);
            if(rows == 1) tile.forgeSingle = true;
            tile solid();
            tiles[tiles.size] = tile;
        }
    }
    level.forgeBuilds[level.forgeBuildCount] = tiles;
    level.forgeBuildCount++;
    level.forgeCrateCount += tiles.size;
    self iPrintln("^2Placed " + tiles.size + " crate(s)");
}

forgeUndo()
{
    if(!isDefined(level.forgeBuildCount) || level.forgeBuildCount == 0)
    {
        self iPrintln("^1No Forge builds to undo");
        return;
    }
    level.forgeBuildCount--;
    tiles = level.forgeBuilds[level.forgeBuildCount];
    foreach(tile in tiles)
    {
        if(isDefined(tile)) tile delete();
    }
    level.forgeCrateCount -= tiles.size;
    level.forgeBuilds[level.forgeBuildCount] = undefined;
    self iPrintln("^2Removed last Forge build");
}
